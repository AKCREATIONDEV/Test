package com.thirtydegreesray.openhub.mvp.model;

/**
 * A git reference (branch head).
 */
public class GitRef {

    private String ref;
    private GitObject object;

    public String getRef() {
        return ref;
    }

    public GitObject getObject() {
        return object;
    }

}
