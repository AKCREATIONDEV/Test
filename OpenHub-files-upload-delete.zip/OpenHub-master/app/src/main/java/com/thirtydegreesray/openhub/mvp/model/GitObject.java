package com.thirtydegreesray.openhub.mvp.model;

/**
 * Git Data API object reference (blob, tree, commit): only the sha is needed.
 */
public class GitObject {

    private String sha;
    private String type;

    public String getSha() {
        return sha;
    }

    public String getType() {
        return type;
    }

}
