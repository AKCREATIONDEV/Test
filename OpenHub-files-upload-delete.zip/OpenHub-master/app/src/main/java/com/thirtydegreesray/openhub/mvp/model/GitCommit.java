package com.thirtydegreesray.openhub.mvp.model;

/**
 * A git commit of the Git Data API (only the fields the app needs).
 */
public class GitCommit {

    private String sha;
    private GitObject tree;

    public String getSha() {
        return sha;
    }

    /** the tree this commit points to */
    public GitObject getTree() {
        return tree;
    }

}
