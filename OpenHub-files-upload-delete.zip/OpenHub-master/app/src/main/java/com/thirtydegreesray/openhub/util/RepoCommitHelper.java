package com.thirtydegreesray.openhub.util;

import android.content.ContentResolver;
import android.util.Base64;

import com.thirtydegreesray.openhub.http.RepoService;
import com.thirtydegreesray.openhub.mvp.model.GitCommit;
import com.thirtydegreesray.openhub.mvp.model.GitObject;
import com.thirtydegreesray.openhub.mvp.model.GitRef;
import com.thirtydegreesray.openhub.mvp.model.GitTree;
import com.thirtydegreesray.openhub.mvp.model.GitTreeEntry;
import com.thirtydegreesray.openhub.mvp.model.UpdateFileRequest;
import com.thirtydegreesray.openhub.mvp.model.UploadItem;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import retrofit2.Response;
import rx.Observable;

/**
 * Uploads and deletes repository files through the Git Data API. Any number of files change in
 * ONE commit: blobs are created, then a tree on top of the branch head, then a commit, then the
 * branch is moved. Entries with "sha": null delete files.
 * <p>
 * All methods block, call them from a background thread.
 */
public class RepoCommitHelper {

    /** bigger files are skipped, they would not fit into memory on many phones */
    public static final int MAX_FILE_BYTES = 10 * 1024 * 1024;

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    private RepoCommitHelper() {
    }

    /**
     * Progress report of a running upload / delete.
     */
    public static class Progress {
        public final int done;
        public final int total;
        public final boolean finished;

        public Progress(int done, int total, boolean finished) {
            this.done = done;
            this.total = total;
            this.finished = finished;
        }
    }

    public interface ProgressListener {
        void onProgress(int done, int total);
    }

    /**
     * The branch does not exist: tags and commits can't be changed.
     */
    public static class BranchNotFoundException extends IOException {
        public BranchNotFoundException(String message) {
            super(message);
        }
    }

    /**
     * A folder has more entries than GitHub returns in one listing.
     */
    public static class FolderTooLargeException extends IOException {
        public FolderTooLargeException() {
            super("folder too large");
        }
    }

    /**
     * Uploads all items in one commit.
     *
     * @param emptyRepo the repository has no commit yet: the first file is created through the
     *                  contents API (which makes the initial commit), the rest follows in one commit
     */
    public static void uploadFiles(RepoService service, ContentResolver resolver, String owner,
                                   String repo, String branch, boolean emptyRepo,
                                   List<UploadItem> items, String message,
                                   ProgressListener listener) throws IOException {
        int total = items.size();
        int done = 0;
        List<UploadItem> rest = items;

        if (emptyRepo) {
            UploadItem first = items.get(0);
            byte[] bytes = readBytes(resolver, first);
            UpdateFileRequest body = new UpdateFileRequest(message,
                    Base64.encodeToString(bytes, Base64.NO_WRAP), null, null);
            call(service.updateFile(owner, repo, first.getRepoPath(), body));
            done = 1;
            if (listener != null) listener.onProgress(done, total);
            rest = items.subList(1, total);
            if (rest.isEmpty()) return;
        }

        JSONArray entries = new JSONArray();
        for (UploadItem item : rest) {
            byte[] bytes = readBytes(resolver, item);
            GitObject blob = body(call(service.createBlob(owner, repo, new Base64JsonBody(bytes))));
            entries.put(treeEntry(item.getRepoPath(), blob.getSha()));
            done++;
            if (listener != null) listener.onProgress(done, total);
        }
        commitTree(service, owner, repo, branch, entries, message);
    }

    /**
     * Deletes the given file paths in one commit.
     */
    public static void deletePaths(RepoService service, String owner, String repo, String branch,
                                   List<String> paths, String message) throws IOException {
        JSONArray entries = new JSONArray();
        for (String path : paths) {
            entries.put(treeEntry(path, null));
        }
        commitTree(service, owner, repo, branch, entries, message);
    }

    /**
     * All files (and submodules) below a folder.
     *
     * @param folderSha tree sha of the folder, as listed by the contents API
     */
    public static List<String> listFolderFiles(RepoService service, String owner, String repo,
                                               String folderPath, String folderSha) throws IOException {
        GitTree tree = body(call(service.getGitTree(true, owner, repo, folderSha, 1)));
        if (tree.isTruncated()) throw new FolderTooLargeException();
        List<String> paths = new ArrayList<>();
        if (tree.getTree() != null) {
            for (GitTreeEntry entry : tree.getTree()) {
                if (!entry.isTree()) {
                    paths.add(folderPath + "/" + entry.getPath());
                }
            }
        }
        return paths;
    }

    // ------------------------------------------------------------------
    // the commit itself
    // ------------------------------------------------------------------

    private static void commitTree(RepoService service, String owner, String repo, String branch,
                                   JSONArray entries, String message) throws IOException {
        String ref = "heads/" + branch;

        Response<GitRef> refResponse = callRaw(service.getGitRef(true, owner, repo, ref));
        if (refResponse.code() == 404) {
            throw new BranchNotFoundException(branch);
        }
        if (!refResponse.isSuccessful()) {
            throw new IOException(ActionsFileHelper.getFailureMessage(refResponse));
        }
        String parentSha = body(refResponse).getObject().getSha();

        GitCommit parent = body(call(service.getGitCommit(true, owner, repo, parentSha)));
        String baseTree = parent.getTree().getSha();

        try {
            JSONObject treeBody = new JSONObject();
            treeBody.put("base_tree", baseTree);
            treeBody.put("tree", entries);
            GitObject tree = body(call(service.createTree(owner, repo, json(treeBody))));

            JSONObject commitBody = new JSONObject();
            commitBody.put("message", message);
            commitBody.put("tree", tree.getSha());
            commitBody.put("parents", new JSONArray().put(parentSha));
            GitCommit commit = body(call(service.createCommit(owner, repo, json(commitBody))));

            JSONObject refBody = new JSONObject();
            refBody.put("sha", commit.getSha());
            refBody.put("force", false);
            call(service.updateGitRef(owner, repo, ref, json(refBody)));
        } catch (JSONException e) {
            throw new IOException(e.getMessage());
        }
    }

    private static JSONObject treeEntry(String path, String blobSha) throws IOException {
        try {
            JSONObject entry = new JSONObject();
            entry.put("path", path);
            entry.put("mode", "100644");
            entry.put("type", "blob");
            // JSONObject.NULL writes an explicit null, which deletes the entry from the tree
            entry.put("sha", blobSha == null ? JSONObject.NULL : blobSha);
            return entry;
        } catch (JSONException e) {
            throw new IOException(e.getMessage());
        }
    }

    private static RequestBody json(JSONObject object) {
        return RequestBody.create(JSON, object.toString());
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    private static byte[] readBytes(ContentResolver resolver, UploadItem item) throws IOException {
        InputStream in = resolver.openInputStream(item.getUri());
        if (in == null) throw new IOException("Cannot read " + item.getRepoPath());
        try {
            long size = item.getSize();
            ByteArrayOutputStream out = new ByteArrayOutputStream(
                    size > 0 && size <= MAX_FILE_BYTES ? (int) size : 8192);
            byte[] buffer = new byte[16 * 1024];
            int count;
            long total = 0;
            while ((count = in.read(buffer)) != -1) {
                total += count;
                if (total > MAX_FILE_BYTES) {
                    throw new IOException(item.getRepoPath() + " is larger than "
                            + (MAX_FILE_BYTES / (1024 * 1024)) + " MB");
                }
                out.write(buffer, 0, count);
            }
            return out.toByteArray();
        } finally {
            in.close();
        }
    }

    /**
     * Runs the request on the current thread and fails with GitHub's own message.
     */
    private static <T> Response<T> call(Observable<Response<T>> observable) throws IOException {
        Response<T> response = callRaw(observable);
        if (!response.isSuccessful()) {
            throw new IOException(ActionsFileHelper.getFailureMessage(response));
        }
        return response;
    }

    /**
     * Same, but the caller inspects failing responses itself.
     */
    private static <T> Response<T> callRaw(Observable<Response<T>> observable) throws IOException {
        try {
            return observable.toBlocking().first();
        } catch (RuntimeException e) {
            // RxJava wraps checked exceptions of the blocking call
            if (e.getCause() instanceof IOException) throw (IOException) e.getCause();
            throw e;
        }
    }

    private static <T> T body(Response<T> response) throws IOException {
        if (response.body() == null) throw new IOException("Empty response from GitHub");
        return response.body();
    }

}
