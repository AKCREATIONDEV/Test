package com.thirtydegreesray.openhub.util;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;

import com.thirtydegreesray.openhub.mvp.model.UploadItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Turns what the user picked (files or a folder of the Storage Access Framework) into a list of
 * files with their paths in the repository, applying the size and count limits.
 * Must be called from a background thread.
 */
public class UploadScanner {

    public static final int MAX_FILES = 300;
    public static final long MAX_TOTAL_BYTES = 50L * 1024 * 1024;
    /** stop walking a gigantic folder tree after this many rejected files */
    private static final int MAX_SKIPPED_BEFORE_STOP = 1000;

    private UploadScanner() {
    }

    public static class ScanResult {
        public final ArrayList<UploadItem> items = new ArrayList<>();
        public long totalBytes;
        /** too big, over the limits, or a duplicate of another picked path */
        public int skipped;
    }

    /**
     * @param targetDir folder in the repository, "" for the root
     */
    public static ScanResult scanFiles(ContentResolver resolver, List<Uri> uris, String targetDir) {
        Collector collector = new Collector();
        for (Uri uri : uris) {
            String name = null;
            long size = -1;
            Cursor cursor = null;
            try {
                cursor = resolver.query(uri,
                        new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE},
                        null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    name = cursor.getString(0);
                    if (!cursor.isNull(1)) size = cursor.getLong(1);
                }
            } catch (RuntimeException ignored) {
                // provider refused the query, the name falls back to the uri
            } finally {
                if (cursor != null) cursor.close();
            }
            if (name == null) name = uri.getLastPathSegment();
            String cleanName = cleanName(name);
            if (cleanName == null) {
                collector.result.skipped++;
                continue;
            }
            collector.add(join(targetDir, cleanName), uri, size);
        }
        return collector.result;
    }

    /**
     * Walks a folder picked with ACTION_OPEN_DOCUMENT_TREE. The folder keeps its name:
     * picking "docs" with target "assets" gives assets/docs/....
     */
    public static ScanResult scanFolder(ContentResolver resolver, Uri treeUri, String targetDir) {
        Collector collector = new Collector();
        String rootId = DocumentsContract.getTreeDocumentId(treeUri);
        String rootName = queryDocumentName(resolver,
                DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId));
        String cleanRoot = cleanName(rootName);
        String base = cleanRoot == null ? targetDir : join(targetDir, cleanRoot);
        walk(resolver, treeUri, rootId, base, collector);
        return collector.result;
    }

    private static void walk(ContentResolver resolver, Uri treeUri, String parentDocumentId,
                             String basePath, Collector collector) {
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocumentId);
        Cursor cursor = null;
        List<String[]> subFolders = new ArrayList<>();
        try {
            cursor = resolver.query(children, new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE}, null, null, null);
            if (cursor == null) return;
            while (cursor.moveToNext()) {
                String documentId = cursor.getString(0);
                String name = cleanName(cursor.getString(1));
                String mime = cursor.getString(2);
                long size = cursor.isNull(3) ? -1 : cursor.getLong(3);
                if (name == null) {
                    collector.result.skipped++;
                    continue;
                }
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    // never upload the git metadata of a local clone
                    if (!".git".equals(name)) {
                        subFolders.add(new String[]{documentId, name});
                    }
                } else {
                    Uri documentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId);
                    collector.add(join(basePath, name), documentUri, size);
                }
            }
        } catch (RuntimeException ignored) {
            // unreadable folder: its files are simply not offered
        } finally {
            if (cursor != null) cursor.close();
        }
        for (String[] folder : subFolders) {
            if (collector.result.skipped > MAX_SKIPPED_BEFORE_STOP) return;
            walk(resolver, treeUri, folder[0], join(basePath, folder[1]), collector);
        }
    }

    private static String queryDocumentName(ContentResolver resolver, Uri documentUri) {
        Cursor cursor = null;
        try {
            cursor = resolver.query(documentUri,
                    new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) return cursor.getString(0);
        } catch (RuntimeException ignored) {
            // no name available
        } finally {
            if (cursor != null) cursor.close();
        }
        return null;
    }

    /**
     * A single path segment usable in git, or null.
     */
    static String cleanName(String name) {
        if (name == null) return null;
        String clean = name.replace('\\', '_').replace('/', '_').trim();
        if (clean.length() == 0 || ".".equals(clean) || "..".equals(clean)) return null;
        return clean;
    }

    static String join(String base, String name) {
        if (base == null || base.length() == 0) return name;
        return base + "/" + name;
    }

    /**
     * Collects accepted files, enforcing the limits and keeping one entry per repository path.
     */
    private static class Collector {
        final ScanResult result = new ScanResult();
        private final Map<String, Integer> indexByPath = new HashMap<>();

        void add(String repoPath, Uri uri, long size) {
            long countedSize = Math.max(size, 0);
            if (size > RepoCommitHelper.MAX_FILE_BYTES) {
                result.skipped++;
                return;
            }
            Integer existing = indexByPath.get(repoPath);
            if (existing != null) {
                // the same path picked twice: the last pick wins, git trees can't hold duplicates
                UploadItem old = result.items.get(existing);
                result.totalBytes += countedSize - Math.max(old.getSize(), 0);
                result.items.set(existing, new UploadItem(repoPath, uri, size));
                result.skipped++;
                return;
            }
            if (result.items.size() >= MAX_FILES || result.totalBytes + countedSize > MAX_TOTAL_BYTES) {
                result.skipped++;
                return;
            }
            indexByPath.put(repoPath, result.items.size());
            result.items.add(new UploadItem(repoPath, uri, size));
            result.totalBytes += countedSize;
        }
    }

}
