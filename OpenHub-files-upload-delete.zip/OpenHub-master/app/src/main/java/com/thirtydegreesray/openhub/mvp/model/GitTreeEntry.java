package com.thirtydegreesray.openhub.mvp.model;

/**
 * One entry of a git tree.
 */
public class GitTreeEntry {

    private String path;
    private String mode;
    /** blob, tree or commit (submodule) */
    private String type;
    private String sha;

    public String getPath() {
        return path;
    }

    public String getMode() {
        return mode;
    }

    public String getType() {
        return type;
    }

    public String getSha() {
        return sha;
    }

    public boolean isTree() {
        return "tree".equals(type);
    }

}
