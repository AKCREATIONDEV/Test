

package com.thirtydegreesray.openhub.mvp.contract;

import android.net.Uri;
import android.support.annotation.NonNull;

import com.thirtydegreesray.openhub.mvp.contract.base.IBaseContract;
import com.thirtydegreesray.openhub.mvp.contract.base.IBaseListContract;
import com.thirtydegreesray.openhub.mvp.contract.base.IBasePagerContract;
import com.thirtydegreesray.openhub.mvp.model.FileModel;
import com.thirtydegreesray.openhub.mvp.model.FilePath;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ThirtyDegreesRay on 2017/8/14 16:02:28
 */

public interface IRepoFilesContract {

    interface View extends IBaseContract.View, IBasePagerContract.View, IBaseListContract.View{
        void showFiles(ArrayList<FileModel> files);
        void showFilePath(ArrayList<FilePath> filePath);

        /**
         * The picked files are read, the user confirms the upload (commit message).
         *
         * @param targetDir folder in the repository, "" for the root
         * @param skipped   files left out (too big, over the limits, duplicates)
         */
        void showUploadPlan(String targetDir, int fileCount, long totalBytes, int skipped);

        /**
         * An upload or delete commit succeeded, the file list must be reloaded.
         */
        void onFilesChanged();
    }

    interface Presenter extends IBasePagerContract.Presenter<IRepoFilesContract.View>{
        void loadFiles(boolean isReload);
        void loadFiles(@NonNull String path, boolean isReload);
        boolean goBack();

        void scanFiles(String targetDir, List<Uri> uris);

        void scanFolder(String targetDir, Uri treeUri);

        void uploadPending(String message);

        void deleteItem(FileModel model, String message);
        void goHome();
    }

}
