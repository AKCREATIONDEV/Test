

package com.thirtydegreesray.openhub.ui.fragment;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.inject.component.AppComponent;
import com.thirtydegreesray.openhub.inject.component.DaggerFragmentComponent;
import com.thirtydegreesray.openhub.inject.module.FragmentModule;
import com.thirtydegreesray.openhub.mvp.contract.IRepoFilesContract;
import com.thirtydegreesray.openhub.mvp.model.Branch;
import com.thirtydegreesray.openhub.mvp.model.FileModel;
import com.thirtydegreesray.openhub.mvp.model.FilePath;
import com.thirtydegreesray.openhub.mvp.model.Repository;
import com.thirtydegreesray.openhub.mvp.presenter.RepoFilesPresenter;
import com.thirtydegreesray.openhub.ui.activity.RepositoryActivity;
import com.thirtydegreesray.openhub.ui.activity.ViewerActivity;
import com.thirtydegreesray.openhub.ui.activity.base.PagerActivity;
import com.thirtydegreesray.openhub.ui.adapter.FilePathAdapter;
import com.thirtydegreesray.openhub.ui.adapter.RepoFilesAdapter;
import com.thirtydegreesray.openhub.ui.fragment.base.ListFragment;
import com.thirtydegreesray.openhub.util.AppOpener;
import com.thirtydegreesray.openhub.util.BundleHelper;
import com.thirtydegreesray.openhub.util.StringUtils;

import java.util.ArrayList;

import javax.inject.Inject;

import butterknife.BindView;

/**
 * Created by ThirtyDegreesRay on 2017/8/14 16:13:20
 */

public class RepoFilesFragment extends ListFragment<RepoFilesPresenter, RepoFilesAdapter>
        implements IRepoFilesContract.View, PagerActivity.IFragmentKeyListener,
        RepositoryActivity.RepositoryListener{

    public static RepoFilesFragment create(Repository repository) {
        RepoFilesFragment fragment = new RepoFilesFragment();
        fragment.setArguments(BundleHelper.builder().put("repo", repository).build());
        return fragment;
    }

    private static final int REQUEST_PICK_FILES = 0x51;
    private static final int REQUEST_PICK_FOLDER = 0x52;

    /** repository folder the next picked files go to, "" for the root */
    private String pendingUploadDir = "";

    @BindView(R.id.path_recycler_view) RecyclerView pathRecyclerView;
    @Inject FilePathAdapter filePathAdapter;

    @Override
    public void showFiles(ArrayList<FileModel> files) {
        adapter.setData(files);
        // the upload box ends the root listing; in an empty repository it is the whole content
        boolean atRoot = StringUtils.isBlank(mPresenter.getCurPath());
        boolean canWrite = mPresenter.canWrite();
        adapter.setCanWrite(canWrite);
        adapter.setUploadBox(atRoot && canWrite, atRoot && files.isEmpty());
        postNotifyDataSetChanged();
    }

    @Override
    public void showFilePath(final ArrayList<FilePath> filePath) {
        filePathAdapter.setData(filePath);
        filePathAdapter.notifyDataSetChanged();
        if(filePath.size() != 0)
            pathRecyclerView.post(new Runnable() {
                @Override
                public void run() {
                    pathRecyclerView.smoothScrollToPosition(filePath.size() - 1);
                }
            });
    }

    @Override
    public void showLoading() {
        refreshLayout.setRefreshing(true);
    }

    @Override
    public void hideLoading() {
        refreshLayout.setRefreshing(false);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_repo_files;
    }

    @Override
    protected void setupFragmentComponent(AppComponent appComponent) {
        DaggerFragmentComponent.builder()
                .appComponent(appComponent)
                .fragmentModule(new FragmentModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initFragment(Bundle savedInstanceState) {
        super.initFragment(savedInstanceState);
        pathRecyclerView.setLayoutManager(
                new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        pathRecyclerView.setAdapter(filePathAdapter);
        adapter.setOnFileMenuClickListener(new RepoFilesAdapter.OnFileMenuClickListener() {
            @Override
            public void onFileMenuClick(FileModel model, View anchor) {
                showFileMenu(model, anchor);
            }
        });
        adapter.setOnUploadBoxClickListener(new RepoFilesAdapter.OnUploadBoxClickListener() {
            @Override
            public void onUploadBoxClick() {
                startUpload("");
            }
        });
        filePathAdapter.setOnItemClickListener((position, view) ->
                mPresenter.loadFiles(filePathAdapter.getData().get(position).getFullPath(), false)
        );
    }

    @Override
    protected void onReLoadData() {
        mPresenter.loadFiles(true);
    }

    @Override
    protected String getEmptyTip() {
        return getString(R.string.no_file);
    }

    @Override
    public void onItemClick(int position, @NonNull View view) {
        super.onItemClick(position, view);
        if(position >= adapter.getData().size()) return;
        FileModel model = adapter.getData().get(position);
        if(model.isDir()){
            mPresenter.loadFiles(model.getPath(), false);
        }else{
            ViewerActivity.show(getActivity(), model, mPresenter.getRepoName());
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN){
            return mPresenter.goBack();
        }
        return false;
    }

    @Override
    public void onFragmentShowed() {
        super.onFragmentShowed();
        if(mPresenter != null) mPresenter.prepareLoadData();
    }

    @Override
    public void onRepositoryInfoUpdated(Repository repository) {

    }

    @Override
    public void onBranchChanged(Branch branch) {
        if(mPresenter == null){
            getArguments().putString("branch", branch.getName());
        } else {
            mPresenter.setCurBranch(branch.getName());
            mPresenter.setLoaded(false);
            mPresenter.prepareLoadData();
        }
    }

    // ------------------------------------------------------------------
    // three dot menu of a file / folder: upload, delete, download
    // ------------------------------------------------------------------

    private void showFileMenu(final FileModel model, View anchor) {
        PopupMenu popup = new PopupMenu(getActivity(), anchor);
        popup.inflate(R.menu.menu_repo_file);
        Menu menu = popup.getMenu();
        boolean canWrite = mPresenter.canWrite();
        menu.findItem(R.id.action_file_upload).setVisible(canWrite);
        menu.findItem(R.id.action_file_delete).setVisible(canWrite);
        // a folder can't be downloaded
        menu.findItem(R.id.action_file_download).setVisible(model.isFile());
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_file_upload:
                        // a folder receives the files itself, a file's neighbours go to its folder
                        startUpload(model.isDir() ? model.getPath() : getParentPath(model.getPath()));
                        return true;
                    case R.id.action_file_delete:
                        confirmDelete(model);
                        return true;
                    case R.id.action_file_download:
                        downloadFile(model);
                        return true;
                    default:
                        return false;
                }
            }
        });
        popup.show();
    }

    private String getParentPath(String path) {
        return path.contains("/") ? path.substring(0, path.lastIndexOf('/')) : "";
    }

    private void downloadFile(FileModel model) {
        if (StringUtils.isBlank(model.getDownloadUrl())) {
            showWarningToast(getString(R.string.files_download_unavailable));
            return;
        }
        AppOpener.startDownload(getActivity(), model.getDownloadUrl(), model.getName());
    }

    // ------------------------------------------------------------------
    // upload: pick files or a folder, confirm with a commit message, one commit
    // ------------------------------------------------------------------

    private void startUpload(String targetDir) {
        pendingUploadDir = targetDir;
        String shownDir = StringUtils.isBlank(targetDir) ? getString(R.string.files_upload_root) : targetDir;
        new AlertDialog.Builder(getActivity())
                .setTitle(getString(R.string.files_upload_choose_title, shownDir))
                .setItems(new String[]{getString(R.string.files_upload_choose_files),
                                getString(R.string.files_upload_choose_folder)},
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (which == 0) {
                                    pickFiles();
                                } else {
                                    pickFolder();
                                }
                            }
                        })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void pickFiles() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startPicker(intent, REQUEST_PICK_FILES);
    }

    private void pickFolder() {
        startPicker(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQUEST_PICK_FOLDER);
    }

    private void startPicker(Intent intent, int requestCode) {
        try {
            startActivityForResult(intent, requestCode);
        } catch (ActivityNotFoundException e) {
            showErrorToast(getString(R.string.files_no_file_picker));
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK || data == null) return;
        if (requestCode == REQUEST_PICK_FILES) {
            ArrayList<Uri> uris = new ArrayList<>();
            ClipData clipData = data.getClipData();
            if (clipData != null) {
                for (int i = 0; i < clipData.getItemCount(); i++) {
                    uris.add(clipData.getItemAt(i).getUri());
                }
            } else if (data.getData() != null) {
                uris.add(data.getData());
            }
            if (!uris.isEmpty()) mPresenter.scanFiles(pendingUploadDir, uris);
        } else if (requestCode == REQUEST_PICK_FOLDER) {
            if (data.getData() != null) mPresenter.scanFolder(pendingUploadDir, data.getData());
        }
    }

    @Override
    public void showUploadPlan(String targetDir, int fileCount, long totalBytes, int skipped) {
        String shownDir = StringUtils.isBlank(targetDir) ? getString(R.string.files_upload_root) : targetDir;
        StringBuilder info = new StringBuilder(getString(R.string.files_upload_summary,
                fileCount, StringUtils.getSizeString(totalBytes)));
        info.append('\n').append(getString(R.string.files_upload_target, shownDir,
                mPresenter.getCurBranch()));
        if (skipped > 0) {
            info.append('\n').append(getString(R.string.files_upload_skipped, skipped));
        }
        showCommitDialog(R.string.files_upload, info.toString(),
                getString(R.string.files_upload_default_message),
                new OnMessageConfirmedListener() {
                    @Override
                    public void onConfirmed(String message) {
                        mPresenter.uploadPending(message);
                    }
                });
    }

    // ------------------------------------------------------------------
    // delete: a file, or every file of a folder, in one commit
    // ------------------------------------------------------------------

    private void confirmDelete(final FileModel model) {
        String info = model.isDir()
                ? getString(R.string.files_delete_info_folder, model.getName(), mPresenter.getCurBranch())
                : getString(R.string.files_delete_info_file, model.getPath(), mPresenter.getCurBranch());
        showCommitDialog(R.string.delete, info,
                getString(R.string.files_delete_default_message, model.getName()),
                new OnMessageConfirmedListener() {
                    @Override
                    public void onConfirmed(String message) {
                        mPresenter.deleteItem(model, message);
                    }
                });
    }

    @Override
    public void onFilesChanged() {
        mPresenter.loadFiles(true);
    }

    // ------------------------------------------------------------------
    // shared commit message dialog
    // ------------------------------------------------------------------

    private interface OnMessageConfirmedListener {
        void onConfirmed(String message);
    }

    /**
     * Info text, editable commit message, and a button named like the action. An empty message
     * keeps the dialog open.
     */
    private void showCommitDialog(int actionRes, String info, String defaultMessage,
                                  final OnMessageConfirmedListener listener) {
        View content = View.inflate(getActivity(), R.layout.dialog_commit, null);
        ((TextView) content.findViewById(R.id.commit_info)).setText(info);
        final EditText messageEdit = (EditText) content.findViewById(R.id.commit_message);
        messageEdit.setText(defaultMessage);
        messageEdit.setSelection(messageEdit.getText().length());

        final AlertDialog dialog = new AlertDialog.Builder(getActivity())
                .setTitle(actionRes)
                .setView(content)
                .setPositiveButton(actionRes, null)
                .setNegativeButton(R.string.cancel, null)
                .show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = messageEdit.getText().toString().trim();
                if (message.length() == 0) {
                    messageEdit.setError(getString(R.string.actions_commit_message_required));
                    return;
                }
                dialog.dismiss();
                listener.onConfirmed(message);
            }
        });
    }

}
