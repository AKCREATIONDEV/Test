package com.thirtydegreesray.openhub.ui.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.AppCompatImageView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.mvp.model.FileModel;
import com.thirtydegreesray.openhub.ui.adapter.base.BaseAdapter;
import com.thirtydegreesray.openhub.ui.adapter.base.BaseViewHolder;
import com.thirtydegreesray.openhub.util.StringUtils;

import javax.inject.Inject;

import butterknife.BindView;

/**
 * Files and folders of a repository directory. A three dot button sits behind every entry, and
 * in the repository root an upload box is appended as the last row (the only row in an empty
 * repository).
 */
public class RepoFilesAdapter extends BaseAdapter<BaseViewHolder, FileModel> {

    private static final int TYPE_FILE = 0;
    private static final int TYPE_UPLOAD_BOX = 1;

    /**
     * Listener of the three dot button of a file / folder row.
     */
    public interface OnFileMenuClickListener {
        void onFileMenuClick(FileModel model, View anchor);
    }

    /**
     * Listener of the upload box.
     */
    public interface OnUploadBoxClickListener {
        void onUploadBoxClick();
    }

    private OnFileMenuClickListener fileMenuClickListener;
    private OnUploadBoxClickListener uploadBoxClickListener;
    /** push access: folders only get a menu (upload / delete) when this is true */
    private boolean canWrite = false;
    private boolean showUploadBox = false;
    private boolean emptyRepo = false;

    @Inject
    public RepoFilesAdapter(Context context) {
        super(context);
    }

    public void setOnFileMenuClickListener(OnFileMenuClickListener listener) {
        this.fileMenuClickListener = listener;
    }

    public void setOnUploadBoxClickListener(OnUploadBoxClickListener listener) {
        this.uploadBoxClickListener = listener;
    }

    public void setCanWrite(boolean canWrite) {
        this.canWrite = canWrite;
    }

    /**
     * @param show      append the upload box as last row
     * @param emptyRepo the box is the only content: "This repository is empty" texts
     */
    public void setUploadBox(boolean show, boolean emptyRepo) {
        this.showUploadBox = show;
        this.emptyRepo = emptyRepo;
    }

    private int getFileCount() {
        return data == null ? 0 : data.size();
    }

    @Override
    public int getItemCount() {
        return getFileCount() + (showUploadBox ? 1 : 0);
    }

    @Override
    public int getItemViewType(int position) {
        return showUploadBox && position == getFileCount() ? TYPE_UPLOAD_BOX : TYPE_FILE;
    }

    @Override
    protected int getLayoutId(int viewType) {
        return viewType == TYPE_UPLOAD_BOX ? R.layout.layout_item_upload_box : R.layout.layout_item_file;
    }

    @Override
    protected BaseViewHolder getViewHolder(View itemView, int viewType) {
        if (viewType == TYPE_UPLOAD_BOX) {
            return new UploadBoxViewHolder(itemView);
        }
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull BaseViewHolder baseHolder, int position) {
        if (baseHolder instanceof UploadBoxViewHolder) {
            bindUploadBox((UploadBoxViewHolder) baseHolder);
            return;
        }
        super.onBindViewHolder(baseHolder, position);
        ViewHolder holder = (ViewHolder) baseHolder;
        final FileModel model = data.get(position);
        holder.fileName.setText(model.getName());
        if (model.isFile()) {
            holder.fileType.setImageResource(R.drawable.ic_file);
            holder.fileSize.setText(StringUtils.getSizeString(model.getSize()));
        } else {
            holder.fileType.setImageResource(R.drawable.ic_folder);
            holder.fileSize.setText("");
        }

        // files always have the menu (download), folders only when they can be changed
        holder.moreBn.setVisibility(model.isFile() || canWrite ? View.VISIBLE : View.GONE);
        holder.moreBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fileMenuClickListener != null) {
                    fileMenuClickListener.onFileMenuClick(model, v);
                }
            }
        });
    }

    private void bindUploadBox(UploadBoxViewHolder holder) {
        holder.title.setText(emptyRepo ? R.string.files_empty_repo_title : R.string.files_upload_box_title);
        holder.subtitle.setText(emptyRepo ? R.string.files_empty_repo_subtitle
                : R.string.files_upload_box_subtitle);
        holder.box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (uploadBoxClickListener != null) {
                    uploadBoxClickListener.onUploadBoxClick();
                }
            }
        });
    }

    class ViewHolder extends BaseViewHolder {

        @BindView(R.id.file_type) AppCompatImageView fileType;
        @BindView(R.id.file_name) TextView fileName;
        @BindView(R.id.file_size) TextView fileSize;
        @BindView(R.id.more_bn) ImageView moreBn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    /**
     * No ButterKnife bindings here, the row has other views than a file row.
     */
    class UploadBoxViewHolder extends BaseViewHolder {

        final View box;
        final TextView title;
        final TextView subtitle;

        UploadBoxViewHolder(@NonNull View itemView) {
            super(itemView);
            box = itemView.findViewById(R.id.upload_box);
            title = (TextView) itemView.findViewById(R.id.upload_title);
            subtitle = (TextView) itemView.findViewById(R.id.upload_subtitle);
        }
    }

}
