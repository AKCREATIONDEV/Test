package com.thirtydegreesray.openhub.mvp.model;

import android.net.Uri;

/**
 * One local file picked for upload and the path it gets in the repository.
 */
public class UploadItem {

    private final String repoPath;
    private final Uri uri;
    private final long size;

    public UploadItem(String repoPath, Uri uri, long size) {
        this.repoPath = repoPath;
        this.uri = uri;
        this.size = size;
    }

    /** full path in the repository, e.g. docs/images/logo.png */
    public String getRepoPath() {
        return repoPath;
    }

    public Uri getUri() {
        return uri;
    }

    /** size in bytes, -1 when the provider does not tell */
    public long getSize() {
        return size;
    }

}
