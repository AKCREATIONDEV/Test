

package com.thirtydegreesray.openhub.mvp.presenter;

import android.content.ContentResolver;
import android.net.Uri;
import android.support.annotation.NonNull;

import com.thirtydegreesray.dataautoaccess.annotation.AutoAccess;
import com.thirtydegreesray.openhub.common.SizedMap;
import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.dao.DaoSession;
import com.thirtydegreesray.openhub.http.RepoService;
import com.thirtydegreesray.openhub.http.core.HttpObserver;
import com.thirtydegreesray.openhub.http.core.HttpResponse;
import com.thirtydegreesray.openhub.http.core.HttpSubscriber;
import com.thirtydegreesray.openhub.http.error.HttpPageNoFoundError;
import com.thirtydegreesray.openhub.mvp.contract.IRepoFilesContract;
import com.thirtydegreesray.openhub.mvp.model.FileModel;
import com.thirtydegreesray.openhub.mvp.model.FilePath;
import com.thirtydegreesray.openhub.mvp.model.Repository;
import com.thirtydegreesray.openhub.mvp.model.UploadItem;
import com.thirtydegreesray.openhub.mvp.presenter.base.BasePagerPresenter;
import com.thirtydegreesray.openhub.util.RepoCommitHelper;
import com.thirtydegreesray.openhub.util.StringUtils;
import com.thirtydegreesray.openhub.util.UploadScanner;

import java.util.ArrayList;
import java.util.Collections;
import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import retrofit2.Response;
import rx.Observable;
import rx.Subscriber;

/**
 * Created by ThirtyDegreesRay on 2017/8/14 16:06:30
 */

public class RepoFilesPresenter extends BasePagerPresenter<IRepoFilesContract.View>
        implements IRepoFilesContract.Presenter{

    private Map<String, ArrayList<FileModel>> cacheMap;
    @AutoAccess Repository repo ;
    @AutoAccess String curPath = "";
    @AutoAccess String curBranch = "";
    private ArrayList<FilePath> filePath;
    /** files picked for upload, waiting for the user's confirmation */
    private ArrayList<UploadItem> pendingItems;
    /** the repository has no files at all (root listing is empty), uploads create the first commit */
    private boolean repoEmpty = false;
    private FilePath homePath ;

    @Inject
    public RepoFilesPresenter(DaoSession daoSession) {
        super(daoSession);
        cacheMap = new SizedMap<>();
        filePath = new ArrayList<>();
        homePath = new FilePath("", "");
        filePath.add(homePath);
    }

    @Override
    public void onViewInitialized() {
        super.onViewInitialized();
    }

    @Override
    protected void loadData() {
        loadFiles(curPath, false);
    }

    @Override
    public void loadFiles(boolean isReload) {
        loadFiles(curPath, isReload);
    }

    @Override
    public void loadFiles(@NonNull String path, boolean isReload) {
        curPath = path;
        curBranch = StringUtils.isBlank(curBranch) ? repo.getDefaultBranch() : curBranch;
        updateFilePath();
        ArrayList<FileModel> filesCache = cacheMap.get(getCacheKey());
        if(!isReload && filesCache != null){
            mView.showFiles(filesCache);
            return ;
        }

        mView.showLoading();
        HttpObserver<ArrayList<FileModel>> httpObserver =
                new HttpObserver<ArrayList<FileModel>>() {
                    @Override
                    public void onError(Throwable error) {
                        if(error instanceof HttpPageNoFoundError){
                            if(StringUtils.isBlank(curPath)) repoEmpty = true;
                            mView.showFiles(new ArrayList<FileModel>());
                        }else{
                            mView.showLoadError(getErrorTip(error));
                        }
                        mView.hideLoading();
                    }

                    @Override
                    public void onSuccess(HttpResponse<ArrayList<FileModel>> response) {
                        sort(response.body());
                        if(StringUtils.isBlank(curPath)) repoEmpty = response.body().isEmpty();
                        cacheMap.put(getCacheKey(), response.body());
                        mView.showFiles(response.body());
                        mView.hideLoading();
                    }
                };
        generalRxHttpExecute(new IObservableCreator<ArrayList<FileModel>>() {
            @Override
            public Observable<Response<ArrayList<FileModel>>> createObservable(boolean forceNetWork) {
                if(isReload){
                    // after a commit or a pull to refresh the listing has to be fresh
                    return getRepoService().getRepoFilesLatest(true, repo.getOwner().getLogin(),
                            repo.getName(), curPath, curBranch);
                }
                return getRepoService().getRepoFiles(repo.getOwner().getLogin(),
                        repo.getName(), curPath, curBranch);
            }
        }, httpObserver, false);
    }

    @Override
    public boolean goBack() {
        if(!StringUtils.isBlank(curPath)){
            curPath = curPath.contains("/") ?
                    curPath.substring(0, curPath.lastIndexOf("/")) : "";
            loadFiles(false);
            return true;
        }
        return false;
    }

    @Override
    public void goHome() {
        if(curPath.equals("")) return;
        curPath = "";
        loadFiles(false);
    }

    private void sort(ArrayList<FileModel> oriList){
        Collections.sort(oriList, new Comparator<FileModel>() {
            @Override
            public int compare(FileModel o1, FileModel o2) {
                if(!o1.getType().equals(o2.getType())){
                    return o1.isDir() ? -1 : 1;
                }
                return 0;
            }
        });
    }

    private String getCacheKey(){
        return curBranch + "-" + curPath;
    }

    public String getCurPath() {
        return curPath;
    }

    public void setCurPath(String curPath) {
        this.curPath = curPath;
    }

    public ArrayList<FilePath> getFilePath(){
        return filePath;
    }

    private void updateFilePath(){
        filePath.clear();
        filePath.add(homePath);
        if(!StringUtils.isBlank(curPath)){
            String[] pathArray = curPath.split("/");
            for(int i = 0; i < pathArray.length; i++){
                String name = pathArray[i];
                String fullPath = "";
                for(int j = 0; j <= i; j++){
                    fullPath = fullPath.concat(pathArray[j]).concat("/");
                }
                fullPath = fullPath.endsWith("/") ?
                        fullPath.substring(0, fullPath.length() - 1) : fullPath;
                FilePath path = new FilePath(name, fullPath);
                filePath.add(path);
            }
        }
        mView.showFilePath(filePath);
    }

    public String getRepoName(){
        return repo.getName();
    }

    // ------------------------------------------------------------------
    // upload / delete (one commit through the Git Data API)
    // ------------------------------------------------------------------

    /**
     * Push access decides if upload / delete are offered. Unknown permissions count as allowed,
     * GitHub rejects the commit with a clear message otherwise.
     */
    public boolean canWrite() {
        return repo.getPermissions() == null || repo.getPermissions().isPush();
    }

    public boolean isRepoEmpty() {
        return repoEmpty;
    }

    public String getCurBranch() {
        return curBranch;
    }

    @Override
    public void scanFiles(final String targetDir, final List<Uri> uris) {
        final ContentResolver resolver = getContext().getContentResolver();
        runScan(targetDir, Observable.create(
                new Observable.OnSubscribe<Response<UploadScanner.ScanResult>>() {
                    @Override
                    public void call(Subscriber<? super Response<UploadScanner.ScanResult>> subscriber) {
                        subscriber.onNext(Response.success(
                                UploadScanner.scanFiles(resolver, uris, targetDir)));
                        subscriber.onCompleted();
                    }
                }));
    }

    @Override
    public void scanFolder(final String targetDir, final Uri treeUri) {
        final ContentResolver resolver = getContext().getContentResolver();
        runScan(targetDir, Observable.create(
                new Observable.OnSubscribe<Response<UploadScanner.ScanResult>>() {
                    @Override
                    public void call(Subscriber<? super Response<UploadScanner.ScanResult>> subscriber) {
                        try {
                            subscriber.onNext(Response.success(
                                    UploadScanner.scanFolder(resolver, treeUri, targetDir)));
                            subscriber.onCompleted();
                        } catch (RuntimeException e) {
                            subscriber.onError(e);
                        }
                    }
                }));
    }

    private void runScan(final String targetDir,
                         Observable<Response<UploadScanner.ScanResult>> observable) {
        mView.showProgressDialog(getString(R.string.files_scanning));
        generalRxHttpExecute(observable, new HttpSubscriber<>(
                new HttpObserver<UploadScanner.ScanResult>() {
                    @Override
                    public void onError(Throwable error) {
                        mView.dismissProgressDialog();
                        mView.showErrorToast(getErrorTip(error));
                    }

                    @Override
                    public void onSuccess(HttpResponse<UploadScanner.ScanResult> response) {
                        mView.dismissProgressDialog();
                        UploadScanner.ScanResult result = response.body();
                        if (result == null || result.items.isEmpty()) {
                            pendingItems = null;
                            mView.showWarningToast(getString(R.string.files_no_files_selected));
                            return;
                        }
                        pendingItems = result.items;
                        mView.showUploadPlan(targetDir, result.items.size(), result.totalBytes,
                                result.skipped);
                    }
                }));
    }

    @Override
    public void uploadPending(final String message) {
        final ArrayList<UploadItem> items = pendingItems;
        if (items == null || items.isEmpty()) return;
        final ContentResolver resolver = getContext().getContentResolver();
        final RepoService service = getRepoService();
        final String owner = repo.getOwner().getLogin();
        final String name = repo.getName();
        final String branch = curBranch;
        final boolean emptyRepo = repoEmpty;

        mView.showProgressDialog(getContext().getString(R.string.files_uploading, 0, items.size()));
        runCommit(Observable.create(new Observable.OnSubscribe<Response<RepoCommitHelper.Progress>>() {
            @Override
            public void call(final Subscriber<? super Response<RepoCommitHelper.Progress>> subscriber) {
                try {
                    RepoCommitHelper.uploadFiles(service, resolver, owner, name, branch, emptyRepo,
                            items, message, new RepoCommitHelper.ProgressListener() {
                                @Override
                                public void onProgress(int done, int total) {
                                    subscriber.onNext(Response.success(
                                            new RepoCommitHelper.Progress(done, total, false)));
                                }
                            });
                    subscriber.onNext(Response.success(
                            new RepoCommitHelper.Progress(items.size(), items.size(), true)));
                    subscriber.onCompleted();
                } catch (Exception e) {
                    subscriber.onError(e);
                }
            }
        }), R.string.files_uploaded);
    }

    @Override
    public void deleteItem(final FileModel model, final String message) {
        final RepoService service = getRepoService();
        final String owner = repo.getOwner().getLogin();
        final String name = repo.getName();
        final String branch = curBranch;

        mView.showProgressDialog(getString(R.string.files_deleting));
        runCommit(Observable.create(new Observable.OnSubscribe<Response<RepoCommitHelper.Progress>>() {
            @Override
            public void call(Subscriber<? super Response<RepoCommitHelper.Progress>> subscriber) {
                try {
                    List<String> paths;
                    if (model.isDir()) {
                        // GitHub has no "delete folder": every file below it goes in one commit
                        paths = RepoCommitHelper.listFolderFiles(service, owner, name,
                                model.getPath(), model.getSha());
                    } else {
                        paths = Collections.singletonList(model.getPath());
                    }
                    if (paths.isEmpty()) {
                        throw new IOException("No files to delete");
                    }
                    RepoCommitHelper.deletePaths(service, owner, name, branch, paths, message);
                    subscriber.onNext(Response.success(new RepoCommitHelper.Progress(1, 1, true)));
                    subscriber.onCompleted();
                } catch (Exception e) {
                    subscriber.onError(e);
                }
            }
        }), R.string.files_deleted);
    }

    /**
     * Runs an upload / delete observable: progress events update the dialog, the last event
     * (finished) closes it and reloads the list.
     */
    private void runCommit(Observable<Response<RepoCommitHelper.Progress>> observable,
                           final int successTipRes) {
        generalRxHttpExecute(observable, new HttpSubscriber<>(
                new HttpObserver<RepoCommitHelper.Progress>() {
                    @Override
                    public void onError(Throwable error) {
                        mView.dismissProgressDialog();
                        if (error instanceof RepoCommitHelper.BranchNotFoundException) {
                            mView.showErrorToast(getString(R.string.files_branch_readonly));
                        } else if (error instanceof RepoCommitHelper.FolderTooLargeException) {
                            mView.showErrorToast(getString(R.string.files_folder_too_large));
                        } else {
                            mView.showErrorToast(getErrorTip(error));
                        }
                    }

                    @Override
                    public void onSuccess(HttpResponse<RepoCommitHelper.Progress> response) {
                        RepoCommitHelper.Progress progress = response.body();
                        if (progress == null) return;
                        if (!progress.finished) {
                            if (progress.done >= progress.total) {
                                mView.showProgressDialog(getString(R.string.files_upload_committing));
                            } else {
                                mView.showProgressDialog(getContext().getString(
                                        R.string.files_uploading, progress.done, progress.total));
                            }
                        } else {
                            mView.dismissProgressDialog();
                            pendingItems = null;
                            mView.showSuccessToast(getString(successTipRes));
                            mView.onFilesChanged();
                        }
                    }
                }));
    }

    public void setCurBranch(String curBranch) {
        this.curBranch = curBranch;
        curPath = "";
    }
}
