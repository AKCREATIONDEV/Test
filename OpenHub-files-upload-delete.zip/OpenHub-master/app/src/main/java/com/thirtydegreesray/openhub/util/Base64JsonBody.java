package com.thirtydegreesray.openhub.util;

import android.util.Base64;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okio.BufferedSink;

/**
 * JSON body {"encoding":"base64","content":"..."} of the "create a blob" API, written in chunks
 * so a big file is never held as one huge string.
 */
public class Base64JsonBody extends RequestBody {

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final String PREFIX = "{\"encoding\":\"base64\",\"content\":\"";
    private static final String SUFFIX = "\"}";
    /** multiple of 3, so only the last chunk carries base64 padding */
    private static final int CHUNK_BYTES = 3 * 8192;

    private final byte[] data;

    public Base64JsonBody(byte[] data) {
        this.data = data;
    }

    @Override
    public MediaType contentType() {
        return JSON;
    }

    @Override
    public long contentLength() {
        return PREFIX.length() + SUFFIX.length() + getBase64Length(data.length);
    }

    @Override
    public void writeTo(BufferedSink sink) throws IOException {
        sink.writeUtf8(PREFIX);
        int offset = 0;
        while (offset < data.length) {
            int length = Math.min(CHUNK_BYTES, data.length - offset);
            sink.writeUtf8(Base64.encodeToString(data, offset, length, Base64.NO_WRAP));
            offset += length;
        }
        sink.writeUtf8(SUFFIX);
    }

    /** length of the padded base64 text of the given number of bytes */
    static long getBase64Length(long byteCount) {
        return ((byteCount + 2) / 3) * 4;
    }

}
