package com.thirtydegreesray.openhub.mvp.model;

import java.util.ArrayList;

/**
 * A git tree. "truncated" is true when GitHub cut a very large recursive listing.
 */
public class GitTree {

    private String sha;
    private ArrayList<GitTreeEntry> tree;
    private boolean truncated;

    public String getSha() {
        return sha;
    }

    public ArrayList<GitTreeEntry> getTree() {
        return tree;
    }

    public boolean isTruncated() {
        return truncated;
    }

}
