

package com.thirtydegreesray.openhub.ui.adapter;

import android.app.Activity;
import android.support.v7.app.AlertDialog;
import android.widget.Toast;
import android.content.Context;
import android.content.res.ColorStateList;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.common.GlideApp;
import com.thirtydegreesray.openhub.mvp.model.Repository;
import com.thirtydegreesray.openhub.ui.activity.ProfileActivity;
import com.thirtydegreesray.openhub.ui.adapter.base.BaseAdapter;
import com.thirtydegreesray.openhub.ui.adapter.base.BaseViewHolder;
import com.thirtydegreesray.openhub.ui.fragment.base.BaseFragment;
import com.thirtydegreesray.openhub.util.LanguageColorsHelper;
import com.thirtydegreesray.openhub.util.PrefUtils;
import com.thirtydegreesray.openhub.util.RepoTranslationHelper;
import com.thirtydegreesray.openhub.util.StringUtils;
import com.thirtydegreesray.openhub.util.ViewUtils;

import java.util.Map;
import java.util.HashMap;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created on 2017/7/18.
 *
 * @author ThirtyDegreesRay
 */

public class RepositoriesAdapter extends BaseAdapter<RepositoriesAdapter.ViewHolder, Repository> {

    @Inject
    public RepositoriesAdapter(Context context, BaseFragment fragment){
        super(context, fragment);
    }

    /** 仓库 fullName -> 所属星标目录展示文案 */
    private Map<String, String> starListTags;

    // In-memory cache avoids translating the same repository description repeatedly.
    private final Map<String, String> translatedDescriptions = new HashMap<>();

    private static final String TRANSLATION_PREFS = "repo_translation";
    private static final String TARGET_LANGUAGE_KEY = "target_language";
    private static final String DEFAULT_TARGET_LANGUAGE = "hi";

    private static final String[] TARGET_LANGUAGE_NAMES = {
            "Hindi", "English", "Bengali", "Spanish", "French",
            "German", "Japanese", "Chinese", "Arabic", "Russian", "Portuguese"
    };
    private static final String[] TARGET_LANGUAGE_TAGS = {
            "hi", "en", "bn", "es", "fr", "de", "ja", "zh", "ar", "ru", "pt"
    };

    public void setStarListTags(@Nullable Map<String, String> starListTags) {
        this.starListTags = starListTags;
    }

    @Override
    protected int getLayoutId(int viewType) {
        return R.layout.layout_item_repository;
    }

    @NonNull
    @Override
    protected ViewHolder getViewHolder(@NonNull View itemView, int viewType) {
        ViewHolder holder = new ViewHolder(itemView);
        return holder;
    }

    public class ViewHolder extends BaseViewHolder {

        @BindView(R.id.iv_user_avatar) ImageView ivUserAvatar;
        @BindView(R.id.language_color) ImageView languageColor;
        @BindView(R.id.tv_repo_name) TextView tvRepoName;
        @BindView(R.id.tv_language) TextView tvLanguage;
        @BindView(R.id.tv_repo_description) TextView tvRepoDescription;
        @BindView(R.id.tv_translate_description) TextView tvTranslateDescription;
        String boundRepositoryKey;
        @BindView(R.id.tv_star_num) TextView tvStarNum;
        @BindView(R.id.tv_fork_num) TextView tvForkNum;
        @BindView(R.id.tv_owner_name) TextView tvOwnerName;
        @BindView(R.id.tv_since_star_num) TextView tvSinceStarNum;
        @BindView(R.id.since_star_lay) LinearLayout sinceStarLay;
        @BindView(R.id.owner_lay) LinearLayout ownerLay;
        @BindView(R.id.fork_mark) View forkMark;
        @BindView(R.id.tv_star_lists) TextView tvStarLists;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }

        @OnClick(R.id.iv_user_avatar)
        public void onUserClick(){
            if(getAdapterPosition() != RecyclerView.NO_POSITION){
                ProfileActivity.show((Activity) context, ivUserAvatar, data.get(getAdapterPosition()).getOwner().getLogin(),
                        data.get(getAdapterPosition()).getOwner().getAvatarUrl());
            }
        }

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        super.onBindViewHolder(holder, position);
        Repository repository = data.get(position);

        holder.boundRepositoryKey = repository.getFullName() == null
                ? repository.getName() : repository.getFullName();
        holder.tvTranslateDescription.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                showTranslationOptions(holder, repository);
            }
        });
        boolean hasOwnerAvatar = !StringUtils.isBlank(repository.getOwner().getAvatarUrl());
        holder.tvRepoName.setText(hasOwnerAvatar ? repository.getName(): repository.getFullName());
        ViewUtils.setTextView(holder.tvRepoDescription, repository.getDescription());

        holder.tvRepoDescription.setText(repository.getDescription());
        holder.tvTranslateDescription.setVisibility(
                StringUtils.isBlank(repository.getDescription()) ? View.GONE : View.VISIBLE);
        holder.tvTranslateDescription.setText("Translate");
        holder.tvTranslateDescription.setEnabled(true);
        holder.tvStarNum.setText(String.valueOf(repository.getStargazersCount()));
        holder.tvForkNum.setText(String.valueOf(repository.getForksCount()));
        holder.tvOwnerName.setText(repository.getOwner().getLogin());

        if(StringUtils.isBlank(repository.getLanguage())){
            holder.tvLanguage.setText("");
            holder.languageColor.setVisibility(View.INVISIBLE);
        } else {
            holder.languageColor.setVisibility(View.VISIBLE);
            holder.tvLanguage.setText(repository.getLanguage());
            int languageColor = LanguageColorsHelper.INSTANCE.getColor(context, repository.getLanguage());
            holder.languageColor.setImageTintList(ColorStateList.valueOf(languageColor));
        }


        if(hasOwnerAvatar){
            holder.ivUserAvatar.setVisibility(View.VISIBLE);
            holder.ownerLay.setVisibility(View.VISIBLE);
            holder.sinceStarLay.setVisibility(View.GONE);
            GlideApp.with(fragment)
                    .load(repository.getOwner().getAvatarUrl())
                    .onlyRetrieveFromCache(!PrefUtils.isLoadImageEnable())
                    .into(holder.ivUserAvatar);
        } else {
            holder.ivUserAvatar.setVisibility(View.GONE);
            holder.ownerLay.setVisibility(View.GONE);
            if (repository.getSinceStargazersCount() == 0) {
                holder.sinceStarLay.setVisibility(View.INVISIBLE);
            } else {
                holder.sinceStarLay.setVisibility(View.VISIBLE);
                switch (repository.getSince()) {
                    case Daily:
                        holder.tvSinceStarNum.setText(String.format(getString(R.string.star_num_today),
                                repository.getSinceStargazersCount()));
                        break;
                    case Weekly:
                        holder.tvSinceStarNum.setText(String.format(getString(R.string.star_num_this_week),
                                repository.getSinceStargazersCount()));
                        break;
                    case Monthly:
                        holder.tvSinceStarNum.setText(String.format(getString(R.string.star_num_this_month),
                                repository.getSinceStargazersCount()));
                        break;
                }
            }
        }

        holder.forkMark.setVisibility(repository.isFork() ? View.VISIBLE : View.GONE);

        String starListTag = null;
        if (starListTags != null && repository.getFullName() != null) {
            starListTag = starListTags.get(repository.getFullName());
        }
        if (StringUtils.isBlank(starListTag)) {
            holder.tvStarLists.setVisibility(View.GONE);
        } else {
            holder.tvStarLists.setVisibility(View.VISIBLE);
            holder.tvStarLists.setText(starListTag);
        }
    }

    private void showTranslationOptions(final ViewHolder holder, final Repository repository) {
        final String original = repository.getDescription();
        if (StringUtils.isBlank(original)) return;

        final android.content.SharedPreferences prefs =
                context.getSharedPreferences(TRANSLATION_PREFS, Context.MODE_PRIVATE);
        final String savedTarget = prefs.getString(TARGET_LANGUAGE_KEY, DEFAULT_TARGET_LANGUAGE);
        int checked = 0;
        for (int i = 0; i < TARGET_LANGUAGE_TAGS.length; i++) {
            if (TARGET_LANGUAGE_TAGS[i].equals(savedTarget)) {
                checked = i;
                break;
            }
        }

        new AlertDialog.Builder(context)
                .setTitle("Translate description to")
                .setSingleChoiceItems(TARGET_LANGUAGE_NAMES, checked,
                        new android.content.DialogInterface.OnClickListener() {
                            @Override public void onClick(android.content.DialogInterface dialog, int which) {
                                dialog.dismiss();
                                final String targetTag = TARGET_LANGUAGE_TAGS[which];
                                prefs.edit().putString(TARGET_LANGUAGE_KEY, targetTag).apply();
                                translateRepositoryDescription(holder, repository, original, targetTag);
                            }
                        })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void translateRepositoryDescription(final ViewHolder holder,
                                                final Repository repository,
                                                final String original,
                                                final String targetTag) {
        final String repoKey = repository.getFullName() == null
                ? repository.getName() : repository.getFullName();
        final String cacheKey = repoKey + "|" + targetTag;
        final String cached = translatedDescriptions.get(cacheKey);

        if (cached != null) {
            holder.tvRepoDescription.setText(cached);
            holder.tvTranslateDescription.setText("Show original");
            holder.tvTranslateDescription.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    holder.tvRepoDescription.setText(original);
                    holder.tvTranslateDescription.setText("Translate");
                    holder.tvTranslateDescription.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            showTranslationOptions(holder, repository);
                        }
                    });
                }
            });
            return;
        }

        holder.tvTranslateDescription.setEnabled(false);
        holder.tvTranslateDescription.setText("Translating…");
        RepoTranslationHelper.translate(context, original, targetTag,
                new RepoTranslationHelper.Callback() {
                    @Override public void onSuccess(String translatedText) {
                        if (!repoKey.equals(holder.boundRepositoryKey)) return;
                        translatedDescriptions.put(cacheKey, translatedText);
                        holder.tvRepoDescription.setText(translatedText);
                        holder.tvTranslateDescription.setEnabled(true);
                        holder.tvTranslateDescription.setText("Show original");
                        holder.tvTranslateDescription.setOnClickListener(new View.OnClickListener() {
                            @Override public void onClick(View v) {
                                holder.tvRepoDescription.setText(original);
                                holder.tvTranslateDescription.setText("Translate");
                                holder.tvTranslateDescription.setOnClickListener(new View.OnClickListener() {
                                    @Override public void onClick(View v) {
                                        showTranslationOptions(holder, repository);
                                    }
                                });
                            }
                        });
                    }

                    @Override public void onFailure(String message) {
                        if (!repoKey.equals(holder.boundRepositoryKey)) return;
                        holder.tvRepoDescription.setText(original);
                        holder.tvTranslateDescription.setEnabled(true);
                        holder.tvTranslateDescription.setText("Translate");
                        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
                    }
                });
    }

}
