package com.thirtydegreesray.openhub.util;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.Locale;

/**
 * Detects the source language and translates repository descriptions on-device.
 * Translation models are downloaded on demand by ML Kit and can then work offline.
 */
public final class RepoTranslationHelper {

    public interface Callback {
        void onSuccess(String translatedText);
        void onFailure(String message);
    }

    private RepoTranslationHelper() { }

    public static void translate(@NonNull Context context,
                                 @NonNull final String sourceText,
                                 @NonNull final String targetLanguageTag,
                                 @NonNull final Callback callback) {
        if (TextUtils.isEmpty(sourceText.trim())) {
            callback.onFailure("There is no description to translate.");
            return;
        }

        final String targetLanguage = TranslateLanguage.fromLanguageTag(targetLanguageTag);
        if (TextUtils.isEmpty(targetLanguage)) {
            callback.onFailure("This target language is not supported.");
            return;
        }

        final LanguageIdentifier identifier = LanguageIdentification.getClient();
        identifier.identifyLanguage(sourceText)
                .addOnSuccessListener(new OnSuccessListener<String>() {
                    @Override public void onSuccess(String detectedTag) {
                        identifier.close();
                        String sourceLanguage = TranslateLanguage.fromLanguageTag(detectedTag);
                        if (TextUtils.isEmpty(sourceLanguage)) {
                            callback.onFailure("Could not identify this language. Try a longer description.");
                            return;
                        }
                        if (sourceLanguage.equals(targetLanguage)) {
                            callback.onSuccess(sourceText);
                            return;
                        }
                        startTranslation(sourceText, sourceLanguage, targetLanguage, callback);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override public void onFailure(Exception e) {
                        identifier.close();
                        callback.onFailure("Language detection failed: " + safeMessage(e));
                    }
                });
    }

    private static void startTranslation(final String text,
                                         String sourceLanguage,
                                         String targetLanguage,
                                         final Callback callback) {
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(sourceLanguage)
                .setTargetLanguage(targetLanguage)
                .build();
        final Translator translator = Translation.getClient(options);

        translator.downloadModelIfNeeded(new DownloadConditions.Builder().build())
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override public void onSuccess(Void unused) {
                        translator.translate(text)
                                .addOnSuccessListener(new OnSuccessListener<String>() {
                                    @Override public void onSuccess(String result) {
                                        translator.close();
                                        callback.onSuccess(result);
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override public void onFailure(Exception e) {
                                        translator.close();
                                        callback.onFailure("Translation failed: " + safeMessage(e));
                                    }
                                });
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override public void onFailure(Exception e) {
                        translator.close();
                        callback.onFailure("Could not download translation model: " + safeMessage(e));
                    }
                });
    }

    private static String safeMessage(Exception e) {
        if (e == null || TextUtils.isEmpty(e.getLocalizedMessage())) {
            return "Please check your internet connection and try again.";
        }
        return e.getLocalizedMessage();
    }
}
