package com.thirtydegreesray.openhub.ui.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.ClipData;
import android.content.ClipboardManager;

import com.thirtydegreesray.openhub.AppConfig;
import com.thirtydegreesray.openhub.AppData;
import com.thirtydegreesray.openhub.http.RepoService;
import com.thirtydegreesray.openhub.http.core.AppRetrofit;
import com.thirtydegreesray.openhub.mvp.model.WorkflowFileUpdate;
import com.thirtydegreesray.openhub.ui.widget.YamlLanguage;

import java.nio.charset.Charset;

import okhttp3.ResponseBody;
import retrofit2.Response;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import tiiehenry.code.language.LanguageNonProg;
import tiiehenry.code.view.CodeEditor;
import tiiehenry.code.view.ColorSchemeLight;

/** Full-screen editor page for workflow YAML and GitHub Actions logs. */
public class CodeEditorActivity extends Activity {
    private static final String MODE_WORKFLOW = "workflow";
    private static final String MODE_LOG = "log";
    private CodeEditor editor;
    private TextView status;
    private String owner, repo, branch, path, sha, mode;
    private RepoService service;

    public static void openWorkflow(Activity a, String owner, String repo, String branch,
                                    String path, String sha, String content) {
        a.startActivity(new android.content.Intent(a, CodeEditorActivity.class)
                .putExtra("mode", MODE_WORKFLOW).putExtra("owner", owner)
                .putExtra("repo", repo).putExtra("branch", branch)
                .putExtra("path", path).putExtra("sha", sha).putExtra("content", content));
    }

    public static void openLogs(Activity a, String title, String content) {
        a.startActivity(new android.content.Intent(a, CodeEditorActivity.class)
                .putExtra("mode", MODE_LOG).putExtra("title", title)
                .putExtra("content", content));
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        mode = getIntent().getStringExtra("mode");
        owner = getIntent().getStringExtra("owner");
        repo = getIntent().getStringExtra("repo");
        branch = getIntent().getStringExtra("branch");
        path = getIntent().getStringExtra("path");
        sha = getIntent().getStringExtra("sha");
        boolean workflow = MODE_WORKFLOW.equals(mode);
        String titleText = workflow ? "Workflow YAML Editor" : getIntent().getStringExtra("title");
        String content = getIntent().getStringExtra("content");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF5F5F5);
        int pad = dp(12);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText(titleText == null ? "Code Editor" : titleText);
        title.setTextSize(20);
        title.setTextColor(0xFF202124);
        title.setPadding(dp(4), dp(4), dp(4), dp(8));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText(workflow ? owner + "/" + repo + " · " + branch + "\n" + path
                : "GitHub Actions · Read-only log");
        subtitle.setTextSize(12);
        subtitle.setTextColor(0xFF666666);
        subtitle.setPadding(dp(4), 0, dp(4), dp(8));
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        Button undo = button("Undo");
        Button redo = button("Redo");
        Button copy = button("Copy");
        bar.addView(undo, new LinearLayout.LayoutParams(0, -2, 1));
        bar.addView(redo, new LinearLayout.LayoutParams(0, -2, 1));
        bar.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        if (workflow) {
            Button save = button("Commit & Push");
            bar.addView(save, new LinearLayout.LayoutParams(0, -2, 1.35f));
            save.setOnClickListener(v -> confirmSave());
        }
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setText(workflow ? "Editable workflow file" : "Logs are read-only");
        status.setTextSize(12);
        status.setTextColor(0xFF666666);
        status.setPadding(dp(4), dp(5), dp(4), dp(5));
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        editor = new CodeEditor(this);
        editor.setColorScheme(new ColorSchemeLight());
        editor.setShowLineNumbers(true);
        editor.setHighlightCurrentRow(true);
        editor.setWordWrap(!workflow);
        editor.setTextSize(12);
        editor.setText(content == null ? "" : content);
        editor.setPadding(dp(8), dp(8), dp(8), dp(8));
        editor.setBackgroundColor(0xFFFFFFFF);
        if (workflow) {
            editor.setLanguage(YamlLanguage.getInstance());
        } else {
            editor.setLanguage(LanguageNonProg.getInstance());
            // Keep the editor's native touch handling so long logs can be scrolled.
            editor.setFocusable(false);
            editor.setFocusableInTouchMode(false);
        }
        root.addView(editor, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        undo.setEnabled(workflow);
        redo.setEnabled(workflow);
        undo.setOnClickListener(v -> editor.undo());
        redo.setOnClickListener(v -> editor.redo());
        copy.setOnClickListener(v -> copyAll());

        if (workflow) {
            service = AppRetrofit.INSTANCE.getRetrofit(AppConfig.GITHUB_API_BASE_URL,
                    AppData.INSTANCE.getAccessToken()).create(RepoService.class);
        }
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }

    private void copyAll() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Editor content", editor.getString()));
        toast("Copied to clipboard");
    }

    private void confirmSave() {
        if (editor.getString().trim().length() == 0) {
            toast("Workflow YAML cannot be empty");
            return;
        }
        new AlertDialog.Builder(this).setTitle("Commit workflow changes?")
                .setMessage("Commit changes to " + path + " on " + branch + "?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Commit", (d, w) -> saveFile())
                .show();
    }

    private void saveFile() {
        status.setText("Committing workflow file…");
        String encoded = Base64.encodeToString(editor.getString().getBytes(Charset.forName("UTF-8")), Base64.NO_WRAP);
        WorkflowFileUpdate update = new WorkflowFileUpdate("Update workflow " + path, encoded, sha, branch);
        service.updateWorkflowFile(owner, repo, path, update)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe(response -> {
                    if (response.isSuccessful()) {
                        status.setText("Committed successfully");
                        toast("Workflow YAML committed and pushed");
                    } else {
                        String detail = "HTTP " + response.code();
                        try { ResponseBody b = response.errorBody(); if (b != null) detail += ": " + b.string(); }
                        catch (Exception ignored) { }
                        status.setText("Commit failed: " + detail);
                        toast("Commit failed: " + detail);
                    }
                }, error -> {
                    status.setText("Commit failed: " + error.getLocalizedMessage());
                    toast("Commit failed: " + error.getLocalizedMessage());
                });
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
}
