package com.akcreation.materialicons.activities;

import android.content.Intent;
import android.content.res.Configuration; // Naya import
import android.os.Build; // Naya import
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View; // Naya import
import android.view.Window; // Naya import
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat; // Naya import
import androidx.core.view.WindowInsetsControllerCompat; // Naya import

import com.akcreation.materialicons.R;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_TIMEOUT = 2000; // 2 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Naye feature ko call karein
        setStatusBarTextColor();

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashActivity.this, ProjectsActivity.class);
                startActivity(intent);
                finish();
            }
        }, SPLASH_TIMEOUT);
    }

    // --- YEH AAPKA NAYA METHOD HAI (MODERN VERSION) ---
    private void setStatusBarTextColor() {
        // Window object haasil karein
        Window window = getWindow();
        
        // Window Insets Controller ka istemal karein (yeh naya tareeka hai)
        WindowInsetsControllerCompat insetsController = WindowCompat.getInsetsController(window, window.getDecorView());
        
        // System ka current night mode check karein
        int nightMode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        boolean isDarkMode = (nightMode == Configuration.UI_MODE_NIGHT_YES);
        
        // Controller ko batayein ki status bar ke icons/text ka color kaisa hona chahiye
        // 'true' = Light (Dark text for light background)
        // 'false' = Dark (Light text for dark background)
        if (insetsController != null) {
            insetsController.setAppearanceLightStatusBars(!isDarkMode);
        }
    }
}