package com.akcreation.materialicons;

import android.app.Application;
import android.content.Context;
import androidx.appcompat.app.AppCompatDelegate;

import com.akcreation.materialicons.utils.CrashHandler;

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        
        // App shuru hote hi hamara crash handler set kar dein
        Thread.setDefaultUncaughtExceptionHandler(new CrashHandler(this));
        
    }
}