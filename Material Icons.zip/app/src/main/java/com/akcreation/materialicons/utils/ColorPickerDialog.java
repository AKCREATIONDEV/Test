package com.akcreation.materialicons.utils;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.PaintDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;

import com.akcreation.materialicons.R;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class ColorPickerDialog {

    public interface OnColorSelectedListener {
        void onColorSelected(int color);
    }

    private final Context context;
    private int initialColor;
    private final OnColorSelectedListener listener;
    private AlertDialog dialog;

    // UI Components
    private View colorSpectrumView;
    private ImageView colorSelector;
    private SeekBar hueSeekBar, alphaSeekBar;
    private EditText hexCodeEditText;
    private View colorPreview;

    private float[] currentHsv = new float[3];
    private int currentAlpha = 255;
    private boolean isEditingHex = false;

    public ColorPickerDialog(Context context, int initialColor, OnColorSelectedListener listener) {
        this.context = context;
        this.initialColor = initialColor;
        this.listener = listener;
        this.currentAlpha = Color.alpha(initialColor);
        Color.colorToHSV(initialColor, this.currentHsv);
    }

    public void show() {
        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(context);
        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.dialog_color_picker, null);

        setupUI(dialogView);
        setupListeners();
        updateUIFromColor(initialColor);

        builder.setView(dialogView)
               .setTitle("Select Color")
               .setPositiveButton("OK", (d, which) -> {
                   if (listener != null) {
                       listener.onColorSelected(getColor());
                   }
               })
               .setNegativeButton("Cancel", null);

        dialog = builder.create();
        dialog.show();
    }
    
    private void setupUI(View view) {
        colorSpectrumView = view.findViewById(R.id.color_spectrum_view);
        colorSelector = view.findViewById(R.id.color_selector);
        hueSeekBar = view.findViewById(R.id.hue_seek_bar);
        alphaSeekBar = view.findViewById(R.id.alpha_seek_bar);
        hexCodeEditText = view.findViewById(R.id.hex_code_edit_text);
        colorPreview = view.findViewById(R.id.color_preview);
        
        hueSeekBar.setMax(360);
        alphaSeekBar.setMax(255);

        // Create hue gradient for the hue seekbar
        int[] hueColors = new int[361];
        for (int i = 0; i < 361; i++) {
            hueColors[i] = Color.HSVToColor(new float[]{i, 1f, 1f});
        }
        PaintDrawable hueDrawable = new PaintDrawable();
        hueDrawable.setShape(new RectShape());
        hueDrawable.getPaint().setShader(new LinearGradient(0, 0, hueSeekBar.getWidth(), hueSeekBar.getHeight(), hueColors, null, Shader.TileMode.CLAMP));
        hueSeekBar.setProgressDrawable(hueDrawable);
    }

    private void setupListeners() {
        hueSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    currentHsv[0] = progress;
                    updateSpectrumAndColor();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        alphaSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(fromUser) {
                    currentAlpha = progress;
                    updateUIFromColor(getColor());
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        colorSpectrumView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE) {
                float x = Math.max(0, Math.min(event.getX(), v.getWidth()));
                float y = Math.max(0, Math.min(event.getY(), v.getHeight()));

                currentHsv[1] = x / v.getWidth(); // Saturation
                currentHsv[2] = 1 - (y / v.getHeight()); // Value

                // Move selector
                colorSelector.setX(x - (colorSelector.getWidth() / 2f));
                colorSelector.setY(y - (colorSelector.getHeight() / 2f));

                updateUIFromColor(getColor());
                return true;
            }
            return false;
        });

        hexCodeEditText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                if(isEditingHex) return;
                try {
                    if (s.length() == 7 || s.length() == 9) { // #RRGGBB or #AARRGGBB
                        int color = Color.parseColor(s.toString());
                        updateUIFromColor(color);
                    }
                } catch (IllegalArgumentException e) {
                    // Invalid hex code, do nothing
                }
            }
        });
    }
    
    private void updateSpectrumAndColor() {
        // Update the main color spectrum view based on the selected hue
        int startColor = Color.HSVToColor(new float[]{currentHsv[0], 0f, 1f}); // White
        int endColor = Color.HSVToColor(new float[]{currentHsv[0], 1f, 1f});   // Full saturation
        
        LinearGradient saturationGradient = new LinearGradient(0, 0, colorSpectrumView.getWidth(), 0, startColor, endColor, Shader.TileMode.CLAMP);
        LinearGradient valueGradient = new LinearGradient(0, 0, 0, colorSpectrumView.getHeight(), Color.TRANSPARENT, Color.BLACK, Shader.TileMode.CLAMP);
        // This part is tricky without a custom view. A simple gradient will suffice for now.
        colorSpectrumView.setBackground(new PaintDrawable(endColor));

        updateUIFromColor(getColor());
    }

    private void updateUIFromColor(int color) {
        Color.colorToHSV(color, currentHsv);
        currentAlpha = Color.alpha(color);

        // Update SeekBars
        hueSeekBar.setProgress((int) currentHsv[0]);
        alphaSeekBar.setProgress(currentAlpha);

        // Update Preview
        colorPreview.setBackgroundColor(color);

        // Update Hex Code
        isEditingHex = true;
        String hex = String.format("#%08X", color);
        hexCodeEditText.setText(hex);
        isEditingHex = false;
        
        // Update alpha seekbar gradient
        int solidColor = Color.HSVToColor(new float[]{currentHsv[0], currentHsv[1], currentHsv[2]});
        int transparentColor = Color.argb(0, Color.red(solidColor), Color.green(solidColor), Color.blue(solidColor));
        PaintDrawable alphaDrawable = new PaintDrawable();
        alphaDrawable.setShape(new RectShape());
        alphaDrawable.getPaint().setShader(new LinearGradient(0,0, alphaSeekBar.getWidth(), 0, transparentColor, solidColor, Shader.TileMode.CLAMP));
        alphaSeekBar.setProgressDrawable(alphaDrawable);

        // update spectrum view (this is an approximation)
        updateSpectrumAndColor();

        // Update selector position
        if(colorSpectrumView.getWidth() > 0){
             float x = currentHsv[1] * colorSpectrumView.getWidth();
             float y = (1 - currentHsv[2]) * colorSpectrumView.getHeight();
             colorSelector.setX(x - (colorSelector.getWidth() / 2f));
             colorSelector.setY(y - (colorSelector.getHeight() / 2f));
        }
    }

    private int getColor() {
        return Color.HSVToColor(currentAlpha, currentHsv);
    }
}