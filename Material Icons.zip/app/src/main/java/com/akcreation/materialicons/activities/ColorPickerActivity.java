package com.akcreation.materialicons.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.ColorInt;
import androidx.appcompat.app.AppCompatActivity;

import com.akcreation.colorpicker.ColorPickerDialog;
import com.akcreation.colorpicker.ColorPickerDialogListener;

public class ColorPickerActivity extends AppCompatActivity implements ColorPickerDialogListener {

    // Yeh keys Intent ke saath data bhejne aur receive karne ke liye hain
    public static final String EXTRA_COLOR = "extra_initial_color";
    public static final String RESULT_COLOR = "result_selected_color";

    // Color Picker Dialog ke liye ek unique ID
    private static final int COLOR_PICKER_DIALOG_ID = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Intent se shuruaati color (initial color) haasil karein
        int initialColor = getIntent().getIntExtra(EXTRA_COLOR, 0);

        // Color Picker Dialog banayein aur dikhayein
        ColorPickerDialog.newBuilder()
            .setDialogId(COLOR_PICKER_DIALOG_ID)
            .setColor(initialColor) // Shuruaati color set karein
            .setShowAlphaSlider(true) // Transparency (alpha) slider dikhayein
            .show(this); // Is activity (ColorPickerActivity) par dialog dikhayein
    }

    /**
     * Yeh method tab call hota hai jab user color select karke "Select" (ya "OK") par click karta hai.
     * @param dialogId Dialog ki ID (humne 0 set ki hai).
     * @param color Chuna hua color (integer format mein).
     */
    @Override
    public void onColorSelected(int dialogId, @ColorInt int color) {
        // Ek naya Intent banayein result waapas bhejne ke liye
        Intent resultIntent = new Intent();
        // Chune hue color ko Intent mein daalein
        resultIntent.putExtra(RESULT_COLOR, color);
        // Result ko 'OK' set karein aur Intent waapas bhej dein
        setResult(Activity.RESULT_OK, resultIntent);
        // Activity ko band kar dein
        finish();
    }

    /**
     * Yeh method tab call hota hai jab user "Cancel" par click karta hai ya dialog ko dismiss karta hai.
     * @param dialogId Dialog ki ID.
     */
    @Override
    public void onDialogDismissed(int dialogId) {
        // Result ko 'CANCELED' set karein (optional)
        setResult(Activity.RESULT_CANCELED);
        // Activity ko band kar dein
        finish();
    }
}