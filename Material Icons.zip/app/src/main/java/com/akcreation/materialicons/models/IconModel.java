package com.akcreation.materialicons.models;

public class IconModel {
    private final String name;      // Cleaned Name (Display ke liye)
    private final String pathInZip; // Unique Key (IconDataHolder se data lene ke liye)

    public IconModel(String rawName, String pathInZip) {
        // Constructor mein hi naam ko saaf kar lete hain taaki baar-baar process na karna pade
        this.name = sanitizeName(rawName);
        this.pathInZip = pathInZip;
    }

    private String sanitizeName(String rawName) {
        if (rawName == null) return "";
        
        // Path se filename nikalo (e.g., "action/ic_android_24px.svg" -> "ic_android_24px.svg")
        String baseName = rawName.contains("/") 
                ? rawName.substring(rawName.lastIndexOf('/') + 1) 
                : rawName;

        // Extension hatao (.svg)
        if (baseName.endsWith(".svg")) {
            baseName = baseName.substring(0, baseName.length() - 4);
        }

        // Suffix hatao (_24px)
        if (baseName.contains("_24px")) {
            baseName = baseName.replace("_24px", "");
        }
        
        return baseName;
    }

    public String getName() {
        return name;
    }

    public String getPathInZip() {
        return pathInZip;
    }
}
