package com.akcreation.materialicons.utils;

import android.content.Context;
import android.content.Intent;
import com.akcreation.materialicons.activities.CrashActivity;
import java.io.PrintWriter;
import java.io.StringWriter;

public class CrashHandler implements Thread.UncaughtExceptionHandler {

    private final Context context;

    public CrashHandler(Context context) {
        this.context = context;
    }

    @Override
    public void uncaughtException(Thread thread, Throwable ex) {
        // Exception ko String mein convert karein
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        ex.printStackTrace(pw);
        String stackTrace = sw.toString();

        // CrashActivity ko launch karein
        Intent intent = new Intent(context, CrashActivity.class);
        intent.putExtra(CrashActivity.EXTRA_CRASH_LOG, stackTrace);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);

        // App ko aaraam se band karein
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(10);
    }
}