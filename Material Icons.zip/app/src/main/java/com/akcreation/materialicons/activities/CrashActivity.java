package com.akcreation.materialicons.activities;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.akcreation.materialicons.R;

public class CrashActivity extends AppCompatActivity {

    public static final String EXTRA_CRASH_LOG = "extra_crash_log";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crash);

        // UI elements ko link karein
        TextView errorDetailsTextView = findViewById(R.id.crash_log_textview);
        Button copyButton = findViewById(R.id.copy_button);
        Button restartButton = findViewById(R.id.restart_button);

        // Intent se crash log haasil karein
        String errorLog = getIntent().getStringExtra(EXTRA_CRASH_LOG);
        errorDetailsTextView.setText(errorLog);

        // Copy button ka logic
        copyButton.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("Crash Log", errorLog);
            if (clipboard != null) {
                clipboard.setPrimaryClip(clip);
                Toast.makeText(this, "Log copied to clipboard", Toast.LENGTH_SHORT).show();
            }
        });

        // Restart button ka logic
        restartButton.setOnClickListener(v -> {
            restartApp();
        });
    }

    private void restartApp() {
        PackageManager pm = getPackageManager();
        Intent intent = pm.getLaunchIntentForPackage(getPackageName());
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            // Puraani process ko band kar dein
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(10);
        }
    }
}