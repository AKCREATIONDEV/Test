package com.akcreation.materialicons.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.AttrRes;
import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.akcreation.materialicons.R;
import com.akcreation.materialicons.adapters.IconAdapter;
import com.akcreation.materialicons.models.IconModel;
import com.akcreation.materialicons.utils.Converter;
import com.akcreation.materialicons.utils.Filter;
import com.akcreation.materialicons.utils.IconDataHolder; // Naya DataHolder Import
import com.akcreation.materialicons.activities.AboutDialog;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.akcreation.materialicons.utils.RecyclerViewFastScroller;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class IconBrowserActivity extends AppCompatActivity {

    // UI Elements
    private RecyclerView recyclerView;
    private ImageButton filterButton;
    private ImageButton infoButton;

    // Adapters and Data
    private IconAdapter adapter;
    private List<IconModel> iconList = new ArrayList<>();
    private Map<String, List<IconModel>> categorizedIcons;
    private String[] categoryArray;
    private boolean[] checkedItems;
    private ArrayList<String> selectedCategories = new ArrayList<>();

    // First Scroller view ke liye
    private RecyclerViewFastScroller fastScroller;

    // File and Path
    // ZipFile hata diya gaya hai
    private String projectPath;

    // Export Dialog ke liye Color Management
    private int selectedColor;
    private boolean isUpdatingByCode = false;

    // Activity Result Launcher
    private ActivityResultLauncher<Intent> colorPickerLauncher;

    // Dialog ke UI elements ko hold karne ke liye
    private View activeColorPreview;
    private EditText activeHexEditText;

    // Custom size ke liye
    private static final String CUSTOM_SIZE_OPTION = "Custom";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_icon_browser);

        // Status bar text color automatically set karein
        setStatusBarTextColor();

        selectedColor = getThemeColor(this, android.R.attr.colorAccent);

        // Color Picker launcher ko register karein
        colorPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        int returnedColor = result.getData().getIntExtra(ColorPickerActivity.RESULT_COLOR, selectedColor);
                        selectedColor = returnedColor;
                        if (activeColorPreview != null && activeHexEditText != null) {
                            updateColorUI(activeColorPreview, activeHexEditText);
                        }
                    }
                }
        );

        projectPath = getIntent().getStringExtra("PROJECT_PATH");
        if (projectPath == null) {
            Toast.makeText(this, "Error: Project path not found.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setupToolbar();
        setupUI();
        setupRecyclerView();
        
        // ZIP ki jagah ab JSON load karenge
        loadIconsFromJson();
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        setStatusBarTextColor();
        if (adapter != null) {
            adapter.refreshTheme();
        }
    }

    private void setStatusBarTextColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Window window = getWindow();
            View decorView = window.getDecorView();
            int nightMode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            boolean isDarkMode = (nightMode == Configuration.UI_MODE_NIGHT_YES);
            int flags = decorView.getSystemUiVisibility();
            if (isDarkMode) {
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            } else {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            decorView.setSystemUiVisibility(flags);
        }
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void setupUI() {
        recyclerView = findViewById(R.id.recycler_view_icons);
        fastScroller = findViewById(R.id.fast_scroller);

        SearchView searchView = findViewById(R.id.search_view_icons);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (adapter != null) adapter.filter(newText);
                return true;
            }
        });

        filterButton = findViewById(R.id.filter_button);
        filterButton.setOnClickListener(v -> {
            if (categoryArray != null) showFilterDialog();
            else Toast.makeText(this, "Categories are loading...", Toast.LENGTH_SHORT).show();
        });

        infoButton = findViewById(R.id.info_button);
        infoButton.setOnClickListener(v -> showAppInfoDialog());
    }

    private void setupRecyclerView() {
        GridLayoutManager layoutManager = new GridLayoutManager(this, 5);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemViewCacheSize(20);
        recyclerView.setDrawingCacheEnabled(true);
        recyclerView.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);
    }

    @ColorInt
    private int getThemeColor(@NonNull Context context, @AttrRes int attr) {
        TypedValue typedValue = new TypedValue();
        if (context.getTheme().resolveAttribute(attr, typedValue, true)) {
            return typedValue.data;
        }
        return Color.BLACK;
    }

    private void showAppInfoDialog() {
        AboutDialog dialog = new AboutDialog(this);
        dialog.show();
    }

    // --- NEW METHOD: JSON se data load karna ---
    private void loadIconsFromJson() {
        new Thread(() -> {
            try {
                // Check karein agar data pehle se loaded hai
                if (!IconDataHolder.isEmpty() && !iconList.isEmpty()) {
                     // Data already exists, just refresh list if needed
                     return;
                }

                // 1. JSON File Read Karein
                // File name wahi hona chahiye jo assets mein hai
                InputStream is = getAssets().open("icons.json");
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                StringBuilder jsonBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    jsonBuilder.append(line);
                }
                reader.close();

                // 2. Data Parse aur Store Karein
                JSONObject rootObject = new JSONObject(jsonBuilder.toString());
                Iterator<String> categories = rootObject.keys();

                IconDataHolder.clear(); // Safai
                iconList.clear();

                while (categories.hasNext()) {
                    String categoryName = categories.next();
                    JSONObject categoryContent = rootObject.getJSONObject(categoryName);
                    Iterator<String> fileNames = categoryContent.keys();

                    while (fileNames.hasNext()) {
                        String fileName = fileNames.next();
                        JSONObject fileDetails = categoryContent.getJSONObject(fileName);

                        // Content nikalein
                        String svgCode = fileDetails.optString("content", "");
                        
                        // Unique path banayein
                        String uniquePath = categoryName + "/" + fileName;

                        // Heavy Data ko DataHolder mein daalein
                        IconDataHolder.putSvg(uniquePath, svgCode);

                        // Lightweight Model list mein daalein
                        iconList.add(new IconModel(fileName, uniquePath));
                    }
                }
                
                Collections.sort(iconList, (o1, o2) -> o1.getName().compareTo(o2.getName()));

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(this, "Error loading JSON: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }

            runOnUiThread(() -> {
                categorizedIcons = Filter.groupIconsByCategory(iconList);
                categoryArray = categorizedIcons.keySet().toArray(new String[0]);
                checkedItems = new boolean[categoryArray.length];
                
                // Adapter mein ab ZipFile ki jagah NULL pass karein
                adapter = new IconAdapter(this, iconList, null, this::showExportPopupMenu);
                recyclerView.setAdapter(adapter);

                if (fastScroller != null) {
                    fastScroller.attachFastScrollerToRecyclerView(recyclerView);
                }
                Toast.makeText(this, "Loaded " + iconList.size() + " icons.", Toast.LENGTH_SHORT).show();
            });
        }).start();
    }

    private void showFilterDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Filter by Category");
        Arrays.fill(checkedItems, false);
        for (int i = 0; i < categoryArray.length; i++) {
            if (selectedCategories.contains(categoryArray[i])) {
                checkedItems[i] = true;
            }
        }
        builder.setMultiChoiceItems(categoryArray, checkedItems, (dialog, which, isChecked) -> {
            String category = categoryArray[which];
            if (isChecked) selectedCategories.add(category);
            else selectedCategories.remove(category);
        });
        builder.setPositiveButton("Apply", (dialog, which) -> adapter.filterByCategories(selectedCategories));
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.setNeutralButton("Clear", (dialog, which) -> {
            selectedCategories.clear();
            adapter.filterByCategories(null);
        });
        builder.create().show();
    }

    private void showExportPopupMenu(IconModel icon) {
        int position = -1;
        for (int i = 0; i < adapter.getItemCount(); i++) {
            if (adapter.getIconAt(i) == icon) {
                position = i;
                break;
            }
        }
        RecyclerView.ViewHolder viewHolder = recyclerView.findViewHolderForAdapterPosition(position);
        View anchorView = (viewHolder != null) ? viewHolder.itemView : findViewById(R.id.filter_button);
        PopupMenu popupMenu = new PopupMenu(this, anchorView);
        popupMenu.getMenuInflater().inflate(R.menu.menu_export_options, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.export_svg) {
                showExportDialog(icon, "svg");
            } else if (itemId == R.id.export_vector) {
                showExportDialog(icon, "vector");
            } else if (itemId == R.id.export_png) {
                showExportDialog(icon, "png");
            }
            return true;
        });
        popupMenu.show();
    }

    private void showExportDialog(IconModel icon, String format) {
        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_export, null);
        builder.setView(dialogView);
        builder.setTitle("Add to project");

        // 1. Asli Color Detect Karein (Ab DataHolder se)
        selectedColor = getOriginalIconColor(icon);

        final EditText nameEditText = dialogView.findViewById(R.id.edit_text_icon_name);
        activeColorPreview = dialogView.findViewById(R.id.view_color_preview);
        activeHexEditText = dialogView.findViewById(R.id.edit_text_color_hex);
        final AutoCompleteTextView sizeSpinner = dialogView.findViewById(R.id.spinner_icon_size);
        final CheckBox adaptiveCheckBox = dialogView.findViewById(R.id.checkbox_adaptive_icon);

        String iconBaseName = icon.getName().startsWith("ic_") ? icon.getName() : "ic_" + icon.getName();
        String extension = format.equals("png") ? ".png" : (format.equals("svg") ? ".svg" : ".xml");
        nameEditText.setText(iconBaseName + extension);

        String[] sizes = {"24dp", "36dp", "48dp", "72dp", "96dp", CUSTOM_SIZE_OPTION};
        ArrayAdapter<String> sizeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, sizes);
        sizeSpinner.setAdapter(sizeAdapter);
        sizeSpinner.setText(sizes[0], false);

        sizeSpinner.setOnItemClickListener((parent, view, position, id) -> {
            String selectedSize = (String) parent.getItemAtPosition(position);
            if (CUSTOM_SIZE_OPTION.equals(selectedSize)) {
                showCustomSizeDialog(sizeSpinner);
            }
        });

        // 2. UI Update karein (Naye detected color ke saath)
        updateColorUI(activeColorPreview, activeHexEditText);

        View.OnClickListener clickListener = v -> {
            Intent intent = new Intent(this, ColorPickerActivity.class);
            intent.putExtra(ColorPickerActivity.EXTRA_COLOR, selectedColor);
            colorPickerLauncher.launch(intent);
        };
        activeColorPreview.setOnClickListener(clickListener);
        activeHexEditText.setOnClickListener(clickListener);

        activeHexEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (isUpdatingByCode) return;
                String hex = s.toString();
                if (hex.startsWith("#") && (hex.length() == 7 || hex.length() == 9)) {
                    try {
                        int color = Color.parseColor(hex);
                        selectedColor = color;
                        isUpdatingByCode = true;
                        activeColorPreview.setBackgroundColor(selectedColor);
                        isUpdatingByCode = false;
                    } catch (IllegalArgumentException e) {}
                }
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.setPositiveButton("Add", (dialog, which) -> {
            String fileName = nameEditText.getText().toString();
            if (fileName.isEmpty()) {
                Toast.makeText(this, "File name cannot be empty.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (fileName.contains(".")) fileName = fileName.substring(0, fileName.lastIndexOf('.'));

            String selectedSizeStr = sizeSpinner.getText().toString();
            if (selectedSizeStr.isEmpty() || CUSTOM_SIZE_OPTION.equals(selectedSizeStr)) {
                Toast.makeText(this, "Please select a valid size.", Toast.LENGTH_SHORT).show();
                return;
            }

            selectedSizeStr = selectedSizeStr.replace("dp", "").trim();
            int size;
            try {
                size = Integer.parseInt(selectedSizeStr);
                if (size <= 0 || size > 1024) {
                    Toast.makeText(this, "Size must be between 1 and 1024 dp.", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid size format.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean isAdaptive = adaptiveCheckBox.isChecked();
            exportIcon(icon, fileName, format, size, size, selectedColor, isAdaptive);
        });

        builder.setOnDismissListener(dialog -> {
            activeColorPreview = null;
            activeHexEditText = null;
        });
        builder.create().show();
    }

    private void showCustomSizeDialog(AutoCompleteTextView sizeSpinner) {
        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
        builder.setTitle("Custom Icon Size");

        final EditText input = new EditText(this);
        input.setHint("Enter size (e.g.,100)");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        int padding = (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, 20, getResources().getDisplayMetrics()
        );
        input.setPadding(padding, padding, padding, padding);

        builder.setView(input);

        builder.setPositiveButton("OK", (dialog, which) -> {
            String customSize = input.getText().toString().trim();
            if (!customSize.isEmpty()) {
                try {
                    int size = Integer.parseInt(customSize);
                    if (size > 0 && size <= 1024) {
                        sizeSpinner.setText(customSize + "dp", false);
                    } else {
                        Toast.makeText(this, "Size must be between 1 and 1024 dp.", Toast.LENGTH_SHORT).show();
                        sizeSpinner.setText("24dp", false);
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid size format.", Toast.LENGTH_SHORT).show();
                    sizeSpinner.setText("24dp", false);
                }
            } else {
                sizeSpinner.setText("24dp", false);
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> {
            sizeSpinner.setText("24dp", false);
            dialog.cancel();
        });

        builder.show();
    }

    private void updateColorUI(View colorPreview, EditText hexEditText) {
        isUpdatingByCode = true;
        colorPreview.setBackgroundColor(selectedColor);
        hexEditText.setText(String.format("#%08X", selectedColor));
        isUpdatingByCode = false;
    }

    // --- UPDATED EXPORT METHOD (Uses IconDataHolder) ---
    private void exportIcon(IconModel icon, String fileName, String format, int width, int height, int color, boolean isAdaptive) {
        new Thread(() -> {
            try {
                // 1. Memory se SVG nikalein
                String svgContent = IconDataHolder.getSvg(icon.getPathInZip());
                
                if (svgContent == null) {
                    throw new IOException("Icon data not found in memory!");
                }

                // 2. String ko Stream mein badlein
                InputStream is = new ByteArrayInputStream(svgContent.getBytes(StandardCharsets.UTF_8));
                
                // 3. Converter ko bhejein
                boolean success = Converter.exportIcon(this, is, projectPath, fileName, format, color, width, height, isAdaptive);
                
                runOnUiThread(() -> {
                    if (success) Toast.makeText(this, "Icon added successfully!", Toast.LENGTH_SHORT).show();
                    else Toast.makeText(this, "Failed to add icon.", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Memory Clear Karein
        IconDataHolder.clear();
    }

    // --- UPDATED COLOR DETECTION METHOD (Uses IconDataHolder) ---
    private int getOriginalIconColor(IconModel icon) {
        try {
            // Memory se SVG nikalein
            String svgContent = IconDataHolder.getSvg(icon.getPathInZip());
            if (svgContent == null) return Color.BLACK;

            // Regex se Hex Code dhoondhein (#RRGGBB ya #RGB)
            java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("#([0-9A-Fa-f]{8}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})");
            java.util.regex.Matcher matcher = pattern.matcher(svgContent);

            if (matcher.find()) {
                String hex = matcher.group();
                if (hex.length() == 4) {
                    char r = hex.charAt(1);
                    char g = hex.charAt(2);
                    char b = hex.charAt(3);
                    hex = "#" + r + r + g + g + b + b;
                }
                return Color.parseColor(hex);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Color.BLACK;
    }
}
