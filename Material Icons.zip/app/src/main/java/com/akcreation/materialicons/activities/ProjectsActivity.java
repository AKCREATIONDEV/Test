package com.akcreation.materialicons.activities;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.akcreation.materialicons.R;
import com.akcreation.materialicons.adapters.ProjectAdapter;
import com.akcreation.materialicons.models.ProjectModel;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ProjectsActivity extends AppCompatActivity {

    private static final int STORAGE_PERMISSION_CODE = 101;
    private static final int FOLDER_PICKER_CODE = 202;
    private RecyclerView recyclerView;
    private ProjectAdapter adapter;
    private List<ProjectModel> projectList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_projects);

        // Status bar text color setup
        setupStatusBar();

        recyclerView = findViewById(R.id.recycler_view_projects);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        
        adapter = new ProjectAdapter(this, projectList);
        recyclerView.setAdapter(adapter);

        SearchView searchView = findViewById(R.id.search_view);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override public boolean onQueryTextSubmit(String query) { return false; }
            @Override public boolean onQueryTextChange(String newText) {
                if (adapter != null) adapter.filter(newText);
                return true;
            }
        });
        
        ImageButton selectFolderButton = findViewById(R.id.select_folder_button);
        selectFolderButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            startActivityForResult(intent, FOLDER_PICKER_CODE);
        });

        checkPermissionsAndLoadProjects();
                // FIRST TIME APP OPEN -> Show About Dialog
        if (isFirstRun()) {
             AboutDialog dialog = new AboutDialog(this);
             dialog.show();
             setFirstRunDone();
        }
    }

    private boolean isFirstRun() {
        return getSharedPreferences("app_prefs", MODE_PRIVATE)
                .getBoolean("first_run", true);
    }

    private void setFirstRunDone() {
        getSharedPreferences("app_prefs", MODE_PRIVATE)
                .edit()
                .putBoolean("first_run", false)
                .apply();
    }

    private void setupStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Window window = getWindow();
            View decor = window.getDecorView();
            
            // Check if dark mode is enabled
            int nightModeFlags = getResources().getConfiguration().uiMode & 
                               android.content.res.Configuration.UI_MODE_NIGHT_MASK;
            
            if (nightModeFlags == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
                // Dark mode - White text on status bar
                decor.setSystemUiVisibility(0);
            } else {
                // Light mode - Black text on status bar
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }
    }

    private void checkPermissionsAndLoadProjects() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                loadProjects();
            } else {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                    intent.addCategory("android.intent.category.DEFAULT");
                    intent.setData(Uri.parse(String.format("package:%s", getApplicationContext().getPackageName())));
                    startActivityForResult(intent, STORAGE_PERMISSION_CODE);
                } catch (Exception e) {
                    Intent intent = new Intent();
                    intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                    startActivityForResult(intent, STORAGE_PERMISSION_CODE);
                }
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                loadProjects();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
            }
        }
    }

    private void loadProjects() {
        new Thread(() -> {
            List<ProjectModel> projects = new ArrayList<>();
            File projectsDir = new File(Environment.getExternalStorageDirectory(), "AndroidIDEProjects");
            if (projectsDir.exists() && projectsDir.isDirectory()) {
                File[] projectFiles = projectsDir.listFiles(File::isDirectory);
                if (projectFiles != null) {
                    for (File projectFile : projectFiles) {
                        projects.add(new ProjectModel(projectFile));
                    }
                }
            }
            
            runOnUiThread(() -> {
                if (projects.isEmpty()) {
                    Toast.makeText(this, "No projects found in AndroidIDEProjects folder.", Toast.LENGTH_SHORT).show();
                }
                projectList = projects;
                adapter.updateProjects(projectList);
            });
        }).start();
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    loadProjects();
                } else {
                    Toast.makeText(this, "Storage permission is required.", Toast.LENGTH_SHORT).show();
                }
            }
        } else if (requestCode == FOLDER_PICKER_CODE) {
             if (resultCode == Activity.RESULT_OK && data != null) {
                Uri treeUri = data.getData();
                if (treeUri != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        getContentResolver().takePersistableUriPermission(treeUri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    }
                    
                    String path = getPathFromTreeUri(treeUri);
                    if(path != null){
                        Intent intent = new Intent(this, IconBrowserActivity.class);
                        intent.putExtra("PROJECT_PATH", path);
                        startActivity(intent);
                    } else {
                        Toast.makeText(this, "Could not access the selected folder.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }

    private String getPathFromTreeUri(Uri treeUri) {
        String path = treeUri.getPath();
        if (path == null) return null;

        final String[] split = path.split(":");
        if (split.length > 1) {
            String relativePath = split[1];
            return new File(Environment.getExternalStorageDirectory(), relativePath).getAbsolutePath();
        }
        return null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadProjects();
            } else {
                Toast.makeText(this, "Permission denied. Cannot load projects.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}