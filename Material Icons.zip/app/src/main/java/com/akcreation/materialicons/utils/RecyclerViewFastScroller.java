package com.akcreation.materialicons.utils;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.akcreation.materialicons.R;
import androidx.annotation.DimenRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StyleRes;
import androidx.annotation.StyleableRes;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.content.ContextCompat;
import androidx.core.widget.TextViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Objects;

public class RecyclerViewFastScroller extends RelativeLayout {

    private static final String TAG = "RVFastScroller";
    private static final String ERROR_MESSAGE_NO_RECYCLER_VIEW = "The RecyclerView required for initialization with FastScroller cannot be null";

    // Enums
    public enum FastScrollDirection {
        VERTICAL(0), HORIZONTAL(1);

        final int value;
        FastScrollDirection(int value) { this.value = value; }

        public static FastScrollDirection getByValue(int value) {
            for (FastScrollDirection dir : values()) {
                if (dir.value == value) return dir;
            }
            return Defaults.fastScrollDirection;
        }
    }

    private enum PopupPosition {
        BEFORE_TRACK(0), AFTER_TRACK(1);

        final int value;
        PopupPosition(int value) { this.value = value; }

        public static PopupPosition getByValue(int value) {
            for (PopupPosition pos : values()) {
                if (pos.value == value) return pos;
            }
            return Defaults.popupPosition;
        }
    }

    // Defaults Class
    private static class Defaults {
        static final int popupDrawableInt = R.drawable.custom_bg_primary;
        static final int handleDrawableInt = R.drawable.custom_bg_primary;
        static final int handleSize = R.dimen.default_handle_size;
        static final int textStyle = R.style.FastScrollerTextAppearance;
        static final PopupPosition popupPosition = PopupPosition.BEFORE_TRACK;
        static final FastScrollDirection fastScrollDirection = FastScrollDirection.VERTICAL;
        static final boolean isFixedSizeHandle = false;
        static final boolean isFastScrollEnabled = true;
        static final long animationDuration = 100;
        static final long popupVisibilityDuration = 200L;
        static final boolean hasEmptyItemDecorator = true;
        static final int handleVisibilityDuration = 0;
        static final int trackMargin = 0;
    }

    // Views
    public TextView popupTextView;
    private AppCompatImageView handleImageView;
    private LinearLayout trackView;
    private RecyclerView recyclerView;

    // Configuration
    private boolean isFixedSizeHandle = Defaults.isFixedSizeHandle;
    private boolean isFastScrollEnabled = Defaults.isFastScrollEnabled;
    private boolean hasEmptyItemDecorator = Defaults.hasEmptyItemDecorator;
    private PopupPosition popupPosition = Defaults.popupPosition;
    private FastScrollDirection fastScrollDirection = Defaults.fastScrollDirection;
    private int handleVisibilityDuration = -1;
    
    private int handleWidth = ViewGroup.LayoutParams.WRAP_CONTENT;
    private int handleHeight = ViewGroup.LayoutParams.WRAP_CONTENT;
    private int trackMarginStart = 0;
    private int trackMarginEnd = 0;
    private int textStyle = Defaults.textStyle;

    // State
    private boolean isEngaged = false;
    private int previousTotalVisibleItem = 0;
    
    // Listeners & Handlers
    private HandleStateListener handleStateListener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable hideHandleRunnable;
    private final Runnable popupAnimationRunnable = () -> animateVisibility(popupTextView, false);

    // Constructors
    public RecyclerViewFastScroller(Context context) {
        this(context, null);
    }

    public RecyclerViewFastScroller(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public RecyclerViewFastScroller(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        addPopupLayout();
        addThumbAndTrack();

        if (attrs != null) {
            TypedArray attribs = context.getTheme().obtainStyledAttributes(attrs, R.styleable.RecyclerViewFastScroller, 0, 0);

            try {
                if (attribs.hasValue(R.styleable.RecyclerViewFastScroller_popupPosition)) {
                    popupPosition = PopupPosition.getByValue(attribs.getInt(R.styleable.RecyclerViewFastScroller_popupPosition, Defaults.popupPosition.value));
                }
                if (attribs.hasValue(R.styleable.RecyclerViewFastScroller_fastScrollDirection)) {
                    fastScrollDirection = FastScrollDirection.getByValue(attribs.getInt(R.styleable.RecyclerViewFastScroller_fastScrollDirection, Defaults.fastScrollDirection.value));
                }

                isFixedSizeHandle = attribs.getBoolean(R.styleable.RecyclerViewFastScroller_handleHasFixedSize, Defaults.isFixedSizeHandle);
                isFastScrollEnabled = attribs.getBoolean(R.styleable.RecyclerViewFastScroller_fastScrollEnabled, Defaults.isFastScrollEnabled);
                hasEmptyItemDecorator = attribs.getBoolean(R.styleable.RecyclerViewFastScroller_addLastItemPadding, Defaults.hasEmptyItemDecorator);

                Drawable trackDrawableRes = attribs.getDrawable(R.styleable.RecyclerViewFastScroller_trackDrawable);
                if (trackDrawableRes != null) {
                    trackView.setBackground(trackDrawableRes);
                }

                if (attribs.getBoolean(R.styleable.RecyclerViewFastScroller_supportSwipeToRefresh, false)) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        setNestedScrollingEnabled(true);
                    }
                }

                alignTrackAndHandle();
                alignPopupLayout();

                if (attribs.hasValue(R.styleable.RecyclerViewFastScroller_popupDrawable)) {
                    popupTextView.setBackground(attribs.getDrawable(R.styleable.RecyclerViewFastScroller_popupDrawable));
                } else {
                    popupTextView.setBackground(ContextCompat.getDrawable(context, Defaults.popupDrawableInt));
                }

                Drawable handleDrawableRes = attribs.getDrawable(R.styleable.RecyclerViewFastScroller_handleDrawable);
                if (handleDrawableRes != null) {
                    handleImageView.setImageDrawable(handleDrawableRes);
                } else {
                    handleImageView.setImageDrawable(ContextCompat.getDrawable(context, Defaults.handleDrawableInt));
                }

                handleVisibilityDuration = attribs.getInt(R.styleable.RecyclerViewFastScroller_handleVisibilityDuration, Defaults.handleVisibilityDuration);

                handleHeight = attribs.getDimensionPixelSize(R.styleable.RecyclerViewFastScroller_handleHeight, loadDimenFromResource(Defaults.handleSize));
                handleWidth = attribs.getDimensionPixelSize(R.styleable.RecyclerViewFastScroller_handleWidth, loadDimenFromResource(Defaults.handleSize));

                trackMarginStart = attribs.getDimensionPixelSize(R.styleable.RecyclerViewFastScroller_trackMarginStart, Defaults.trackMargin);
                trackMarginEnd = attribs.getDimensionPixelSize(R.styleable.RecyclerViewFastScroller_trackMarginEnd, Defaults.trackMargin);

                textStyle = attribs.getResourceId(R.styleable.RecyclerViewFastScroller_popupTextStyle, Defaults.textStyle);
                TextViewCompat.setTextAppearance(popupTextView, textStyle);

            } finally {
                attribs.recycle();
            }
        }
        post(() -> {
           handleImageView.setScaleX(0f);
           handleImageView.setScaleY(0f);
           popupTextView.setScaleX(0f);
           popupTextView.setScaleY(0f);
        });
    }

    // Public Properties setters/getters
    public void setTrackDrawable(Drawable drawable) {
        trackView.setBackground(drawable);
    }

    public Drawable getTrackDrawable() {
        return trackView.getBackground();
    }

    public void setPopupDrawable(Drawable drawable) {
        popupTextView.setBackground(drawable);
    }

    public Drawable getPopupDrawable() {
        return popupTextView.getBackground();
    }

    public void setHandleDrawable(@NonNull Drawable drawable) {
        handleImageView.setImageDrawable(drawable);
    }

    public Drawable getHandleDrawable() {
        return handleImageView.getDrawable();
    }

    public void setTextStyle(@StyleRes int styleRes) {
        this.textStyle = styleRes;
        TextViewCompat.setTextAppearance(popupTextView, styleRes);
    }

    public void setFastScrollEnabled(boolean enabled) {
        this.isFastScrollEnabled = enabled;
    }

    public boolean isFastScrollEnabled() {
        return isFastScrollEnabled;
    }

    public void setTrackMarginStart(int value) {
        this.trackMarginStart = value;
        setTrackMargin();
    }

    public void setTrackMarginEnd(int value) {
        this.trackMarginEnd = value;
        setTrackMargin();
    }

    public void setFastScrollDirection(FastScrollDirection direction) {
        this.fastScrollDirection = direction;
        alignTrackAndHandle();
    }

    public void setHandleWidth(int width) {
        this.handleWidth = width;
        refreshHandleImageViewSize(-1);
    }

    public void setHandleHeight(int height) {
        this.handleHeight = height;
        refreshHandleImageViewSize(-1);
    }
    
    public void setHandleVisibilityDuration(int duration) {
        this.handleVisibilityDuration = duration;
    }

    // Lifecycle methods
    @Override
    protected void onDetachedFromWindow() {
        detachFastScrollerFromRecyclerView();
        super.onDetachedFromWindow();
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        if (getChildCount() > 2) {
            for (int i = 2; i < getChildCount(); i++) {
                View currentView = getChildAt(i);
                if (currentView instanceof RecyclerView) {
                    removeView(currentView);
                    addView(currentView, 0);
                    attachFastScrollerToRecyclerView((RecyclerView) currentView);
                }
            }
        }

        post(() -> {
            OnTouchListener touchListener = (v, motionEvent) -> {
                int[] locationArray = new int[2];
                trackView.getLocationInWindow(locationArray);
                int xAbsPosition = locationArray[0];
                int yAbsPosition = locationArray[1];

                int touchAction = motionEvent.getActionMasked();

                switch (touchAction) {
                    case MotionEvent.ACTION_DOWN:
                    case MotionEvent.ACTION_MOVE:
                        requestDisallowInterceptTouchEvent(true);

                        if (touchAction == MotionEvent.ACTION_DOWN) {
                            if (recyclerView.getAdapter() != null) {
                                try {
                                    // Adapter might not be registered yet if initialized late
                                    // Java doesn't have easy check for anonymous class registration, 
                                    // so we rely on logic that attach registers it.
                                } catch (Exception e) {
                                    registerDataObserver();
                                }
                            }
                            isEngaged = true;
                            if (isFastScrollEnabled) {
                                if (handleStateListener != null) handleStateListener.onEngaged();
                                animateVisibility(popupTextView, true);
                            }
                        }

                        float handleOffset = getHandleLength() / 2;
                        float currentRelativePos;

                        if (fastScrollDirection == FastScrollDirection.HORIZONTAL) {
                            currentRelativePos = motionEvent.getRawX() - xAbsPosition - handleOffset;
                        } else {
                            currentRelativePos = motionEvent.getRawY() - yAbsPosition - handleOffset;
                        }

                        if (isFastScrollEnabled) {
                            moveHandle(currentRelativePos);
                            int position = computePositionForOffsetAndScroll(recyclerView, currentRelativePos);
                            
                            if (touchAction == MotionEvent.ACTION_MOVE) {
                                if (handleStateListener != null) {
                                    float currentPos = (fastScrollDirection == FastScrollDirection.HORIZONTAL) ? handleImageView.getX() : handleImageView.getY();
                                    handleStateListener.onDragged(currentPos, position);
                                }
                            }
                            
                            int itemCount = (recyclerView.getAdapter() != null) ? recyclerView.getAdapter().getItemCount() : 0;
                            updateTextInPopup(Math.min(itemCount - 1, position));
                        } else {
                            // Non-fast scroll fallback
                             if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {
                                if (((LinearLayoutManager) recyclerView.getLayoutManager()).getOrientation() == RecyclerView.HORIZONTAL) {
                                    recyclerView.scrollBy((int) currentRelativePos, 0);
                                } else {
                                    recyclerView.scrollBy(0, (int) currentRelativePos);
                                }
                             }
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        isEngaged = false;
                        if (isFastScrollEnabled) {
                            if (handleStateListener != null) handleStateListener.onReleased();
                            handler.postDelayed(popupAnimationRunnable, Defaults.popupVisibilityDuration);
                        }
                        // Super onTouchEvent can be called if needed, but returning true usually
                        return true;
                }
                return false;
            };

            handleImageView.setOnTouchListener(touchListener);
            trackView.setOnTouchListener(touchListener);
        });
    }

    // Logic Methods
    private void alignPopupLayout() {
        LayoutParams lp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        
        if (popupPosition == PopupPosition.BEFORE_TRACK) {
            if (fastScrollDirection == FastScrollDirection.HORIZONTAL) {
                lp.addRule(RelativeLayout.ABOVE, trackView.getId());
            } else {
                if (Build.VERSION.SDK_INT > 16) lp.addRule(RelativeLayout.START_OF, trackView.getId());
                else lp.addRule(RelativeLayout.LEFT_OF, trackView.getId());
            }
        } else {
            if (fastScrollDirection == FastScrollDirection.HORIZONTAL) {
                lp.addRule(RelativeLayout.BELOW, trackView.getId());
            } else {
                if (Build.VERSION.SDK_INT > 16) lp.addRule(RelativeLayout.END_OF, trackView.getId());
                else lp.addRule(RelativeLayout.RIGHT_OF, trackView.getId());
            }
        }
        popupTextView.setLayoutParams(lp);
    }

    private void alignTrackAndHandle() {
        int padding = getResources().getDimensionPixelOffset(R.dimen.default_handle_padding);
        
        LayoutParams popupLp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        LayoutParams trackLp;

        if (fastScrollDirection == FastScrollDirection.HORIZONTAL) {
            handleImageView.setPadding(0, padding, 0, padding);
            popupLp.addRule(RelativeLayout.ALIGN_BOTTOM, R.id.trackView);
            
            trackLp = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            trackLp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        } else {
            handleImageView.setPadding(padding, 0, padding, 0);
            if (Build.VERSION.SDK_INT > 16) popupLp.addRule(RelativeLayout.ALIGN_END, R.id.trackView);
            else popupLp.addRule(RelativeLayout.ALIGN_RIGHT, R.id.trackView);
            
            trackLp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            if (Build.VERSION.SDK_INT > 16) trackLp.addRule(RelativeLayout.ALIGN_PARENT_END);
            else trackLp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        }
        
        popupTextView.setLayoutParams(popupLp);
        trackView.setLayoutParams(trackLp);

        post(() -> {
            if (fastScrollDirection == FastScrollDirection.HORIZONTAL) {
                handleImageView.setY(0f);
                popupTextView.setY(trackView.getY() - popupTextView.getHeight());
            } else {
                handleImageView.setX(0f);
                popupTextView.setX(trackView.getX() - popupTextView.getWidth());
            }
            
            // Safe check
            if (recyclerView != null) {
                onScrollListener.onScrolled(recyclerView, 0, 0);
            }
        });
    }

    private void setTrackMargin() {
        if (trackView.getLayoutParams() instanceof MarginLayoutParams) {
            MarginLayoutParams mlp = (MarginLayoutParams) trackView.getLayoutParams();
            if (fastScrollDirection == FastScrollDirection.HORIZONTAL) {
                if (Build.VERSION.SDK_INT > 16) {
                    mlp.setMarginStart(trackMarginStart);
                    mlp.setMarginEnd(trackMarginEnd);
                } else {
                    mlp.setMargins(trackMarginStart, 0, trackMarginEnd, 0);
                }
            } else {
                mlp.setMargins(0, trackMarginStart, 0, trackMarginEnd);
            }
            trackView.setLayoutParams(mlp);
        }
    }

    private void refreshHandleImageViewSize(int newComputedSize) {
        if (newComputedSize == -1) {
            handleImageView.setLayoutParams(new LinearLayout.LayoutParams(handleWidth, handleHeight));
        } else {
            // Dynamic sizing todo
        }
    }

    private void addThumbAndTrack() {
        View.inflate(getContext(), R.layout.fastscroller_track_thumb, this);
        handleImageView = findViewById(R.id.thumbIV);
        trackView = findViewById(R.id.trackView);
    }

    private void addPopupLayout() {
        View.inflate(getContext(), R.layout.fastscroller_popup, this);
        popupTextView = findViewById(R.id.fastScrollPopupTV);
    }

    private void moveHandle(float offset) {
        post(() -> {
            handleImageView.setScaleX(1f);
            handleImageView.setScaleY(1f);
        });

        if (handleVisibilityDuration > 0) {
            if (hideHandleRunnable != null) {
                handler.removeCallbacks(hideHandleRunnable);
            }
            hideHandleRunnable = () -> animateVisibility(handleImageView, false);
            handler.postDelayed(hideHandleRunnable, handleVisibilityDuration);
        }

        moveViewToRelativePositionWithBounds(handleImageView, offset);
        moveViewToRelativePositionWithBounds(popupTextView, offset - getPopupLength());
    }

    private void moveViewToRelativePositionWithBounds(View view, float finalOffset) {
        if (fastScrollDirection == FastScrollDirection.HORIZONTAL) {
            view.setX(Math.min(Math.max(finalOffset, 0f), (getTrackLength() - view.getWidth())));
        } else {
            view.setY(Math.min(Math.max(finalOffset, 0f), (getTrackLength() - view.getHeight())));
        }
    }

    private void animateVisibility(View view, boolean makeVisible) {
        float scaleFactor = makeVisible ? 1f : 0f;
        
        view.animate().scaleX(scaleFactor).setDuration(Defaults.animationDuration)
            .setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationCancel(Animator animation) {
                     // Reset duration if cancelled (simplified from Kotlin extension)
                     view.animate().scaleX(scaleFactor).setDuration(Defaults.animationDuration);
                }
            });
            
        view.animate().scaleY(scaleFactor).setDuration(Defaults.animationDuration)
            .setListener(new AnimatorListenerAdapter() {
                @Override
                 public void onAnimationCancel(Animator animation) {
                     view.animate().scaleY(scaleFactor).setDuration(Defaults.animationDuration);
                }
            });
    }

    private int loadDimenFromResource(@DimenRes int dimenId) {
        return getContext().getResources().getDimensionPixelSize(dimenId);
    }

    // Helper math methods
    private float getTrackLength() {
        return (fastScrollDirection == FastScrollDirection.VERTICAL) ? trackView.getHeight() : trackView.getWidth();
    }
    
    private float getHandleLength() {
        return (fastScrollDirection == FastScrollDirection.VERTICAL) ? handleImageView.getHeight() : handleImageView.getWidth();
    }
    
    private float getPopupLength() {
        return (fastScrollDirection == FastScrollDirection.VERTICAL) ? popupTextView.getHeight() : popupTextView.getWidth();
    }

    // RecyclerView Extensions converted to methods
    private int getTotalCompletelyVisibleItemCount(LinearLayoutManager lm) {
        int firstVisible = lm.findFirstCompletelyVisibleItemPosition();
        if (firstVisible == RecyclerView.NO_POSITION) firstVisible = lm.findFirstVisibleItemPosition();
        
        int lastVisible = lm.findLastCompletelyVisibleItemPosition();
        if (lastVisible == RecyclerView.NO_POSITION) lastVisible = lm.findLastVisibleItemPosition();
        
        if (firstVisible == RecyclerView.NO_POSITION || lastVisible == RecyclerView.NO_POSITION) {
            return RecyclerView.NO_POSITION;
        }
        return lastVisible - firstVisible;
    }

    private void safeScrollToPosition(RecyclerView rv, int position) {
        if (rv.getLayoutManager() instanceof LinearLayoutManager) {
            ((LinearLayoutManager) rv.getLayoutManager()).scrollToPositionWithOffset(position, 0);
        } else {
            rv.getLayoutManager().scrollToPosition(position);
        }
    }

    private int computePositionForOffsetAndScroll(RecyclerView rv, float relativeRawPos) {
        if (rv.getLayoutManager() == null) return 0;
        int itemCount = (rv.getAdapter() != null) ? rv.getAdapter().getItemCount() : 0;
        
        float newOffset = relativeRawPos / (getTrackLength() - getHandleLength());
        
        if (rv.getLayoutManager() instanceof LinearLayoutManager) {
            LinearLayoutManager lm = (LinearLayoutManager) rv.getLayoutManager();
            int totalVisibleItems = getTotalCompletelyVisibleItemCount(lm);
            
            if (totalVisibleItems == RecyclerView.NO_POSITION) return RecyclerView.NO_POSITION;
            
            previousTotalVisibleItem = Math.max(previousTotalVisibleItem, totalVisibleItems);
            
            int position;
            if (lm.getReverseLayout()) {
                position = Math.min(itemCount, Math.max(0, itemCount - Math.round(newOffset * (itemCount - totalVisibleItems))));
            } else {
                position = Math.min(itemCount, Math.max(0, Math.round(newOffset * (itemCount - totalVisibleItems))));
            }
            
            int toScrollPosition = Math.min(itemCount - (previousTotalVisibleItem + 1), position);
            safeScrollToPosition(rv, toScrollPosition);
            return position;
        } else {
            int position = Math.round(newOffset * itemCount);
            safeScrollToPosition(rv, position);
            return position;
        }
    }

    private void updateTextInPopup(int position) {
        int itemCount = (recyclerView.getAdapter() != null) ? recyclerView.getAdapter().getItemCount() : 1;
        if (position < 0 || position >= itemCount) return;
        
        RecyclerView.Adapter<?> adapter = recyclerView.getAdapter();
        if (adapter == null) return;
        
        if (adapter instanceof OnPopupTextUpdate) {
            popupTextView.setText(((OnPopupTextUpdate) adapter).onChange(position));
        } else if (adapter instanceof OnPopupViewUpdate) {
            ((OnPopupViewUpdate) adapter).onUpdate(position, popupTextView);
        } else {
            popupTextView.setVisibility(GONE);
        }
    }

    // Inner Classes and Listeners
    private final RecyclerView.ItemDecoration emptySpaceItemDecoration = new RecyclerView.ItemDecoration() {
        @Override
        public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
            super.getItemOffsets(outRect, view, parent, state);
            int itemCount = (parent.getAdapter() != null) ? parent.getAdapter().getItemCount() : 0;
            if (parent.getChildAdapterPosition(view) == itemCount - 1) {
                if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {
                    int currentVisiblePos = ((LinearLayoutManager) recyclerView.getLayoutManager()).findFirstVisibleItemPosition();
                    if (currentVisiblePos != RecyclerView.NO_POSITION) {
                        RecyclerView.ViewHolder vh = parent.findViewHolderForAdapterPosition(currentVisiblePos);
                        if (vh != null) {
                            outRect.bottom = vh.itemView.getHeight();
                        }
                    }
                }
            }
        }
    };

    private final RecyclerView.AdapterDataObserver adapterDataObserver = new RecyclerView.AdapterDataObserver() {
        @Override
        public void onChanged() {
            super.onChanged();
            previousTotalVisibleItem = 0;
        }

        @Override
        public void onItemRangeRemoved(int positionStart, int itemCount) {
            super.onItemRangeRemoved(positionStart, itemCount);
            previousTotalVisibleItem = 0;
        }
    };

    private final RecyclerView.OnScrollListener onScrollListener = new RecyclerView.OnScrollListener() {
    @Override
    public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
        super.onScrolled(recyclerView, dx, dy);
        
        // Agar Fast Scroll pakda hua hai, to kuch mat karo
        if (isEngaged) return;

        // Scroll ho raha hai -> Handle dikhao
        animateVisibility(handleImageView, true);

        // Agar list choti hai to handle mat dikhao
        if (!(recyclerView.getLayoutManager() instanceof LinearLayoutManager)) return;
        
        // ... (Range/Extent calculation wala purana logic yahan same rahega) ...
        LinearLayoutManager lm = (LinearLayoutManager) recyclerView.getLayoutManager();
        int range, extent, offset;
         if (lm.getOrientation() == RecyclerView.HORIZONTAL) {
            range = recyclerView.computeHorizontalScrollRange();
            extent = recyclerView.computeHorizontalScrollExtent();
            offset = recyclerView.computeHorizontalScrollOffset();
        } else {
            range = recyclerView.computeVerticalScrollRange();
            extent = recyclerView.computeVerticalScrollExtent();
            offset = recyclerView.computeVerticalScrollOffset();
        }
        
        // Position update karo
        float error = (float) extent * offset / range;
        float finalOffset = (getTrackLength() - getHandleLength()) * ((error + offset) / range);
        
        // Move Handle (Yeh method apne aap timer reset karega kyunki XML mein duration set hai)
        moveHandle(finalOffset);
    }
    
    // YEH METHOD ADD KAREIN: Jab scroll ruk jaye (Idle state)
    @Override
    public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
        super.onScrollStateChanged(recyclerView, newState);
        
        if (newState == RecyclerView.SCROLL_STATE_IDLE) {
            // Jab scroll ruk jaye, to timer start karo chhupane ke liye
            if (handleVisibilityDuration > 0) {
                handler.removeCallbacks(hideHandleRunnable);
                handler.postDelayed(hideHandleRunnable, handleVisibilityDuration);
            }
        } else {
            // Jab tak scroll ho raha hai, handle dikhate raho (Timer cancel karo)
            handler.removeCallbacks(hideHandleRunnable);
            animateVisibility(handleImageView, true);
        }
    }
    };


    // Public Methods to attach/detach
    public void setHandleStateListener(HandleStateListener listener) {
        this.handleStateListener = listener;
    }

    public void attachFastScrollerToRecyclerView(RecyclerView recyclerView) {
        this.recyclerView = recyclerView;
        if (hasEmptyItemDecorator) {
            recyclerView.addItemDecoration(emptySpaceItemDecoration);
        }
        registerDataObserver();
        recyclerView.addOnScrollListener(onScrollListener);
    }
    
    private void registerDataObserver() {
        if (recyclerView != null && recyclerView.getAdapter() != null) {
             try {
                recyclerView.getAdapter().registerAdapterDataObserver(adapterDataObserver);
             } catch(Exception e) {
                 // Already registered
             }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    public void detachFastScrollerFromRecyclerView() {
        if (recyclerView != null) {
            if (recyclerView.getAdapter() != null) {
                try {
                    recyclerView.getAdapter().unregisterAdapterDataObserver(adapterDataObserver);
                } catch (Exception e) {
                    // Not registered
                }
            }
            recyclerView.removeOnScrollListener(onScrollListener);
            if (hasEmptyItemDecorator) {
                recyclerView.removeItemDecoration(emptySpaceItemDecoration);
            }
        }
        if (handleImageView != null) handleImageView.setOnTouchListener(null);
        if (popupTextView != null) popupTextView.setOnTouchListener(null);
    }

    // Interfaces
    public interface OnPopupViewUpdate {
        void onUpdate(int position, TextView popupTextView);
    }

    public interface OnPopupTextUpdate {
        CharSequence onChange(int position);
    }

    public interface HandleStateListener {
        void onEngaged();
        void onDragged(float offset, int position);
        void onReleased();
    }
}
