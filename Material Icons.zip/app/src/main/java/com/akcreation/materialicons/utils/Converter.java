package com.akcreation.materialicons.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import com.caverock.androidsvg.SVG;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Utility class for converting and exporting SVG icons to various formats (SVG, XML Vector, PNG).
 * Handles color application, resizing, and adaptive icon generation.
 * Updated to support Stroke LineCaps, LineJoins and Smart Fill/Stroke detection.
 *
 * @author AK_CREATION_DEV
 * @version 2.1 (Stroke & Cap Support Added)
 */
public class Converter {

    // --- CONSTANTS ---
    private static final int ADAPTIVE_ICON_SIZE = 108;

    // Regex to detect hex colors (3 or 6 digits) inside attributes or styles
    private static final Pattern HEX_COLOR_PATTERN = Pattern.compile("#([0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})");

    // Regex to extract 'd' attribute from path (Fallback mechanism)
    private static final Pattern PATH_D_ATTRIBUTE_PATTERN = Pattern.compile("d\\s*=\\s*\"([^\"]+)\"");

    /**
     * Data class to hold the result of an export operation.
     */
    public static class ConversionResult {
        public final boolean success;
        public final String message;
        public final List<String> generatedFiles;

        public ConversionResult(boolean success, String message, List<String> generatedFiles) {
            this.success = success;
            this.message = message;
            this.generatedFiles = generatedFiles;
        }
    }

    /**
     * Wrapper method to export an icon returning a boolean success status.
     */
    public static boolean exportIcon(Context context, InputStream svgInputStream,
                                     String projectPath, String fileName,
                                     String exportType, int color,
                                     int width, int height, boolean isAdaptive) {
        ConversionResult result = exportIconWithResult(context, svgInputStream, projectPath,
                fileName, exportType, color, width, height, isAdaptive);
        return result.success;
    }

    /**
     * Core method to handle icon export with detailed result reporting.
     */
    public static ConversionResult exportIconWithResult(Context context, InputStream svgInputStream,
                                                        String projectPath, String fileName,
                                                        String exportType, int color,
                                                        int width, int height, boolean isAdaptive) {
        List<String> generatedFiles = new ArrayList<>();

        // Ensure the directory exists
        String saveDir = projectPath + "/app/src/main/res/drawable/";
        File dir = new File(saveDir);
        if (!dir.exists() && !dir.mkdirs()) {
            return new ConversionResult(false, "Critical Error: Failed to create directory " + saveDir, generatedFiles);
        }

        try {
            // Step 1: Read SVG Content
            String originalSvgContent = readStreamToString(svgInputStream);
            if (originalSvgContent == null || originalSvgContent.trim().isEmpty()) {
                return new ConversionResult(false, "Error: Source SVG content is empty.", generatedFiles);
            }

            // Step 2: Prepare Target Color Hex
            String targetColorHex = String.format("#%06X", (0xFFFFFF & color));

            // Step 3: Apply Smart Color Logic (For PNG/SVG exports mostly)
            String coloredSvgContent = applySmartColorToSvg(originalSvgContent, targetColorHex);
            String cleanFileName = sanitizeFileName(fileName);

            // Step 4: Handle Adaptive Icons separately
            if (isAdaptive) {
                return createAdaptiveIcon(coloredSvgContent, color, cleanFileName, dir);
            }

            // Step 5: Execute Export based on Type
            switch (exportType.toLowerCase()) {
                case "svg":
                    File svgFile = new File(dir, cleanFileName + ".svg");
                    String resizedSvg = resizeSvgDimensions(coloredSvgContent, width, height);
                    if (saveStringToFile(resizedSvg, svgFile)) {
                        generatedFiles.add(svgFile.getAbsolutePath());
                        return new ConversionResult(true, "SVG Exported Successfully", generatedFiles);
                    }
                    return new ConversionResult(false, "Failed to write SVG file to disk.", generatedFiles);

                case "vector":
                    File vectorFile = new File(dir, cleanFileName + ".xml");
                    // Important: Vectors need precise XML structure
                    // We pass original content to parse attributes like 'stroke-linecap' correctly
                    String vectorXml = convertSvgToVectorXml(originalSvgContent, width, height, targetColorHex);
                    if (saveStringToFile(vectorXml, vectorFile)) {
                        generatedFiles.add(vectorFile.getAbsolutePath());
                        return new ConversionResult(true, "Vector Drawable Created Successfully", generatedFiles);
                    }
                    return new ConversionResult(false, "Failed to generate Vector XML.", generatedFiles);

                case "png":
                    return exportPngImage(coloredSvgContent, dir, cleanFileName, width, height);

                case "png_multi":
                    return exportMultipleResolutions(coloredSvgContent, dir, cleanFileName);

                default:
                    return new ConversionResult(false, "Unknown Export Type: " + exportType, generatedFiles);
            }

        } catch (Exception e) {
            e.printStackTrace();
            return new ConversionResult(false, "Exception: " + e.getMessage(), generatedFiles);
        } finally {
            closeQuietly(svgInputStream);
        }
    }

    // ============================================================================================
    // CORE LOGIC: COLOR MANIPULATION
    // ============================================================================================

    private static String applySmartColorToSvg(String svgContent, String targetHex) {
        String modified = svgContent;
        modified = modified.replace("fill=\"currentColor\"", "fill=\"" + targetHex + "\"");
        modified = modified.replace("stroke=\"currentColor\"", "stroke=\"" + targetHex + "\"");
        modified = modified.replace("'currentColor'", "\"" + targetHex + "\"");

        String[] blackVariants = {"#000000", "#000", "black", "#181816", "#212121"};
        for (String variant : blackVariants) {
            modified = modified.replace("fill=\"" + variant + "\"", "fill=\"" + targetHex + "\"");
            modified = modified.replace("stroke=\"" + variant + "\"", "stroke=\"" + targetHex + "\"");
            modified = modified.replace(":" + variant, ":" + targetHex);
        }

        if (modified.contains("<style>") || modified.contains("style=")) {
            Matcher matcher = HEX_COLOR_PATTERN.matcher(modified);
            StringBuffer sb = new StringBuffer();
            while (matcher.find()) {
                matcher.appendReplacement(sb, targetHex);
            }
            matcher.appendTail(sb);
            modified = sb.toString();
        }

        if (!modified.contains("fill=") && !modified.contains("stroke=")) {
            modified = modified.replaceFirst("<svg", "<svg fill=\"" + targetHex + "\"");
        }
        return modified;
    }

    // ============================================================================================
    // CORE LOGIC: VECTOR DRAWABLE GENERATION (UPDATED)
    // ============================================================================================

    private static String convertSvgToVectorXml(String svgContent, int width, int height, String targetColorHex) {
        List<PathData> paths = parsePathsFromSvg(svgContent);

        if (paths.isEmpty()) {
            extractPathsUsingRegex(svgContent, paths);
        }

        StringBuilder pathBuilder = new StringBuilder();

        for (PathData path : paths) {
            pathBuilder.append("    <path\n");

            // --- Logic to determine Fill vs Stroke ---
            boolean isStrokeNone = path.strokeColor != null && path.strokeColor.equalsIgnoreCase("none");
            boolean isFillNone = path.fillColor != null && path.fillColor.equalsIgnoreCase("none");
            
            // It has a stroke if stroke is defined and not "none"
            boolean hasStroke = path.strokeColor != null && !isStrokeNone;
            
            // It has a fill if fill is defined and not "none".
            // If neither stroke nor fill is strictly defined, we default to fill.
            boolean hasFill = (path.fillColor != null && !isFillNone) || (!hasStroke && path.fillColor == null);

            // 1. Apply Stroke Attributes
            if (hasStroke) {
                pathBuilder.append("        android:strokeColor=\"").append(targetColorHex).append("\"\n");
                
                String w = (path.strokeWidth != null) ? path.strokeWidth.replaceAll("[^0-9.]", "") : "1";
                pathBuilder.append("        android:strokeWidth=\"").append(w).append("\"\n");

                // Add Line Cap (Round, etc)
                if (path.strokeLineCap != null) {
                    pathBuilder.append("        android:strokeLineCap=\"").append(path.strokeLineCap).append("\"\n");
                }
                
                // Add Line Join (Round, Miter, etc)
                if (path.strokeLineJoin != null) {
                    pathBuilder.append("        android:strokeLineJoin=\"").append(path.strokeLineJoin).append("\"\n");
                }
            }

            // 2. Apply Fill Attributes
            if (hasFill) {
                pathBuilder.append("        android:fillColor=\"").append(targetColorHex).append("\"\n");
            } else {
                // IMPORTANT: If fill="none" (like in your icon), set transparent fill
                pathBuilder.append("        android:fillColor=\"#00000000\"\n");
            }

            pathBuilder.append("        android:pathData=\"").append(path.data).append("\" />\n");
        }

        // Note: Using hardcoded 24 viewport as standard, can be parsed from viewbox if needed later
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
               "<vector xmlns:android=\"http://schemas.android.com/apk/res/android\"\n" +
               "    android:width=\"" + width + "dp\"\n" +
               "    android:height=\"" + height + "dp\"\n" +
               "    android:viewportWidth=\"24.0\"\n" +
               "    android:viewportHeight=\"24.0\">\n" +
               pathBuilder.toString() +
               "</vector>";
    }

    // ============================================================================================
    // CORE LOGIC: IMAGE GENERATION (PNG)
    // ============================================================================================

    private static ConversionResult exportPngImage(String svgContent, File dir, String fileName, int width, int height) {
        List<String> generatedFiles = new ArrayList<>();
        try {
            File pngFile = new File(dir, fileName + ".png");
            SVG svg = SVG.getFromString(svgContent);
            svg.setDocumentWidth(width);
            svg.setDocumentHeight(height);

            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            bitmap.eraseColor(Color.TRANSPARENT);
            canvas.setDrawFilter(new PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
            svg.renderToCanvas(canvas);

            try (OutputStream os = new FileOutputStream(pngFile)) {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, os);
            }
            bitmap.recycle();
            generatedFiles.add(pngFile.getAbsolutePath());
            return new ConversionResult(true, "PNG Saved: " + fileName, generatedFiles);
        } catch (Exception e) {
            return new ConversionResult(false, "PNG Export Failed: " + e.getMessage(), generatedFiles);
        }
    }

    private static ConversionResult exportMultipleResolutions(String svgContent, File dir, String fileName) {
        List<String> generatedFiles = new ArrayList<>();
        int[] resolutions = {512, 1024, 2048, 3840};
        try {
            for (int size : resolutions) {
                ConversionResult res = exportPngImage(svgContent, dir, fileName + "_" + size + "px", size, size);
                if (res.success) generatedFiles.addAll(res.generatedFiles);
            }
            return new ConversionResult(true, "Multi-Res PNGs Generated", generatedFiles);
        } catch (Exception e) {
            return new ConversionResult(false, "Batch Export Failed", generatedFiles);
        }
    }

    // ============================================================================================
    // HELPERS & UTILS
    // ============================================================================================

        // ============================================================================================
    // FIXED PARSER: Handles attributes defined on the <svg> root tag
    // ============================================================================================

    private static List<PathData> parsePathsFromSvg(String svgContent) {
        List<PathData> paths = new ArrayList<>();
        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();

            String cleanXml = svgContent.replaceAll("<style>[\\s\\S]*?</style>", "");
            xpp.setInput(new StringReader(cleanXml));

            // Variables to store Root (<svg>) attributes to use as defaults
            String rootFill = null;
            String rootStroke = null;
            String rootStrokeW = null;
            String rootLineCap = null;
            String rootLineJoin = null;

            int eventType = xpp.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                String tagName = xpp.getName();

                if (eventType == XmlPullParser.START_TAG) {
                    // 1. Capture Root Attributes (SVG Tag)
                    if ("svg".equalsIgnoreCase(tagName)) {
                        rootFill = xpp.getAttributeValue(null, "fill");
                        rootStroke = xpp.getAttributeValue(null, "stroke");
                        rootStrokeW = xpp.getAttributeValue(null, "stroke-width");
                        rootLineCap = xpp.getAttributeValue(null, "stroke-linecap");
                        rootLineJoin = xpp.getAttributeValue(null, "stroke-linejoin");
                    }
                    
                    // 2. Apply to Paths (If path doesn't have its own, use Root's)
                    else if ("path".equalsIgnoreCase(tagName)) {
                        String d = xpp.getAttributeValue(null, "d");
                        
                        // Read Path Attributes
                        String pFill = xpp.getAttributeValue(null, "fill");
                        String pStroke = xpp.getAttributeValue(null, "stroke");
                        String pStrokeW = xpp.getAttributeValue(null, "stroke-width");
                        String pLineCap = xpp.getAttributeValue(null, "stroke-linecap");
                        String pLineJoin = xpp.getAttributeValue(null, "stroke-linejoin");

                        // MERGE LOGIC: Use Path's value, if null use Root's value
                        String effectiveFill = (pFill != null) ? pFill : rootFill;
                        String effectiveStroke = (pStroke != null) ? pStroke : rootStroke;
                        String effectiveStrokeW = (pStrokeW != null) ? pStrokeW : rootStrokeW;
                        String effectiveLineCap = (pLineCap != null) ? pLineCap : rootLineCap;
                        String effectiveLineJoin = (pLineJoin != null) ? pLineJoin : rootLineJoin;

                        if (d != null && !d.trim().isEmpty()) {
                            paths.add(new PathData(d, effectiveFill, effectiveStroke, effectiveStrokeW, effectiveLineCap, effectiveLineJoin));
                        }
                    }
                }
                eventType = xpp.next();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return paths;
    }


    private static void extractPathsUsingRegex(String svgContent, List<PathData> paths) {
        Matcher matcher = PATH_D_ATTRIBUTE_PATTERN.matcher(svgContent);
        while (matcher.find()) {
            // Fallback: passing null for extra attributes
            paths.add(new PathData(matcher.group(1), null, null, null, null, null));
        }
    }

    private static ConversionResult createAdaptiveIcon(String svgContent, int color, String fileName, File saveDir) {
        List<String> files = new ArrayList<>();
        try {
            String fgName = fileName + "_foreground";
            File fgFile = new File(saveDir, fgName + ".xml");
            
            String colorHex = String.format("#%06X", (0xFFFFFF & color));
            // Will now use the new logic for adaptive icon foregrounds too
            String vectorXml = convertSvgToVectorXml(svgContent, ADAPTIVE_ICON_SIZE, ADAPTIVE_ICON_SIZE, colorHex);
            
            if (!saveStringToFile(vectorXml, fgFile)) throw new IOException("Write failed");
            files.add(fgFile.getAbsolutePath());

            String bg = (Color.alpha(color) < 255) ? "@android:color/transparent" : "@android:color/white";
            String wrapperXml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                    "<adaptive-icon xmlns:android=\"http://schemas.android.com/apk/res/android\">\n" +
                    "    <background android:drawable=\"" + bg + "\"/>\n" +
                    "    <foreground android:drawable=\"@drawable/" + fgName + "\"/>\n" +
                    "</adaptive-icon>";

            File wrapperFile = new File(saveDir, fileName + ".xml");
            if (!saveStringToFile(wrapperXml, wrapperFile)) throw new IOException("Wrapper write failed");
            files.add(wrapperFile.getAbsolutePath());

            return new ConversionResult(true, "Adaptive Icon Generated", files);
        } catch (Exception e) {
            return new ConversionResult(false, "Adaptive Error: " + e.getMessage(), files);
        }
    }

    private static String resizeSvgDimensions(String svg, int w, int h) {
        String s = svg.replaceAll("width\\s*=\\s*\"[^\"]*\"", "width=\"" + w + "\"");
        s = s.replaceAll("height\\s*=\\s*\"[^\"]*\"", "height=\"" + h + "\"");
        if (!s.contains("width=")) {
            s = s.replaceFirst("<svg", "<svg width=\"" + w + "\" height=\"" + h + "\"");
        }
        return s;
    }

    private static String sanitizeFileName(String name) {
        return name.toLowerCase().replaceAll("[^a-z0-9_]", "_").replaceAll("_+", "_");
    }

    private static String readStreamToString(InputStream is) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append("\n");
        }
        return sb.toString();
    }

    private static boolean saveStringToFile(String content, File file) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(file)) {
            fos.write(content.getBytes(StandardCharsets.UTF_8));
            return true;
        }
    }

    private static void closeQuietly(InputStream is) {
        try { if (is != null) is.close(); } catch (IOException ignored) {}
    }

    // Inner Data Class (Updated to hold Stroke info)
    private static class PathData {
        final String data;
        final String fillColor;
        final String strokeColor;
        final String strokeWidth;
        final String strokeLineCap;
        final String strokeLineJoin;

        PathData(String d, String f, String s, String sw, String cap, String join) {
            this.data = d;
            this.fillColor = f;
            this.strokeColor = s;
            this.strokeWidth = sw;
            this.strokeLineCap = cap;
            this.strokeLineJoin = join;
        }
    }
}
