package com.akcreation.materialicons.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.akcreation.materialicons.R;
import com.akcreation.materialicons.activities.IconBrowserActivity;
import com.akcreation.materialicons.models.ProjectModel;

import java.util.ArrayList;
import java.util.List;

public class ProjectAdapter extends RecyclerView.Adapter<ProjectAdapter.ViewHolder> {

    private final List<ProjectModel> allProjects;
    private List<ProjectModel> filteredProjects;
    private final Context context;

    public ProjectAdapter(Context context, List<ProjectModel> projects) {
        this.context = context;
        this.allProjects = new ArrayList<>(projects);
        this.filteredProjects = new ArrayList<>(projects);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.project_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ProjectModel project = filteredProjects.get(position);
        holder.projectName.setText(project.getName());
        holder.projectPath.setText(project.getPath());

        // Hamesha default folder icon dikhayein
        holder.projectIcon.setImageResource(R.drawable.ic_folder);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, IconBrowserActivity.class);
            intent.putExtra("PROJECT_PATH", project.getPath());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return filteredProjects.size();
    }

    public void filter(String query) {
        filteredProjects.clear();
        if (query.isEmpty()) {
            filteredProjects.addAll(allProjects);
        } else {
            query = query.toLowerCase().trim();
            for (ProjectModel project : allProjects) {
                if (project.getName().toLowerCase().contains(query)) {
                    filteredProjects.add(project);
                }
            }
        }
        notifyDataSetChanged();
    }
    
    public void updateProjects(List<ProjectModel> newProjects) {
        allProjects.clear();
        allProjects.addAll(newProjects);
        filter("");
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView projectIcon;
        TextView projectName;
        TextView projectPath;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            projectIcon = itemView.findViewById(R.id.project_icon);
            projectName = itemView.findViewById(R.id.project_name);
            projectPath = itemView.findViewById(R.id.project_path);
        }
    }
}