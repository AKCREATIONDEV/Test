package com.akcreation.materialicons.activities;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextPaint;
import com.akcreation.materialicons.R;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;

public class AboutDialog extends Dialog {

    private Context context;
    private ImageView appIcon;
    private boolean easterEggActivated = false;
    private Random random = new Random();

    public AboutDialog(Context context) {
        super(context);
        this.context = context;
    }

    @Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    setContentView(R.layout.dialog_about);
    
    // Make dialog background transparent for rounded corners
    if (getWindow() != null) {
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        
        // Set dialog width to 95% of screen width
        android.view.WindowManager.LayoutParams params = getWindow().getAttributes();
        android.util.DisplayMetrics displayMetrics = new android.util.DisplayMetrics();
        getWindow().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenWidth = displayMetrics.widthPixels;
        int screenHeight = displayMetrics.heightPixels;
        params.width = (int) (screenWidth * 0.85); // 95% of screen width
        params.height = (int) (screenHeight * 0.7);  // 50% height
        getWindow().setAttributes(params);
    }

    initializeViews();
}

    private void initializeViews() {
        appIcon = findViewById(R.id.app_icon);
        TextView appName = findViewById(R.id.app_name);
        TextView appTagline = findViewById(R.id.app_tagline);
        TextView appVersion = findViewById(R.id.app_version);
        
        TextView developerName = findViewById(R.id.developer_name);
        TextView developerTelegram = findViewById(R.id.developer_telegram);
        
        TextView appDescription = findViewById(R.id.app_description);
        
        TextView feature1 = findViewById(R.id.feature_1);
        TextView feature2 = findViewById(R.id.feature_2);
        TextView feature3 = findViewById(R.id.feature_3);
        TextView feature4 = findViewById(R.id.feature_4);
        TextView feature5 = findViewById(R.id.feature_5);
        TextView feature6 = findViewById(R.id.feature_6);
        TextView feature7 = findViewById(R.id.feature_7);
        TextView feature8 = findViewById(R.id.feature_8);
        TextView feature9 = findViewById(R.id.feature_9);
        TextView feature10 = findViewById(R.id.feature_10);
        
        Button okButton = findViewById(R.id.ok_button);

        // Set app info
        appName.setText("Material Icons");
        appTagline.setText("The ultimate icon toolkit for developers and designers");
        
        // Get version dynamically
        try {
            String version = context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0).versionName;
            appVersion.setText("v" + version);
        } catch (Exception e) {
            appVersion.setText("v6.0.0");
        }

        // Set developer info
        developerName.setText("Made by: AK_CREATION_DEV");
        // Telegram text ko black aur name ko blue (clickable) banane ke liye SpannableString use karein
        String telegramText = "Telegram: ";
        String telegramName = "AK_CREATION_DEV";
        String fullText = telegramText + telegramName;

        SpannableString spannableString = new SpannableString(fullText);

        // "Telegram:" ko black color
        spannableString.setSpan(
            new ForegroundColorSpan(Color.BLACK),
            0,
            telegramText.length(),
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        );

        // "AK_CREATION_DEV" ko blue color aur clickable
        spannableString.setSpan(
            new ForegroundColorSpan(Color.parseColor("#2196F3")),
            telegramText.length(),
            fullText.length(),
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        );

        spannableString.setSpan(
            new ClickableSpan() {
                @Override
                public void onClick(View widget) {
                    openUrl("https://t.me/AK_CREATION_DEV");
                }
                @Override
                public void updateDrawState(TextPaint ds) {
                    super.updateDrawState(ds);
                    ds.setUnderlineText(false); // Remove underline
                }
            },
            telegramText.length(),
            fullText.length(),
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        );

        developerTelegram.setText(spannableString);
        developerTelegram.setMovementMethod(LinkMovementMethod.getInstance());
        developerTelegram.setHighlightColor(Color.TRANSPARENT); // Remove highlight on click


        // App Icon Easter Egg - Click to change color
        appIcon.setSoundEffectsEnabled(false);
        appIcon.setOnClickListener(v -> {
            if (easterEggActivated) {
                // Change to random rainbow color
                int randomColor = getRandomRainbowColor();
                appIcon.setColorFilter(randomColor, PorterDuff.Mode.SRC_ATOP);
                // Visual feedback - bounce animation
                appIcon.animate().scaleX(1.1f).scaleY(1.1f).setDuration(100)
                    .withEndAction(() -> appIcon.animate().scaleX(1f).scaleY(1f).setDuration(100).start())
                    .start();
            } else {
                // First click activates easter egg
                easterEggActivated = true;
                appIcon.setColorFilter(Color.MAGENTA, PorterDuff.Mode.SRC_ATOP);
                
            }
        });

        // Set description
        appDescription.setText("Material Icons is the ultimate utility tool designed for Android developers, UI/UX designers, and graphic artists. With a massive library of over 15,000+ icons, this app simplifies the process of finding and integrating high-quality Material Design icons into your projects.\n\nWhether you need XML Vectors for Android development, SVGs for web design, or PNGs for graphic work, Material Icons handles it all.");

        // Set features
        feature1.setText("• Massive Icon Library: Browse over 15,000+ icons");
        feature2.setText("• Vector (XML): Ready-to-use code for Android Studio");
        feature3.setText("• SVG: Perfect for web development and scalable design");
        feature4.setText("• PNG: High-quality images for general use");
        feature5.setText("• Advanced Color Customization with Hex Code support");
        feature6.setText("• Custom Size Selection for standard Android densities");
        feature7.setText("• Smart Search & Categories for quick icon location");
        feature8.setText("• File Management: Rename files before saving");
        feature9.setText("• Offline & Local Storage Support");
        feature10.setText("• Compatible with AndroidIDE projects");

        // OK button click listener
        okButton.setOnClickListener(v -> dismiss());
    }

    private int getRandomRainbowColor() {
        int[] rainbowColors = {
            Color.RED,
            Color.rgb(255, 165, 0),  // Orange
            Color.YELLOW,
            Color.GREEN,
            Color.CYAN,
            Color.BLUE,
            Color.rgb(75, 0, 130),   // Indigo
            Color.MAGENTA,
            Color.rgb(255, 20, 147), // Deep Pink
            Color.rgb(138, 43, 226)  // Blue Violet
        };
        
        return rainbowColors[random.nextInt(rainbowColors.length)];
    }

    private void openUrl(String url) {
        try {
            android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_VIEW);
            intent.setData(android.net.Uri.parse(url));
            context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context, "Could not open link", Toast.LENGTH_SHORT).show();
        }
    }
}