package com.akcreation.materialicons.adapters;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.PictureDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.akcreation.materialicons.R;
import com.akcreation.materialicons.models.IconModel;
import com.akcreation.materialicons.utils.Filter;
import com.akcreation.materialicons.utils.IconDataHolder; // Naya Data Source
import com.akcreation.materialicons.utils.RecyclerViewFastScroller;
import com.caverock.androidsvg.SVG;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipFile; // (Ab zaroorat nahi, lekin agar purane imports hain to hata dein)

public class IconAdapter extends RecyclerView.Adapter<IconAdapter.ViewHolder>
        implements RecyclerViewFastScroller.OnPopupTextUpdate {

    private final List<IconModel> allIcons;
    private List<IconModel> filteredIcons;
    private List<IconModel> iconsMatchingCategory;
    private final Context context;
    // private final ZipFile zipFile; // HATA DIYA GAYA
    private final OnIconClickListener listener;
    private String currentQuery = "";

    // Dark Mode Flags
    private boolean isDarkMode = false;
    private String whiteHex = "#FFFFFF";

    // Caching & Threading
    private final LruCache<String, PictureDrawable> memoryCache;
    private final ExecutorService executorService;
    private final Handler mainHandler;

    // REGEX: Hex Codes dhoondhne ke liye (# ke baad 3 ya 6 characters)
    private final Pattern hexPattern = Pattern.compile("#([0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})");

    public interface OnIconClickListener {
        void onIconClick(IconModel icon);
    }

    // Constructor Updated: ZipFile parameter hata diya gaya hai (ya null accept karega)
    public IconAdapter(Context context, List<IconModel> icons, ZipFile ignoredZipFile, OnIconClickListener listener) {
        this.context = context;
        this.allIcons = new ArrayList<>(icons);
        this.filteredIcons = new ArrayList<>(icons);
        this.iconsMatchingCategory = new ArrayList<>(icons);
        // this.zipFile = zipFile; // Ab store nahi karenge
        this.listener = listener;

        int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);
        int cacheSize = maxMemory / 8;
        memoryCache = new LruCache<>(cacheSize);

        executorService = Executors.newFixedThreadPool(4);
        mainHandler = new Handler(Looper.getMainLooper());

        updateThemeColor();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.icon_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        IconModel icon = filteredIcons.get(position);
        
        holder.iconName.setText(icon.getName());
        holder.iconName.setTextColor(isDarkMode ? Color.WHITE : Color.BLACK);

        holder.iconImage.setImageDrawable(null);
        holder.iconImage.setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        String cacheKey = icon.getPathInZip() + (isDarkMode ? "_dark" : "_light");
        
        PictureDrawable cachedDrawable = memoryCache.get(cacheKey);

        if (cachedDrawable != null) {
            holder.iconImage.setImageDrawable(cachedDrawable);
        } else {
            loadIconAsync(holder, icon, position, cacheKey);
        }

        holder.itemView.setOnClickListener(v -> listener.onIconClick(icon));
    }

    // --- NEW LOADING METHOD (Uses IconDataHolder) ---
    private void loadIconAsync(ViewHolder holder, IconModel icon, int position, String cacheKey) {
        executorService.execute(() -> {
            try {
                // STEP 1: Ab Zip se nahi, seedha RAM (DataHolder) se SVG code nikalo
                // Yeh super fast hai kyunki file I/O nahi hota
                String originalSvg = IconDataHolder.getSvg(icon.getPathInZip());

                if (originalSvg == null || originalSvg.isEmpty()) {
                    return; // Code nahi mila
                }

                String finalSvg = originalSvg;

                // --- INTELLIGENT DARK MODE LOGIC (Preserved) ---
                if (isDarkMode) {
                    // Check karo ki kya Icon "Dark/Black" category ka hai?
                    if (isIconMostlyDark(originalSvg)) {
                        
                        // Dark Colors ko White banao
                        finalSvg = replaceDarkColorsWithWhite(finalSvg);

                        // Keywords handle karo
                        finalSvg = finalSvg.replace("fill=\"currentColor\"", "fill=\"" + whiteHex + "\"");
                        finalSvg = finalSvg.replace("stroke=\"currentColor\"", "stroke=\"" + whiteHex + "\"");
                        finalSvg = finalSvg.replace("fill=\"black\"", "fill=\"" + whiteHex + "\"");
                        finalSvg = finalSvg.replace("stroke=\"black\"", "stroke=\"" + whiteHex + "\"");

                        // Safety Net: Agar color nahi mila to default fill daal do
                        boolean hasStroke = finalSvg.contains("stroke=");
                        boolean hasFill = finalSvg.contains("fill=");
                        if (!hasFill && !hasStroke) {
                            finalSvg = finalSvg.replaceFirst("<svg", "<svg fill=\"" + whiteHex + "\"");
                        }
                    }
                }

                // STEP 2: Render
                SVG svg = SVG.getFromString(finalSvg);
                PictureDrawable drawable = new PictureDrawable(svg.renderToPicture());

                memoryCache.put(cacheKey, drawable);

                mainHandler.post(() -> {
                    if (holder.getAdapterPosition() == position) {
                        holder.iconImage.setImageDrawable(drawable);
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Dark Mode Check Logic
     */
    private boolean isIconMostlyDark(String svgContent) {
        Matcher matcher = hexPattern.matcher(svgContent);
        
        while (matcher.find()) {
            String hex = matcher.group(1);
            if (!isColorDark(hex)) {
                return false; // Colored icon hai, mat chhedo
            }
        }
        
        if (svgContent.contains("=\"red\"") || svgContent.contains("=\"blue\"") || svgContent.contains("=\"#FFF\"")) {
            return false;
        }
        
        return true; 
    }

    /**
     * Hex Color Replacement Logic
     */
    private String replaceDarkColorsWithWhite(String svgContent) {
        Matcher matcher = hexPattern.matcher(svgContent);
        StringBuffer sb = new StringBuffer();

        while (matcher.find()) {
            String hex = matcher.group(1);
            if (isColorDark(hex)) {
                matcher.appendReplacement(sb, whiteHex);
            } else {
                matcher.appendReplacement(sb, "#" + hex);
            }
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    /**
     * Brightness Check
     */
    private boolean isColorDark(String hex) {
        try {
            if (hex.length() == 3) {
                hex = "" + hex.charAt(0) + hex.charAt(0) + hex.charAt(1) + hex.charAt(1) + hex.charAt(2) + hex.charAt(2);
            }
            int color = Color.parseColor("#" + hex);
            double darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255;
            
            return darkness > 0.5; 
        } catch (Exception e) {
            return true;
        }
    }

    @Override
    public int getItemCount() {
        return filteredIcons.size();
    }

    @Override
    public CharSequence onChange(int position) {
        if (position >= 0 && position < filteredIcons.size()) {
            String name = filteredIcons.get(position).getName();
            if (name != null && !name.isEmpty()) {
                return name.substring(0, 1).toUpperCase();
            }
        }
        return "";
    }

    public void refreshTheme() {
        updateThemeColor();
        memoryCache.evictAll();
        notifyItemRangeChanged(0, getItemCount());
    }

    private void updateThemeColor() {
        int nightMode = context.getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK;
        
        isDarkMode = (nightMode == Configuration.UI_MODE_NIGHT_YES);
    }

    public void filterByCategories(Collection<String> selectedCategories) {
        iconsMatchingCategory.clear();
        if (selectedCategories == null || selectedCategories.isEmpty()) {
            iconsMatchingCategory.addAll(allIcons);
        } else {
            for (IconModel icon : allIcons) {
                String iconCategory = Filter.getCategoryFromPath(icon.getPathInZip());
                if (selectedCategories.contains(iconCategory)) {
                    iconsMatchingCategory.add(icon);
                }
            }
        }
        filter(currentQuery);
    }

    public void filter(String query) {
        currentQuery = query;
        filteredIcons.clear();

        if (query.isEmpty()) {
            filteredIcons.addAll(iconsMatchingCategory);
        } else {
            query = query.toLowerCase();
            for (IconModel icon : iconsMatchingCategory) {
                if (icon.getName().toLowerCase().contains(query)) {
                    filteredIcons.add(icon);
                }
            }
        }
        notifyDataSetChanged();
    }

    public IconModel getIconAt(int position) {
        if (filteredIcons != null && position >= 0 && position < filteredIcons.size()) {
            return filteredIcons.get(position);
        }
        return null;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView iconImage;
        TextView iconName;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            iconImage = itemView.findViewById(R.id.icon_image_view);
            iconName = itemView.findViewById(R.id.icon_name_text_view);
        }
    }
}
