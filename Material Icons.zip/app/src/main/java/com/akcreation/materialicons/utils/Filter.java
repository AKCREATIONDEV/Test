package com.akcreation.materialicons.utils;

import com.akcreation.materialicons.models.IconModel;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap; // TreeMap order maintain karne ke liye

public class Filter {

    /**
     * Icon ke FOLDER STRUCTURE se category nikalta hai.
     * Example: "Icons/Action/ic_home.svg" -> returns "Action"
     * Example: "Alerts/ic_bell.svg" -> returns "Alerts"
     */
    public static String getCategoryFromPath(String pathInZip) {
        // Path safety check
        if (pathInZip == null || pathInZip.trim().isEmpty()) {
            return "Uncategorized";
        }

        // Check karein ki file kisi folder mein hai ya nahi ('/' dhoondhein)
        int lastSlashIndex = pathInZip.lastIndexOf('/');

        if (lastSlashIndex != -1) {
            // 1. Filename hata dein. (Ex: "Icons/Action/ic_home.svg" -> "Icons/Action")
            String fullFolderPath = pathInZip.substring(0, lastSlashIndex);

            // 2. Ab sabse aakhri folder ka naam nikalein. 
            // Ex: "Icons/Action" -> "Action"
            // Ex: "Alerts" -> "Alerts"
            int secondLastSlashIndex = fullFolderPath.lastIndexOf('/');
            
            String folderName;
            if (secondLastSlashIndex != -1) {
                folderName = fullFolderPath.substring(secondLastSlashIndex + 1);
            } else {
                folderName = fullFolderPath;
            }

            // 3. Naam ko sundar banayein (First letter capital, underscore hatana)
            return formatCategoryName(folderName);
        }

        // Agar file root par hai (koi folder nahi)
        return "Uncategorized";
    }

    // Helper method: Naam ko saaf aur Capitalize karne ke liye
    private static String formatCategoryName(String text) {
        if (text == null || text.trim().isEmpty()) return "Uncategorized";

        // Underscore ko space se replace karein (e.g., "social_media" -> "social media")
        String cleanText = text.replace("_", " ");

        // Pehla letter bada karein
        if (cleanText.length() > 0) {
            return cleanText.substring(0, 1).toUpperCase() + cleanText.substring(1);
        }
        return cleanText;
    }

    /**
     * Sabhi icons ki list ko category ke hisaab se group karta hai.
     */
    public static Map<String, List<IconModel>> groupIconsByCategory(List<IconModel> allIcons) {
        // TreeMap categories ko alphabetically sort kar dega (A, B, C...)
        Map<String, List<IconModel>> categorizedMap = new TreeMap<>();

        for (IconModel icon : allIcons) {
            // Ab yeh naye folder-based logic se category nikalega
            String category = getCategoryFromPath(icon.getPathInZip());

            List<IconModel> categoryList = categorizedMap.get(category);

            if (categoryList == null) {
                categoryList = new ArrayList<>();
                categorizedMap.put(category, categoryList);
            }

            categoryList.add(icon);
        }
        return categorizedMap;
    }
}
