package com.akcreation.materialicons.models;

import java.io.File;

public class ProjectModel {
    private final String name;
    private final String path;
    private final File file;

    public ProjectModel(File file) {
        this.file = file;
        this.name = file.getName();
        this.path = file.getAbsolutePath();
    }

    public String getName() {
        return name;
    }

    public String getPath() {
        return path;
    }
    
    public File getFile() {
        return file;
    }
}