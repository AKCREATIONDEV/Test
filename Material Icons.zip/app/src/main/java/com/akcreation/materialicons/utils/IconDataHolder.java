package com.akcreation.materialicons.utils;

import java.util.HashMap;
import java.util.Map;

public class IconDataHolder {
    // Yeh map saara heavy data hold karega, lekin efficiently
    private static final Map<String, String> svgDataMap = new HashMap<>();

    // Data save karne ke liye
    public static void putSvg(String path, String content) {
        svgDataMap.put(path, content);
    }

    // Live Data maangne ke liye
    public static String getSvg(String path) {
        return svgDataMap.get(path);
    }

    // Memory free karne ke liye (Jab app band ho)
    public static void clear() {
        svgDataMap.clear();
    }
    
    public static boolean isEmpty() {
        return svgDataMap.isEmpty();
    }
}
