package com.thirtydegreesray.openhub.ui.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.thirtydegreesray.openhub.AppConfig;
import com.thirtydegreesray.openhub.AppData;
import com.thirtydegreesray.openhub.http.RepoService;
import com.thirtydegreesray.openhub.http.core.AppRetrofit;
import com.thirtydegreesray.openhub.mvp.model.FileModel;
import com.thirtydegreesray.openhub.mvp.model.WorkflowFileContent;
import com.thirtydegreesray.openhub.mvp.model.WorkflowFileUpdate;
import com.thirtydegreesray.openhub.ui.widget.YamlLanguage;
import tiiehenry.code.view.CodeEditor;
import tiiehenry.code.view.ColorSchemeLight;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Response;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/** Simple in-app editor for .github/workflows/*.yml and *.yaml files. */
public class WorkflowEditorActivity extends Activity {
    private String owner, repo, branch;
    private RepoService service;
    private ListView list;
    private TextView status;
    private final ArrayList<FileModel> files = new ArrayList<>();

    public static void show(Activity activity, String owner, String repo, String branch) {
        activity.startActivity(new android.content.Intent(activity, WorkflowEditorActivity.class)
                .putExtra("owner", owner).putExtra("repo", repo).putExtra("branch", branch));
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        owner=getIntent().getStringExtra("owner"); repo=getIntent().getStringExtra("repo");
        branch=getIntent().getStringExtra("branch");
        if (branch == null || branch.trim().length()==0) branch="main";
        service= AppRetrofit.INSTANCE.getRetrofit(AppConfig.GITHUB_API_BASE_URL,
                AppData.INSTANCE.getAccessToken()).create(RepoService.class);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16,16,16,16);
        TextView title=new TextView(this); title.setText("Workflow YAML Editor\n"+owner+"/"+repo+" · "+branch);
        title.setTextSize(18); root.addView(title);
        status=new TextView(this); status.setText("Loading workflow files…"); root.addView(status);
        Button refresh=new Button(this); refresh.setText("Refresh workflows");
        refresh.setOnClickListener(v -> loadFiles()); root.addView(refresh);
        list=new ListView(this); root.addView(list,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root); loadFiles();
    }

    private void loadFiles() {
        status.setText("Loading .github/workflows…");
        service.getRepoFiles(owner,repo,".github/workflows",branch)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe(response -> {
                    files.clear();
                    if (response.isSuccessful() && response.body()!=null) {
                        for (FileModel f: response.body()) {
                            String n=f.getName()==null?"":f.getName().toLowerCase();
                            if ("file".equals(f.getType()) && (n.endsWith(".yml")||n.endsWith(".yaml"))) files.add(f);
                        }
                    }
                    ArrayList<String> names=new ArrayList<>();
                    for(FileModel f:files) names.add(f.getPath());
                    list.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,names));
                    status.setText(files.isEmpty()?"No .yml/.yaml workflow files found (or access denied).":"Tap a workflow to edit and commit it.");
                    list.setOnItemClickListener((parent,view,position,id)->openFile(files.get(position)));
                }, error -> status.setText("Could not load workflows: "+error.getLocalizedMessage()));
    }

    private void openFile(FileModel file) {
        status.setText("Loading "+file.getName()+"…");
        service.getWorkflowFile(owner,repo,file.getPath(),branch)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe(response -> {
                    WorkflowFileContent body=response.body();
                    if (!response.isSuccessful() || body==null || body.getContent()==null) {
                        toast("Cannot read file. Check repository permissions."); return;
                    }
                    try {
                        String raw=new String(Base64.decode(body.getContent().replaceAll("\\s", ""),Base64.DEFAULT), Charset.forName("UTF-8"));
                        showEditor(file,body,raw);
                    } catch(Exception e) { toast("Could not decode YAML: "+e.getMessage()); }
                }, error -> toast("Load failed: "+error.getLocalizedMessage()));
    }

    private void showEditor(FileModel file, WorkflowFileContent body, String content) {
        LinearLayout box=new LinearLayout(this); box.setPadding(8,8,8,8); box.setOrientation(LinearLayout.VERTICAL);
        TextView path=new TextView(this); path.setText(file.getPath()); box.addView(path);
        LinearLayout tools=new LinearLayout(this);
        Button undo=new Button(this); undo.setText("Undo");
        Button redo=new Button(this); redo.setText("Redo");
        Button copy=new Button(this); copy.setText("Copy");
        tools.addView(undo,new LinearLayout.LayoutParams(0,-2,1));
        tools.addView(redo,new LinearLayout.LayoutParams(0,-2,1));
        tools.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        box.addView(tools);
        CodeEditor editor=new CodeEditor(this);
        editor.setLanguage(YamlLanguage.getInstance());
        editor.setColorScheme(new ColorSchemeLight());
        editor.setShowLineNumbers(true);
        editor.setWordWrap(false);
        editor.setText(content);
        editor.setTextSize(13);
        editor.setBackgroundColor(0xFFFFFFFF);
        box.addView(editor,new LinearLayout.LayoutParams(-1,0,1));
        undo.setOnClickListener(v -> editor.undo());
        redo.setOnClickListener(v -> editor.redo());
        copy.setOnClickListener(v -> {
            android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Workflow YAML",editor.getString()));
            toast("YAML copied");
        });
        new AlertDialog.Builder(this).setTitle("Edit workflow YAML").setView(box)
                .setNegativeButton("Cancel",null)
                .setNeutralButton("Copy all",(d,w)->{
                    android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("Workflow YAML",editor.getString()));
                    toast("YAML copied");
                })
                .setPositiveButton("Commit & push",(d,w)->saveFile(file,body,editor.getString()))
                .show();
    }

    private void saveFile(FileModel file, WorkflowFileContent old, String text) {
        if (text.trim().length()==0) { toast("Workflow YAML cannot be empty."); return; }
        String encoded=Base64.encodeToString(text.getBytes(Charset.forName("UTF-8")),Base64.NO_WRAP);
        WorkflowFileUpdate update=new WorkflowFileUpdate("Update workflow "+file.getName(),encoded,old.getSha(),branch);
        status.setText("Committing "+file.getName()+"…");
        service.updateWorkflowFile(owner,repo,file.getPath(),update)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe(response -> {
                    if(response.isSuccessful()) { status.setText("Committed successfully: "+file.getName()); toast("Workflow YAML committed and pushed"); loadFiles(); }
                    else { String detail="HTTP "+response.code(); try { ResponseBody b=response.errorBody(); if(b!=null) detail += ": "+b.string(); } catch(Exception ignored){} status.setText("Commit failed: "+detail); toast("Commit failed: "+detail); }
                }, error -> { status.setText("Commit failed: "+error.getLocalizedMessage()); toast("Commit failed: "+error.getLocalizedMessage()); });
    }
    private void toast(String message){ Toast.makeText(this,message,Toast.LENGTH_LONG).show(); }
}
