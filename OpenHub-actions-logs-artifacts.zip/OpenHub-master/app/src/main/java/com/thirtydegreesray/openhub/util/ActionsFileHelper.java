package com.thirtydegreesray.openhub.util;

import com.thirtydegreesray.openhub.http.core.AppRetrofit;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import okhttp3.CacheControl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Network helper for GitHub Actions job logs and artifact archives.
 * <p>
 * Both endpoints answer with a 302 redirect to a short lived pre-signed url. The api request is
 * sent with the access token, the redirect target is then downloaded without any credentials.
 * Must be called from a background thread.
 */
public class ActionsFileHelper {

    /** ESC [ ... m colour codes found in raw logs */
    private static final Pattern ANSI_PATTERN = Pattern.compile("\\u001B\\[[;\\d]*[A-Za-z]");

    private static OkHttpClient plainClient;

    private ActionsFileHelper() {
    }

    /**
     * Downloaded text and whether it was cut because it is too big.
     */
    public static class TextResult {
        public final String text;
        public final boolean truncated;

        public TextResult(String text, boolean truncated) {
            this.text = text;
            this.truncated = truncated;
        }
    }

    /**
     * Calls the given GitHub api url (with token) and returns the url of the 302 redirect.
     *
     * @throws IOException with GitHub's message when the request is rejected
     *                     (e.g. 410 "Logs have expired")
     */
    public static String resolveRedirectUrl(String apiUrl) throws IOException {
        Request request = new Request.Builder()
                .url(apiUrl)
                // the redirect url expires within a minute, never take it from the cache
                .cacheControl(CacheControl.FORCE_NETWORK)
                .build();
        Response response = AppRetrofit.INSTANCE.getNoRedirectClient().newCall(request).execute();
        ResponseBody body = response.body();
        try {
            if (response.isRedirect()) {
                String location = response.header("Location");
                if (!StringUtils.isBlank(location)) return location;
            }
            if (!response.isSuccessful()) {
                throw new IOException(getFailureMessage(response.code(), response.message(), body));
            }
            throw new IOException("Unexpected response: " + response.code());
        } finally {
            if (body != null) body.close();
        }
    }

    /**
     * Downloads text from a pre-signed url. When the file is bigger than maxBytes only the
     * last maxBytes are returned (the end of a log holds the failure).
     */
    public static TextResult loadText(String url, int maxBytes) throws IOException {
        Request request = new Request.Builder().url(url).build();
        Response response = getPlainClient().newCall(request).execute();
        ResponseBody body = response.body();
        try {
            if (!response.isSuccessful() || body == null) {
                throw new IOException(getFailureMessage(response.code(), response.message(), body));
            }
            InputStream in = body.byteStream();
            long length = body.contentLength();
            boolean truncated = false;
            if (length > maxBytes) {
                truncated = true;
                skipFully(in, length - maxBytes);
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[16 * 1024];
            int count;
            while ((count = in.read(buffer)) != -1) {
                out.write(buffer, 0, count);
            }
            byte[] bytes = out.toByteArray();
            int offset = 0;
            if (bytes.length > maxBytes) {
                // content length was unknown
                truncated = true;
                offset = bytes.length - maxBytes;
            }
            String text = new String(bytes, offset, bytes.length - offset, "UTF-8");
            if (truncated) {
                // the cut most likely happened inside a line
                int firstLineEnd = text.indexOf('\n');
                if (firstLineEnd >= 0 && firstLineEnd < text.length() - 1) {
                    text = text.substring(firstLineEnd + 1);
                }
            }
            return new TextResult(cleanLog(text), truncated);
        } finally {
            if (body != null) body.close();
        }
    }

    /**
     * Removes the byte order mark and ANSI colour escape sequences.
     */
    public static String cleanLog(String text) {
        if (text.length() > 0 && text.charAt(0) == '\uFEFF') {
            text = text.substring(1);
        }
        return ANSI_PATTERN.matcher(text).replaceAll("");
    }

    private static void skipFully(InputStream in, long count) throws IOException {
        long remaining = count;
        while (remaining > 0) {
            long skipped = in.skip(remaining);
            if (skipped <= 0) {
                // skip() may return 0, fall back to reading one byte
                if (in.read() == -1) return;
                skipped = 1;
            }
            remaining -= skipped;
        }
    }

    private static synchronized OkHttpClient getPlainClient() {
        if (plainClient == null) {
            plainClient = new OkHttpClient.Builder()
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(60, TimeUnit.SECONDS)
                    .build();
        }
        return plainClient;
    }

    /**
     * "410: Logs have expired..." using GitHub's JSON message when there is one.
     */
    private static String getFailureMessage(int code, String httpMessage, ResponseBody body) {
        String message = null;
        try {
            if (body != null) {
                message = new JSONObject(body.string()).optString("message", null);
            }
        } catch (Exception ignored) {
            // not JSON
        }
        if (StringUtils.isBlank(message)) message = httpMessage;
        return StringUtils.isBlank(message) ? String.valueOf(code) : code + ": " + message;
    }

}
