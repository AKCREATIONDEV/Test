# AK Code Editor

A standalone Android code editor extracted from the TaoKDao project. The original application features (plugins, terminal, file explorer, markdown reader, web views, settings screens and unrelated modules) have been removed. The editor engine and its language lexer/parser modules are retained.

## Included modules

- `app` — minimal standalone editor application (`com.akcreation.codeeditor`)
- `CodeEditor` — text editing engine, document model, selection, undo/redo, rendering and input handling
- `CodeEditorAntlr` — language tokenization and syntax highlighting

## Editor features

- Code editing with line numbers, current-line highlight, auto-indent and autocomplete
- Syntax highlighting and language selection
- Open and save text/code files through Android Storage Access Framework
- Undo / redo
- Find text and go to line
- Dark/light editor theme, word wrap and font-size controls
- Pinch zoom and editor navigation inherited from the original engine

## Languages

Text, Java, Kotlin, JavaScript, ECMAScript, C, C++, Python, Python (legacy), XML, HTML, CSS, JSON, Lua, Markdown, Bash, Objective-C.

## Build

- JDK 17
- Android SDK Platform 36
- Gradle 8.13 (wrapper included)
- Android Gradle Plugin 8.13.0

Build a debug APK:

```bash
./gradlew :app:assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

The project uses Android Storage Access Framework; it does not request broad external-storage permissions.
