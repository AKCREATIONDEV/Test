package com.thirtydegreesray.openhub.ui.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.support.v7.widget.PopupMenu;
import android.graphics.Typeface;

import com.thirtydegreesray.openhub.AppConfig;
import com.thirtydegreesray.openhub.AppData;
import com.thirtydegreesray.openhub.http.RepoService;
import com.thirtydegreesray.openhub.http.core.AppRetrofit;
import com.thirtydegreesray.openhub.mvp.model.WorkflowFileUpdate;
import com.thirtydegreesray.openhub.ui.widget.YamlLanguage;

import java.nio.charset.Charset;

import okhttp3.ResponseBody;
import tiiehenry.code.language.LanguageNonProg;
import tiiehenry.code.language.java.JavaLanguage;
import tiiehenry.code.language.xml.XMLLanguage;
import tiiehenry.code.language.javascript.JavaScriptLanguage;
import tiiehenry.code.language.python.PythonLanguage;
import tiiehenry.code.language.php.PHPLanguage;
import tiiehenry.code.language.cpp.CppLanguage;
import tiiehenry.code.language.csharp.CSharpLanguage;
import tiiehenry.code.view.CodeEditor;
import tiiehenry.code.view.ColorSchemeLight;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/** Dedicated full-screen code editor used for workflow files, repository source and Actions logs. */
public class CodeEditorActivity extends Activity {
    private static final String MODE_WORKFLOW = "workflow";
    private static final String MODE_LOG = "log";
    private static final String MODE_REPO_FILE = "repo_file";

    private CodeEditor editor;
    private TextView status, titleView;
    private String owner, repo, branch, path, sha, mode, sourceUrl;
    private RepoService service;
    private boolean wrapEnabled;

    public static void openWorkflow(Activity a, String owner, String repo, String branch,
                                    String path, String sha, String content) {
        a.startActivity(new android.content.Intent(a, CodeEditorActivity.class)
                .putExtra("mode", MODE_WORKFLOW).putExtra("owner", owner)
                .putExtra("repo", repo).putExtra("branch", branch)
                .putExtra("path", path).putExtra("sha", sha).putExtra("content", content));
    }

    public static void openLogs(Activity a, String title, String content) {
        a.startActivity(new android.content.Intent(a, CodeEditorActivity.class)
                .putExtra("mode", MODE_LOG).putExtra("title", title)
                .putExtra("content", content));
    }

    public static void openRepositoryFile(Activity a, String title, String url) {
        a.startActivity(new android.content.Intent(a, CodeEditorActivity.class)
                .putExtra("mode", MODE_REPO_FILE).putExtra("title", title)
                .putExtra("source_url", url));
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        mode = getIntent().getStringExtra("mode");
        owner = getIntent().getStringExtra("owner");
        repo = getIntent().getStringExtra("repo");
        branch = getIntent().getStringExtra("branch");
        path = getIntent().getStringExtra("path");
        sha = getIntent().getStringExtra("sha");
        sourceUrl = getIntent().getStringExtra("source_url");

        final boolean workflow = MODE_WORKFLOW.equals(mode);
        final boolean logs = MODE_LOG.equals(mode);
        final boolean repoFile = MODE_REPO_FILE.equals(mode);
        String titleText = workflow ? path : getIntent().getStringExtra("title");
        if (titleText == null || titleText.length() == 0) titleText = "Code Editor";
        if (workflow && titleText.contains("/")) titleText = titleText.substring(titleText.lastIndexOf("/") + 1);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF5F5F5);

        // Screenshot-inspired top app bar: back, filename, undo, redo, commit, overflow.
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setBackgroundColor(0xFF009688);
        TextView back = toolbarText("‹", 34, 52);
        back.setOnClickListener(v -> finish());
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(56)));

        titleView = toolbarText(titleText, 18, 0);
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleView.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        toolbar.addView(titleView, new LinearLayout.LayoutParams(0, dp(56), 1));

        TextView undo = toolbarText("↶", 25, 48);
        TextView redo = toolbarText("↷", 25, 48);
        TextView commit = toolbarText("↑", 24, 48);
        TextView more = toolbarText("⋮", 27, 44);
        toolbar.addView(undo, new LinearLayout.LayoutParams(dp(40), dp(56)));
        toolbar.addView(redo, new LinearLayout.LayoutParams(dp(40), dp(56)));
        if (workflow) toolbar.addView(commit, new LinearLayout.LayoutParams(dp(40), dp(56)));
        toolbar.addView(more, new LinearLayout.LayoutParams(dp(40), dp(56)));
        root.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(56)));

        status = new TextView(this);
        status.setTextColor(0xFF666666);
        status.setTextSize(12);
        status.setPadding(dp(10), dp(5), dp(10), dp(5));
        status.setText(workflow ? owner + "/" + repo + " · " + branch + " · " + path
                : logs ? "GitHub Actions · Read-only" : "Repository source · Read-only");
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        editor = new CodeEditor(this);
        editor.setColorScheme(new ColorSchemeLight());
        editor.setShowLineNumbers(true);
        editor.setHighlightCurrentRow(true);
        editor.setTextSize(12);
        editor.setPadding(dp(8), dp(8), dp(8), dp(8));
        editor.setBackgroundColor(0xFFFFFFFF);
        wrapEnabled = logs;
        editor.setWordWrap(wrapEnabled);
        editor.setLanguage(workflow ? YamlLanguage.getInstance()
                : logs ? LanguageNonProg.getInstance() : languageFor(titleText));
        if (workflow) {
            editor.setText(getIntent().getStringExtra("content") == null ? "" : getIntent().getStringExtra("content"));
        } else if (logs) {
            editor.setText(getIntent().getStringExtra("content") == null ? "" : getIntent().getStringExtra("content"));
        } else {
            editor.setText("Loading " + titleText + "…");
        }
        root.addView(editor, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        undo.setEnabled(workflow);
        redo.setEnabled(workflow);
        undo.setAlpha(workflow ? 1f : 0.35f);
        redo.setAlpha(workflow ? 1f : 0.35f);
        undo.setOnClickListener(v -> editor.undo());
        redo.setOnClickListener(v -> editor.redo());
        if (workflow) {
            commit.setOnClickListener(v -> confirmSave());
        } else {
            commit.setVisibility(View.GONE);
        }

        more.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(this, more);
            popup.getMenu().add(0, 1, 0, "Copy code");
            popup.getMenu().add(0, 2, 1, (wrapEnabled ? "Disable" : "Enable") + " line wrap");
            popup.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == 1) copyAll();
                else if (item.getItemId() == 2) {
                    wrapEnabled = !wrapEnabled;
                    editor.setWordWrap(wrapEnabled);
                    status.setText((workflow ? owner + "/" + repo + " · " + branch + " · " + path
                            : logs ? "GitHub Actions · Read-only" : "Repository source · Read-only")
                            + (wrapEnabled ? " · Wrap on" : " · Wrap off"));
                }
                return true;
            });
            popup.show();
        });

        if (workflow || repoFile) {
            service = AppRetrofit.INSTANCE.getRetrofit(AppConfig.GITHUB_API_BASE_URL,
                    AppData.INSTANCE.getAccessToken()).create(RepoService.class);
        }
        if (repoFile) loadRepositoryFile();
    }

    private TextView toolbarText(String text, int size, int width) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(0xFFFFFFFF);
        v.setTextSize(size);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        return v;
    }

    private tiiehenry.code.language.Language languageFor(String filename) {
        String n = filename == null ? "" : filename.toLowerCase(java.util.Locale.US);
        if (n.endsWith(".java")) return JavaLanguage.getInstance();
        if (n.endsWith(".xml") || n.endsWith(".html") || n.endsWith(".htm")) return XMLLanguage.getInstance();
        if (n.endsWith(".js") || n.endsWith(".jsx")) return JavaScriptLanguage.getInstance();
        if (n.endsWith(".py")) return PythonLanguage.getInstance();
        if (n.endsWith(".php")) return PHPLanguage.getInstance();
        if (n.endsWith(".c") || n.endsWith(".h") || n.endsWith(".cpp") || n.endsWith(".cc") || n.endsWith(".hpp")) return CppLanguage.getInstance();
        if (n.endsWith(".cs")) return CSharpLanguage.getInstance();
        if (n.endsWith(".yml") || n.endsWith(".yaml")) return YamlLanguage.getInstance();
        return LanguageNonProg.getInstance();
    }

    private void loadRepositoryFile() {
        if (sourceUrl == null || sourceUrl.length() == 0) {
            status.setText("Cannot load file: missing GitHub content URL");
            return;
        }
        status.setText("Loading source from GitHub…");
        service.getFileAsStream(true, sourceUrl)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe(response -> {
                    if (response.isSuccessful() && response.body() != null) {
                        try {
                            String content = response.body().string();
                            editor.setText(content);
                            status.setText("Repository source · Read-only · " + content.length() + " characters");
                        } catch (Exception e) {
                            status.setText("Could not read source: " + e.getMessage());
                        }
                    } else {
                        status.setText("Could not load source · HTTP " + response.code());
                    }
                }, error -> status.setText("Could not load source: " + error.getLocalizedMessage()));
    }

    private void copyAll() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Editor content", editor.getString()));
        toast("Copied to clipboard");
    }

    private void confirmSave() {
        if (editor.getString().trim().length() == 0) {
            toast("Workflow YAML cannot be empty");
            return;
        }
        new AlertDialog.Builder(this).setTitle("Commit workflow changes?")
                .setMessage("Commit changes to " + path + " on " + branch + "?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Commit", (d, w) -> saveFile()).show();
    }

    private void saveFile() {
        status.setText("Committing workflow file…");
        String encoded = Base64.encodeToString(editor.getString().getBytes(Charset.forName("UTF-8")), Base64.NO_WRAP);
        WorkflowFileUpdate update = new WorkflowFileUpdate("Update workflow " + path, encoded, sha, branch);
        service.updateWorkflowFile(owner, repo, path, update)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe(response -> {
                    if (response.isSuccessful()) {
                        status.setText("Committed successfully");
                        toast("Workflow YAML committed and pushed");
                    } else {
                        String detail = "HTTP " + response.code();
                        try { ResponseBody b = response.errorBody(); if (b != null) detail += ": " + b.string(); }
                        catch (Exception ignored) { }
                        status.setText("Commit failed: " + detail);
                        toast("Commit failed: " + detail);
                    }
                }, error -> {
                    status.setText("Commit failed: " + error.getLocalizedMessage());
                    toast("Commit failed: " + error.getLocalizedMessage());
                });
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
}
