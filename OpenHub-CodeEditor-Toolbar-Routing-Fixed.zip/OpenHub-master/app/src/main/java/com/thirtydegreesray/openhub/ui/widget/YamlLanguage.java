package com.thirtydegreesray.openhub.ui.widget;
import tiiehenry.code.language.Language;
/** Lightweight YAML language profile for the embedded CodeEditor. */
public final class YamlLanguage extends Language {
 private static YamlLanguage instance;
 private YamlLanguage() {
  setKeywords(new String[]{"name","on","jobs","steps","runs-on","uses","run","with","env","permissions","workflow_dispatch","push","pull_request","schedule","branches","paths","needs","if","strategy","matrix","outputs","timeout-minutes","continue-on-error","working-directory","defaults","concurrency","environment","services","container","secrets","vars","github","actions","checkout","contents","read","write"});
  setOperators(new char[]{':','-','{','}','[',']',',','?','|','>','&','*','!','%','@','`'});
 }
 public static synchronized YamlLanguage getInstance(){if(instance==null)instance=new YamlLanguage();return instance;}
}
