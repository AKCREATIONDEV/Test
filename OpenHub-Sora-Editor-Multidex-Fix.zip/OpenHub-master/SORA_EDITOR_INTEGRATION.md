# Sora Editor integration

OpenHub now uses Sora Editor 0.24.4 as its only code editing/viewing widget. The previous `tiiehenry.code` editor implementation and its custom lexer/color-scheme classes have been removed.

- Sora core + TextMate grammar support only; the separate demo app, file picker and standalone save workflow from the supplied Sora project were not copied.
- Workflow YAML opens in the dedicated Sora editor page and remains editable/committable through the existing GitHub Contents API.
- Repository source and Actions logs open in the same Sora editor page in read-only mode; read-only mode does not disable touch scrolling or text selection.
- TextMate assets include Java, Python, JavaScript, XML, JSON, Kotlin, Gradle/Groovy and YAML scopes.
- Sora 0.24.4 requires Java 17 source/target and core-library desugaring for TextMate. Android minSdk remains 21.
- Android Support Library imports/resources were migrated to AndroidX/Material because Sora depends on AndroidX. Jetifier remains enabled for older third-party libraries.

Sora Editor is licensed under LGPL-2.1. See the upstream license at https://github.com/Rosemoe/sora-editor.
