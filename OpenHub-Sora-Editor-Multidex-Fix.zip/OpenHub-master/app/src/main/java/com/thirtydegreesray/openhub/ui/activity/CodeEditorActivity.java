package com.thirtydegreesray.openhub.ui.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.ClipData;
import android.content.ClipboardManager;
import androidx.appcompat.widget.PopupMenu;
import android.graphics.Typeface;

import com.thirtydegreesray.openhub.AppConfig;
import com.thirtydegreesray.openhub.AppData;
import com.thirtydegreesray.openhub.http.RepoService;
import com.thirtydegreesray.openhub.http.core.AppRetrofit;
import com.thirtydegreesray.openhub.mvp.model.WorkflowFileUpdate;

import java.io.InputStream;
import java.nio.charset.Charset;

import io.github.rosemoe.sora.widget.CodeEditor;
import io.github.rosemoe.sora.widget.schemes.EditorColorScheme;
import io.github.rosemoe.sora.langs.textmate.TextMateColorScheme;
import io.github.rosemoe.sora.langs.textmate.TextMateLanguage;
import io.github.rosemoe.sora.langs.textmate.registry.FileProviderRegistry;
import io.github.rosemoe.sora.langs.textmate.registry.GrammarRegistry;
import io.github.rosemoe.sora.langs.textmate.registry.ThemeRegistry;
import io.github.rosemoe.sora.langs.textmate.registry.model.ThemeModel;
import io.github.rosemoe.sora.langs.textmate.registry.provider.AssetsFileResolver;
import org.eclipse.tm4e.core.registry.IThemeSource;

import okhttp3.ResponseBody;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/** Dedicated Sora editor page for workflow YAML, repository source and Actions logs. */
public class CodeEditorActivity extends Activity {
    private static final String MODE_WORKFLOW = "workflow";
    private static final String MODE_LOG = "log";
    private static final String MODE_REPO_FILE = "repo_file";
    private static volatile boolean textMateReady;
    private static volatile boolean textMateAttempted;

    private CodeEditor editor;
    private TextView status, titleView;
    private String owner, repo, branch, path, sha, mode, sourceUrl;
    private RepoService service;
    private boolean wrapEnabled;

    public static void openWorkflow(Activity a, String owner, String repo, String branch,
                                    String path, String sha, String content) {
        a.startActivity(new android.content.Intent(a, CodeEditorActivity.class)
                .putExtra("mode", MODE_WORKFLOW).putExtra("owner", owner)
                .putExtra("repo", repo).putExtra("branch", branch)
                .putExtra("path", path).putExtra("sha", sha).putExtra("content", content));
    }

    public static void openLogs(Activity a, String title, String content) {
        a.startActivity(new android.content.Intent(a, CodeEditorActivity.class)
                .putExtra("mode", MODE_LOG).putExtra("title", title)
                .putExtra("content", content));
    }

    public static void openRepositoryFile(Activity a, String title, String url) {
        a.startActivity(new android.content.Intent(a, CodeEditorActivity.class)
                .putExtra("mode", MODE_REPO_FILE).putExtra("title", title)
                .putExtra("source_url", url));
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        mode = getIntent().getStringExtra("mode");
        owner = getIntent().getStringExtra("owner");
        repo = getIntent().getStringExtra("repo");
        branch = getIntent().getStringExtra("branch");
        path = getIntent().getStringExtra("path");
        sha = getIntent().getStringExtra("sha");
        sourceUrl = getIntent().getStringExtra("source_url");

        final boolean workflow = MODE_WORKFLOW.equals(mode);
        final boolean logs = MODE_LOG.equals(mode);
        final boolean repoFile = MODE_REPO_FILE.equals(mode);
        String titleText = workflow ? path : getIntent().getStringExtra("title");
        if (titleText == null || titleText.length() == 0) titleText = "Code Editor";
        if (workflow && titleText.contains("/")) titleText = titleText.substring(titleText.lastIndexOf("/") + 1);

        initializeTextMate();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF5F5F5);

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setBackgroundColor(0xFF009688);
        TextView back = toolbarText("‹", 34);
        back.setOnClickListener(v -> finish());
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(56)));

        titleView = toolbarText(titleText, 18);
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleView.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        toolbar.addView(titleView, new LinearLayout.LayoutParams(0, dp(56), 1));

        TextView undo = toolbarText("↶", 25);
        TextView redo = toolbarText("↷", 25);
        TextView commit = toolbarText("↑", 24);
        TextView more = toolbarText("⋮", 27);
        toolbar.addView(undo, new LinearLayout.LayoutParams(dp(40), dp(56)));
        toolbar.addView(redo, new LinearLayout.LayoutParams(dp(40), dp(56)));
        if (workflow) toolbar.addView(commit, new LinearLayout.LayoutParams(dp(40), dp(56)));
        toolbar.addView(more, new LinearLayout.LayoutParams(dp(40), dp(56)));
        root.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(56)));

        status = new TextView(this);
        status.setTextColor(0xFF666666);
        status.setTextSize(12);
        status.setPadding(dp(10), dp(5), dp(10), dp(5));
        status.setText(workflow ? owner + "/" + repo + " · " + branch + " · " + path
                : logs ? "GitHub Actions · Read-only" : "Repository source · Read-only");
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        editor = new CodeEditor(this);
        if (textMateReady) {
            editor.setColorScheme(TextMateColorScheme.create(ThemeRegistry.getInstance()));
        } else {
            editor.setColorScheme(EditorColorScheme.getDefault());
        }
        editor.setLineNumberEnabled(true);
        editor.setHighlightCurrentLine(true);
        editor.setHighlightCurrentBlock(true);
        editor.setTextSize(13f);
        editor.setTabWidth(4);
        editor.setTypefaceText(Typeface.MONOSPACE);
        editor.setPadding(dp(8), dp(8), dp(8), dp(8));
        wrapEnabled = logs;
        editor.setWordwrap(wrapEnabled);
        editor.setEditable(workflow);
        editor.setScalable(true);
        editor.setScrollBarEnabled(true);

        String initial = getIntent().getStringExtra("content");
        if (initial == null) initial = "";
        if (workflow) {
            applyLanguage(path);
            editor.setText(initial);
        } else if (logs) {
            // Logs are plain text and remain scrollable/selectable but not editable.
            editor.setText(initial);
        } else {
            applyLanguage(titleText);
            editor.setText("Loading " + titleText + "…");
        }
        root.addView(editor, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        undo.setEnabled(workflow);
        redo.setEnabled(workflow);
        undo.setAlpha(workflow ? 1f : 0.35f);
        redo.setAlpha(workflow ? 1f : 0.35f);
        undo.setOnClickListener(v -> editor.undo());
        redo.setOnClickListener(v -> editor.redo());
        if (workflow) commit.setOnClickListener(v -> confirmSave());

        more.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(this, more);
            popup.getMenu().add(0, 1, 0, "Copy code");
            popup.getMenu().add(0, 2, 1, (wrapEnabled ? "Disable" : "Enable") + " line wrap");
            popup.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == 1) copyAll();
                else if (item.getItemId() == 2) {
                    wrapEnabled = !wrapEnabled;
                    editor.setWordwrap(wrapEnabled);
                    status.setText((workflow ? owner + "/" + repo + " · " + branch + " · " + path
                            : logs ? "GitHub Actions · Read-only" : "Repository source · Read-only")
                            + (wrapEnabled ? " · Wrap on" : " · Wrap off"));
                }
                return true;
            });
            popup.show();
        });

        if (workflow || repoFile) {
            service = AppRetrofit.INSTANCE.getRetrofit(AppConfig.GITHUB_API_BASE_URL,
                    AppData.INSTANCE.getAccessToken()).create(RepoService.class);
        }
        if (repoFile) loadRepositoryFile();
    }

    private void initializeTextMate() {
        if (textMateReady || textMateAttempted) return;
        synchronized (CodeEditorActivity.class) {
            if (textMateReady || textMateAttempted) return;
            textMateAttempted = true;
            try {
                FileProviderRegistry.getInstance().addFileProvider(
                        new AssetsFileResolver(getApplicationContext().getAssets()));
                ThemeRegistry themes = ThemeRegistry.getInstance();
                String themePath = "textmate/openhub-light-theme.json";
                InputStream input = FileProviderRegistry.getInstance().tryGetInputStream(themePath);
                if (input == null) throw new IllegalStateException("Missing TextMate theme: " + themePath);
                try {
                    ThemeModel theme = new ThemeModel(IThemeSource.fromInputStream(input, themePath, null), "openhub-light");
                    theme.setDark(false);
                    themes.loadTheme(theme);
                    themes.setTheme("openhub-light");
                } finally {
                    input.close();
                }
                GrammarRegistry.getInstance().loadGrammars("textmate/languages.json");
                textMateReady = true;
            } catch (Throwable error) {
                textMateReady = false;
                Toast.makeText(this, "Syntax highlighting unavailable: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    private void applyLanguage(String filename) {
        if (!textMateReady) return;
        String n = filename == null ? "" : filename.toLowerCase(java.util.Locale.US);
        String scope = null;
        if (n.endsWith(".java")) scope = "source.java";
        else if (n.endsWith(".kt") || n.endsWith(".kts")) scope = "source.kotlin";
        else if (n.endsWith(".gradle")) scope = "source.groovy";
        else if (n.endsWith(".yml") || n.endsWith(".yaml")) scope = "source.yaml";
        else if (n.endsWith(".json") || n.endsWith(".jsonc")) scope = "source.json";
        else if (n.endsWith(".xml") || n.endsWith(".html") || n.endsWith(".htm")) scope = "text.xml";
        else if (n.endsWith(".js") || n.endsWith(".jsx") || n.endsWith(".mjs")) scope = "source.js";
        else if (n.endsWith(".py")) scope = "source.python";
        if (scope != null) {
            try { editor.setEditorLanguage(TextMateLanguage.create(scope, true)); }
            catch (Throwable error) { status.setText("Syntax grammar unavailable for " + filename); }
        }
    }

    private TextView toolbarText(String text, int size) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(0xFFFFFFFF);
        v.setTextSize(size);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        return v;
    }

    private void loadRepositoryFile() {
        if (sourceUrl == null || sourceUrl.length() == 0) {
            status.setText("Cannot load file: missing GitHub content URL");
            return;
        }
        status.setText("Loading source from GitHub…");
        service.getFileAsStream(true, sourceUrl)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe(response -> {
                    if (response.isSuccessful() && response.body() != null) {
                        try {
                            String content = response.body().string();
                            applyLanguage(path == null ? titleView.getText().toString() : path);
                            status.setText("Repository source · Read-only · " + content.length() + " characters");
                            editor.setText(content);
                        } catch (Exception e) {
                            status.setText("Could not read source: " + e.getMessage());
                        }
                    } else {
                        status.setText("Could not load source · HTTP " + response.code());
                    }
                }, error -> status.setText("Could not load source: " + error.getLocalizedMessage()));
    }

    private void copyAll() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Editor content", editor.getText().toString()));
        toast("Copied to clipboard");
    }

    private void confirmSave() {
        if (editor.getText().toString().trim().length() == 0) {
            toast("Workflow YAML cannot be empty");
            return;
        }
        new AlertDialog.Builder(this).setTitle("Commit workflow changes?")
                .setMessage("Commit changes to " + path + " on " + branch + "?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Commit", (d, w) -> saveFile()).show();
    }

    private void saveFile() {
        status.setText("Committing workflow file…");
        String encoded = Base64.encodeToString(editor.getText().toString().getBytes(Charset.forName("UTF-8")), Base64.NO_WRAP);
        WorkflowFileUpdate update = new WorkflowFileUpdate("Update workflow " + path, encoded, sha, branch);
        service.updateWorkflowFile(owner, repo, path, update)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe(response -> {
                    if (response.isSuccessful()) {
                        status.setText("Committed successfully");
                        toast("Workflow YAML committed and pushed");
                    } else {
                        String detail = "HTTP " + response.code();
                        try { ResponseBody b = response.errorBody(); if (b != null) detail += ": " + b.string(); }
                        catch (Exception ignored) { }
                        status.setText("Commit failed: " + detail);
                        toast("Commit failed: " + detail);
                    }
                }, error -> {
                    status.setText("Commit failed: " + error.getLocalizedMessage());
                    toast("Commit failed: " + error.getLocalizedMessage());
                });
    }

    @Override protected void onDestroy() {
        if (editor != null) editor.release();
        super.onDestroy();
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
}
