# إخفاء كل الأسماء
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-dontskipnonpubliclibraryclassmembers

# تشويش قوي
-overloadaggressively
-repackageclasses ''
-flattenpackagehierarchy ''

# إزالة اللوج
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}

# منع فك الكود بسهولة
-renamesourcefileattribute SourceFile
-keepattributes LineNumberTable

# تشويش كل الكلاسات
-keep class * {
    *;
}