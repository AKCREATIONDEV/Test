cmake_minimum_required(VERSION 3.4.1)

project(livaibbox)

include_directories(JniHook)
include_directories(./)

file(GLOB SRC1 "./*.cpp")
file(GLOB SRC2 "Utils/*.cpp")
file(GLOB SRC3 "Hook/*.cpp")
file(GLOB SRC4 "JniHook/*.cpp")

add_compile_options(-w)

add_library(
        livaibbox
        SHARED
        BoxCore.cpp
        Hook/AudioHook.cpp
        Hook/DexFileHook.cpp
        ${SRC1}
        ${SRC2}
        ${SRC3}
        ${SRC4}
)

find_library(log-lib log)
find_library(z-lib z)
find_library(dl-lib dl)
find_library(m-lib m)

target_link_libraries(
        livaibbox
        ${log-lib}
        ${z-lib}
        ${dl-lib}
        ${m-lib}
        android
)