#include <pthread.h>
#include <chrono>
#include <thread>
#include <android/log.h>
#include <algorithm>

#define TAG "ThirdPartyFix"
#define ALOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__)
#define ALOGW(...) __android_log_print(ANDROID_LOG_WARN,  TAG, __VA_ARGS__)
#define ALOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

#define SLEEP_TIME (1000LL / 120LL)

/*
struct sRegion {
    uintptr_t start, end;
};

std::vector<sRegion> trapRegions;

bool isObjectInvalid(UObject *obj) {
    if (!Tools::IsPtrValid(obj)) return true;
    if (!Tools::IsPtrValid(obj->ClassPrivate)) return true;
    if (obj->InternalIndex <= 0) return true;
    if (obj->NamePrivate.ComparisonIndex <= 0) return true;
    if ((uintptr_t)(obj) % sizeof(uintptr_t) != 0x0 && (uintptr_t)(obj) % sizeof(uintptr_t) != 0x4) return true;
    if (std::any_of(trapRegions.begin(), trapRegions.end(), [obj](sRegion region) {
            return ((uintptr_t)obj) >= region.start && ((uintptr_t)obj) <= region.end;
        }) || std::any_of(trapRegions.begin(), trapRegions.end(), [obj](sRegion region) {
            return ((uintptr_t)obj->ClassPrivate) >= region.start && ((uintptr_t)obj->ClassPrivate) <= region.end;
        }))
    {
        return true;
    }
    return false;
}


[[noreturn]] void *THIRD_PARTY_FIXED(void *) {
    ALOGD("Thread started for THIRD_PARTY_FIXED");

    while (true) {
        auto startTime = std::chrono::duration_cast<std::chrono::milliseconds>(
                             std::chrono::system_clock::now().time_since_epoch())
                             .count();

        // Get global objects safely (avoid invalid memory access)
        auto objects = UObject::GetGlobalObjects();
        if (objects.Num() <= 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            continue;
        }

        for (int i = 0; i < objects.Num(); i++) {
            auto object = objects.GetByIndex(i);
            if (!object) continue;
            // if (isObjectInvalid(object)) continue;  // Optional check

            if (object->IsA(UBulletHitInfoUploadComponent::StaticClass())) {
                auto bulletComponent = (UBulletHitInfoUploadComponent *)object;
                // Disable remote reporting (offline-safe settings)
                bulletComponent->bEnableTssSdkAntiData = 0;
                bulletComponent->bEnableTssSdkAntiDataFilter = 0;
                bulletComponent->bEnableTssSdkAntiDataFilterNew = 0;
                bulletComponent->bDisableDsTick = 1;
                bulletComponent->bDisableDsAntiDataReport = 1;
                bulletComponent->bEnableAddSPCShootData = 0;
                bulletComponent->NeedSendSimpleCharacterHitData = 0;
            }
        }

        auto endTime = std::chrono::duration_cast<std::chrono::milliseconds>(
                           std::chrono::system_clock::now().time_since_epoch())
                           .count();
        auto elapsedTime = endTime - startTime;

        long delay = std::max(1LL, SLEEP_TIME - elapsedTime);
        std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    }
}

__attribute__((constructor)) void mainload() {
    pthread_t ptid;
    if (pthread_create(&ptid, 0, THIRD_PARTY_FIXED, 0) == 0) {
        ALOGD("THIRD_PARTY_FIXED thread created successfully");
    } else {
        ALOGE("Failed to create THIRD_PARTY_FIXED thread");
    }
}
*/