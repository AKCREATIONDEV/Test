#include "BoxCore.h"
#include "IO.h"
#include <jni.h>
#include <JniHook/JniHook.h>
#include <Hook/VMClassLoaderHook.h>
#include <Hook/UnixFileSystemHook.h>
#include <Hook/BinderHook.h>
#include <Hook/DexFileHook.h>
#include <Hook/RuntimeHook.h>
#include <Hook/AudioHook.h>
#include "Utils/SeccompUtils.h"
#include <android/log.h>

#define LOG_TAG "BoxCore"
#define write_log(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)

struct {
    JavaVM *vm;
    jclass NativeCoreClass;
    jmethodID getCallingUidId;
    jmethodID redirectPathString;
    jmethodID redirectPathFile;
    jmethodID loadEmptyDex;
    jmethodID loadEmptyDexL;
    int api_level;
    bool hooks_initialized;
} VMEnv = {nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, 0, false};

JNIEnv *getEnv() {
    JNIEnv *env;
    VMEnv.vm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6);
    return env;
}

JNIEnv *ensureEnvCreated() {
    JNIEnv *env = getEnv();
    if (env == NULL) {
        VMEnv.vm->AttachCurrentThread(&env, NULL);
    }
    return env;
}

int BoxCore::getCallingUid(JNIEnv *env, int orig) {
    env = ensureEnvCreated();
    if (!VMEnv.NativeCoreClass || !VMEnv.getCallingUidId) {
        return orig;
    }
    return env->CallStaticIntMethod(VMEnv.NativeCoreClass, VMEnv.getCallingUidId, orig);
}

jstring BoxCore::redirectPathString(JNIEnv *env, jstring path) {
    env = ensureEnvCreated();
    if (!VMEnv.NativeCoreClass || !VMEnv.redirectPathString) {
        return path;
    }
    return (jstring) env->CallStaticObjectMethod(VMEnv.NativeCoreClass, VMEnv.redirectPathString, path);
}

jobject BoxCore::redirectPathFile(JNIEnv *env, jobject path) {
    env = ensureEnvCreated();
    if (!VMEnv.NativeCoreClass || !VMEnv.redirectPathFile) {
        return path;
    }
    return env->CallStaticObjectMethod(VMEnv.NativeCoreClass, VMEnv.redirectPathFile, path);
}

jlongArray BoxCore::loadEmptyDex(JNIEnv *env) {
    env = ensureEnvCreated();
    if (!VMEnv.NativeCoreClass || !VMEnv.loadEmptyDex) {
        return nullptr;
    }
    return (jlongArray) env->CallStaticObjectMethod(VMEnv.NativeCoreClass, VMEnv.loadEmptyDex);
}

int BoxCore::getApiLevel() {
    return VMEnv.api_level;
}

JavaVM *BoxCore::getJavaVM() {
    return VMEnv.vm;
}

bool isAndroid16OrHigher() {
    return VMEnv.api_level >= 36;
}

void nativeHook(JNIEnv *env) {
    BaseHook::init(env);

    bool unixHookSuccess = false;
    bool vmHookSuccess = false;
    bool binderHookSuccess = false;

    try {
        UnixFileSystemHook::init(env);
        unixHookSuccess = true;
        write_log("UnixFileSystemHook success");
    } catch (...) {
        write_log("UnixFileSystemHook failed");
    }

    try {
        VMClassLoaderHook::init(env);
        vmHookSuccess = true;
        write_log("VMClassLoaderHook success");
    } catch (...) {
        write_log("VMClassLoaderHook failed");
    }

    try {
        BinderHook::init(env);
        binderHookSuccess = true;
        write_log("BinderHook success");
    } catch (...) {
        write_log("BinderHook failed");
    }

    AudioHook_init(env);

    if (isAndroid16OrHigher()) {
        JNIEnv *env2 = getEnv();
        jclass linuxClass = env2->FindClass("libcore/io/Linux");
        if (linuxClass) {
            write_log("Android 16+ Linux class found");
        } else {
            write_log("Android 16+ Linux class NOT found");
        }
    }

    VMEnv.hooks_initialized = unixHookSuccess || vmHookSuccess || binderHookSuccess;
}

void hideXposed(JNIEnv *env, jclass clazz) {
    write_log("hideXposed called");
    VMClassLoaderHook::hideXposed();
}

void init(JNIEnv *env, jobject clazz, jint api_level) {
    VMEnv.api_level = api_level;

    write_log("init called");

    JniHook::InitJniHook(env, api_level);

    jclass nativeCoreClass = env->FindClass(VMCORE_CLASS);
    if (!nativeCoreClass) {
        write_log("NativeCoreClass NOT found");
        return;
    }

    VMEnv.NativeCoreClass = (jclass) env->NewGlobalRef(nativeCoreClass);

    VMEnv.getCallingUidId = env->GetStaticMethodID(VMEnv.NativeCoreClass, "getCallingUid", "(I)I");
    VMEnv.redirectPathString = env->GetStaticMethodID(
        VMEnv.NativeCoreClass,
        "redirectPath",
        "(Ljava/lang/String;)Ljava/lang/String;"
    );
    VMEnv.redirectPathFile = env->GetStaticMethodID(
        VMEnv.NativeCoreClass,
        "redirectPath",
        "(Ljava/io/File;)Ljava/io/File;"
    );
    VMEnv.loadEmptyDex = env->GetStaticMethodID(
        VMEnv.NativeCoreClass,
        "loadEmptyDex",
        "()[J"
    );
}

void addIORule(JNIEnv *env, jclass clazz, jstring target_path, jstring relocate_path) {
    if (!target_path || !relocate_path) {
        write_log("addIORule null params");
        return;
    }

    const char* target = env->GetStringUTFChars(target_path, JNI_FALSE);
    const char* relocate = env->GetStringUTFChars(relocate_path, JNI_FALSE);

    write_log(("addIORule: " + std::string(target) + " -> " + std::string(relocate)).c_str());

    IO::addRule(target, relocate);

    env->ReleaseStringUTFChars(target_path, target);
    env->ReleaseStringUTFChars(relocate_path, relocate);
}

void enableIO(JNIEnv *env, jclass clazz) {
    write_log("enableIO called");
    IO::init(env);
    nativeHook(env);
}

static JNINativeMethod gMethods[] = {
    {"hideXposed", "()V", (void *) hideXposed},
    {"addIORule", "(Ljava/lang/String;Ljava/lang/String;)V", (void *) addIORule},
    {"enableIO", "()V", (void *) enableIO},
    {"init", "(I)V", (void *) init},
};

int registerNativeMethods(JNIEnv *env, const char *className, JNINativeMethod *methods, int numMethods) {
    jclass clazz = env->FindClass(className);
    if (clazz == nullptr) {
        write_log("registerNativeMethods failed");
        return JNI_FALSE;
    }

    if (env->RegisterNatives(clazz, methods, numMethods) < 0) {
        env->ExceptionClear();
        write_log("registerNativeMethods error");
        return JNI_FALSE;
    }

    write_log("registerNativeMethods success");
    return JNI_TRUE;
}

int registerNatives(JNIEnv *env) {
    if (!registerNativeMethods(env, VMCORE_CLASS, gMethods, sizeof(gMethods) / sizeof(gMethods[0]))) {
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

void registerMethod(JNIEnv *jenv) {
    registerNatives(jenv);
}

JNIEXPORT jint JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    VMEnv.vm = vm;

    if (vm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6) != JNI_OK) {
        return JNI_EVERSION;
    }

    write_log("JNI_OnLoad");

    registerMethod(env);

    return JNI_VERSION_1_6;
}