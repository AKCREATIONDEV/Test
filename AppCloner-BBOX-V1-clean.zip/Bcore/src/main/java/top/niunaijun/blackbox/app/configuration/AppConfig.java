package top.niunaijun.blackbox.app.configuration;

public class AppConfig {
    private String packageName;
    private String appName;
    private int userId;
    private boolean isSystemApp;
    private boolean isXposedModule;
    
    public AppConfig() {
        this.packageName = "";
        this.appName = "";
        this.userId = 0;
        this.isSystemApp = false;
        this.isXposedModule = false;
    }
    
    public AppConfig(String packageName, String appName, int userId) {
        this.packageName = packageName;
        this.appName = appName;
        this.userId = userId;
        this.isSystemApp = false;
        this.isXposedModule = false;
    }
    
    public String getPackageName() {
        return packageName;
    }
    
    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }
    
    public String getAppName() {
        return appName;
    }
    
    public void setAppName(String appName) {
        this.appName = appName;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public boolean isSystemApp() {
        return isSystemApp;
    }
    
    public void setSystemApp(boolean systemApp) {
        isSystemApp = systemApp;
    }
    
    public boolean isXposedModule() {
        return isXposedModule;
    }
    
    public void setXposedModule(boolean xposedModule) {
        isXposedModule = xposedModule;
    }
}