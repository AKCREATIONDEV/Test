package top.niunaijun.blackbox.core;

/** JNI bridge used by the BlackBox virtual runtime only. */
public final class NativeCore {
    static {
        System.loadLibrary("livaibbox");
    }

    private NativeCore() { }

    public static native void init(int apiLevel);
    public static native void enableIO();
    public static native void addIORule(String targetPath, String relocatePath);
    public static native void hideXposed();
}
