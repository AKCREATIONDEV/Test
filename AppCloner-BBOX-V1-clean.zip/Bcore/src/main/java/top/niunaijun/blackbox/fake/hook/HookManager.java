package top.niunaijun.blackbox.fake.hook;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.fake.delegate.AppInstrumentation;
import top.niunaijun.blackbox.fake.service.*;
import top.niunaijun.blackbox.fake.service.context.ContentServiceStub;
import top.niunaijun.blackbox.fake.service.context.RestrictionsManagerStub;
import top.niunaijun.blackbox.fake.service.libcore.OsStub;
import top.niunaijun.blackbox.utils.compat.BuildCompat;

/**
 * Universal HookManager — Android 11 to 14
 * Automatically skips missing proxies to avoid build errors.
 */
public class HookManager {
    public static final String TAG = "HookManager";

    private static final HookManager sHookManager = new HookManager();
    private final Map<Class<?>, IInjectHook> mInjectors = new HashMap<>();
    private final Object mLock = new Object();
    private volatile boolean mInited = false;

    private final ExecutorService mExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "HookManager-Init");
        t.setDaemon(true);
        return t;
    });

    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    public static HookManager get() {
        return sHookManager;
    }

    public void init(boolean async) {
        synchronized (mLock) {
            if (mInited) return;
            mInited = true;

            if (BlackBoxCore.get().isBlackProcess() || BlackBoxCore.get().isServerProcess()) {

                // Core hooks (common)
                safeAdd(() -> new OsStub());
                safeAdd(() -> new IActivityManagerProxy());
                safeAdd(() -> new IPackageManagerProxy());
                safeAdd(() -> new ITelephonyManagerProxy());
                safeAdd(() -> new HCallbackProxy());
                safeAdd(() -> new IAppOpsManagerProxy());
                safeAdd(() -> new INotificationManagerProxy());
                safeAdd(() -> new IAlarmManagerProxy());
                safeAdd(() -> new IAppWidgetManagerProxy());
                safeAdd(() -> new ContentServiceStub());
                safeAdd(() -> new IWindowManagerProxy());
                safeAdd(() -> new IUserManagerProxy());
                safeAdd(() -> new RestrictionsManagerStub());
                safeAdd(() -> new IMediaSessionManagerProxy());
                safeAdd(() -> new ILocationManagerProxy());
                safeAdd(() -> new IStorageManagerProxy());
                safeAdd(() -> new IAccessibilityManagerProxy());
                safeAdd(() -> new ITelephonyRegistryProxy());

                safeAdd(() -> new IAccountManagerProxy());
                safeAdd(() -> new IPhoneSubInfoProxy());
                safeAdd(() -> new IMediaRouterServiceProxy());
                safeAdd(() -> new IPowerManagerProxy());
                safeAdd(() -> new IContextHubServiceProxy());
                safeAdd(() -> new IVibratorServiceProxy());
                safeAdd(() -> new IPersistentDataBlockServiceProxy());
                safeAdd(() -> AppInstrumentation.get());
                safeAdd(() -> new IWifiManagerProxy());
                safeAdd(() -> new IWifiScannerProxy());

                // Optional / version-based
                trySafe(() -> new IDisplayManagerProxy());
                trySafe(() -> new ILauncherAppsProxy());
                trySafe(() -> new IJobServiceProxy());
                trySafe(() -> new IDevicePolicyManagerProxy());
                trySafe(() -> new IConnectivityManagerProxy());
                trySafe(() -> new IDeviceIdentifiersPolicyProxy());

                if (BuildCompat.isT()) safeAdd(() -> new ILocaleManagerProxy());
                if (BuildCompat.isS()) {
                    safeAdd(() -> new IActivityClientProxy((Object) null));
                    safeAdd(() -> new IVpnManagerProxy());
                }
                if (BuildCompat.isR()) safeAdd(() -> new IPermissionManagerProxy());
                if (BuildCompat.isQ()) safeAdd(() -> new IActivityTaskManagerProxy());
                if (BuildCompat.isPie()) safeAdd(() -> new ISystemUpdateProxy());
                if (BuildCompat.isOreo()) {
                    safeAdd(() -> new IAutofillManagerProxy());
                    safeAdd(() -> new IStorageStatsManagerProxy());
                }
                if (BuildCompat.isN_MR1()) safeAdd(() -> new IShortcutManagerProxy());
                if (BuildCompat.isN()) safeAdd(() -> new INetworkManagementServiceProxy());
                if (BuildCompat.isM()) {
                    safeAdd(() -> new IFingerprintManagerProxy());
                    safeAdd(() -> new IGraphicsStatsProxy());
                }
            }

            if (async) mExecutor.execute(this::injectAll);
            else injectAll();
        }
    }

    public void init() {
        init(false);
    }

    public void checkEnv(Class<?> clazz) {
        IInjectHook hook;
        synchronized (mLock) {
            hook = mInjectors.get(clazz);
        }
        if (hook != null) {
            try {
                if (hook.isBadEnv()) {
                    Log.d(TAG, clazz.getSimpleName() + " bad env, reinjecting");
                    safeInject(hook);
                }
            } catch (Throwable t) {
                Log.e(TAG, "checkEnv error", t);
            }
        }
    }

    public void checkAll() {
        Map<Class<?>, IInjectHook> snapshot;
        synchronized (mLock) {
            snapshot = new HashMap<>(mInjectors);
        }
        for (IInjectHook hook : snapshot.values()) {
            if (hook == null) continue;
            try {
                if (hook.isBadEnv()) safeInject(hook);
            } catch (Throwable t) {
                Log.e(TAG, "checkAll failed", t);
            }
        }
    }

    private void addInjector(IInjectHook hook) {
        if (hook == null) return;
        synchronized (mLock) {
            mInjectors.put(hook.getClass(), hook);
        }
    }

    private void injectAll() {
        Map<Class<?>, IInjectHook> snapshot;
        synchronized (mLock) {
            snapshot = new HashMap<>(mInjectors);
        }
        for (IInjectHook hook : snapshot.values()) safeInject(hook);
    }

    private void safeInject(IInjectHook hook) {
        try {
            hook.injectHook();
        } catch (Throwable t) {
            Log.e(TAG, "hook error: " + hook.getClass().getSimpleName(), t);
            if (Looper.myLooper() != Looper.getMainLooper()) {
                mMainHandler.post(() -> {
                    try {
                        hook.injectHook();
                    } catch (Throwable tt) {
                        Log.e(TAG, "main retry failed: " + hook.getClass().getSimpleName(), tt);
                    }
                });
            }
        }
    }

    private void safeAdd(Provider<IInjectHook> provider) {
        try {
            IInjectHook hook = provider.provide();
            if (hook != null) addInjector(hook);
        } catch (Throwable t) {
            Log.e(TAG, "safeAdd failed", t);
        }
    }

    /** Optional add: ignores if class missing */
    private void trySafe(Provider<IInjectHook> provider) {
        try {
            IInjectHook hook = provider.provide();
            if (hook != null) addInjector(hook);
        } catch (Throwable ignored) {
            Log.w(TAG, "Optional hook skipped: " + provider);
        }
    }

    private interface Provider<T> {
        T provide();
    }
}
