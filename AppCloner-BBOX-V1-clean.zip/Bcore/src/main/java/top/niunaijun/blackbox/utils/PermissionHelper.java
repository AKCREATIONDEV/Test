package top.niunaijun.blackbox.utils;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.BActivityThread;

public class PermissionHelper {
    private static final String TAG = "PermissionHelper";
    
    public static final int REQUEST_MICROPHONE = 1001;
    
    public interface PermissionCallback {
        void onPermissionGranted(String permission);
        void onPermissionDenied(String permission);
    }
    
    private static PermissionCallback mCurrentCallback;
    
    public static boolean checkMicrophonePermission() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Context context = BActivityThread.getApplication();
                if (context == null) {
                    context = BlackBoxCore.getContext();
                }
                int result = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO);
                return result == PackageManager.PERMISSION_GRANTED;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    public static boolean requestMicrophonePermission(Activity activity, PermissionCallback callback) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            if (callback != null) callback.onPermissionGranted(Manifest.permission.RECORD_AUDIO);
            return true;
        }
        
        if (checkMicrophonePermission()) {
            if (callback != null) callback.onPermissionGranted(Manifest.permission.RECORD_AUDIO);
            return true;
        }
        
        if (activity.shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
            showMicrophoneRationale(activity, callback);
        } else {
            mCurrentCallback = callback;
            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MICROPHONE);
        }
        return false;
    }
    
    private static void showMicrophoneRationale(Activity activity, PermissionCallback callback) {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(activity);
        builder.setTitle("صلاحية المايك مطلوبة")
                .setMessage("التطبيق يحتاج إلى صلاحية المايك لتسجيل الصوت في اللعبة")
                .setPositiveButton("موافق", (dialog, which) -> {
                    mCurrentCallback = callback;
                    ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MICROPHONE);
                })
                .setNegativeButton("رفض", (dialog, which) -> {
                    if (callback != null) callback.onPermissionDenied(Manifest.permission.RECORD_AUDIO);
                })
                .show();
    }
    
    public static void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_MICROPHONE && mCurrentCallback != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mCurrentCallback.onPermissionGranted(Manifest.permission.RECORD_AUDIO);
            } else {
                mCurrentCallback.onPermissionDenied(Manifest.permission.RECORD_AUDIO);
            }
            mCurrentCallback = null;
        }
    }
    
    public static void openAppSettings(Context context) {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", context.getPackageName(), null);
        intent.setData(uri);
        context.startActivity(intent);
    }
}