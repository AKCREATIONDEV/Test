package top.niunaijun.blackbox.fake.hook;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.Log;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;

import top.niunaijun.blackbox.utils.MethodParameterUtils;

/**
 * Created by Milk on 3/30/21.
 * * ∧＿∧
 * (`･ω･∥
 * 丶　つ０
 * しーＪ
 * 此处无Bug
 */
public abstract class ClassInvocationStub implements InvocationHandler, IInjectHook {
    public static final String TAG = ClassInvocationStub.class.getSimpleName();

    private final Map<String, MethodHook> mMethodHookMap = new HashMap<>();
    private Object mBase;
    private Object mProxyInvocation;
    private boolean onlyProxy;

    protected abstract Object getWho();

    protected abstract void inject(Object baseInvocation, Object proxyInvocation);

    protected void onBindMethod() {

    }

    protected Object getProxyInvocation() {
        return mProxyInvocation;
    }

    protected Object getBase() {
        return mBase;
    }

    protected void onlyProxy(boolean o) {
        onlyProxy = o;
    }

    @Override
    public void injectHook() {
        // الحصول على الخدمة الأساسية
        mBase = getWho();
        
        // [الحل] التحقق من أن mBase ليس null قبل المتابعة
        if (mBase == null) {
            Log.e(TAG, "injectHook failed: mBase is null for " + this.getClass().getName());
            
            // محاولة إنشاء Proxy وهمي لتجنب العطل
            try {
                // إنشاء Proxy وهمي باستخدام واجهة افتراضية
                mProxyInvocation = Proxy.newProxyInstance(
                    this.getClass().getClassLoader(), 
                    new Class[]{}, 
                    this
                );
            } catch (Exception e) {
                Log.e(TAG, "Failed to create fallback proxy", e);
            }
            
            // لا نستطيع متابعة التهيئة بشكل طبيعي، ولكن التطبيق لن ينهار
            return;
        }

        // الكود الأصلي - يتم تنفيذه فقط إذا كان mBase ليس null
        try {
            mProxyInvocation = Proxy.newProxyInstance(
                mBase.getClass().getClassLoader(), 
                MethodParameterUtils.getAllInterface(mBase.getClass()), 
                this
            );
        } catch (Exception e) {
            Log.e(TAG, "Failed to create proxy for " + mBase.getClass().getName(), e);
            
            // محاولة بديلة
            try {
                mProxyInvocation = Proxy.newProxyInstance(
                    this.getClass().getClassLoader(), 
                    new Class[]{}, 
                    this
                );
            } catch (Exception e2) {
                Log.e(TAG, "Failed to create fallback proxy", e2);
                return;
            }
        }
        
        if (!onlyProxy && mBase != null && mProxyInvocation != null) {
            try {
                inject(mBase, mProxyInvocation);
            } catch (Exception e) {
                Log.e(TAG, "Failed to inject", e);
            }
        }
        
        onBindMethod();
        
        // باقي الكود كما هو
        Class<?>[] declaredClasses = this.getClass().getDeclaredClasses();
        for (Class<?> declaredClass : declaredClasses) {
            initAnnotation(declaredClass);
        }
        ScanClass scanClass = this.getClass().getAnnotation(ScanClass.class);
        if (scanClass != null) {
            for (Class<?> aClass : scanClass.value()) {
                for (Class<?> declaredClass : aClass.getDeclaredClasses()) {
                    initAnnotation(declaredClass);
                }
            }
        }
    }

    protected void initAnnotation(Class<?> clazz) {
        ProxyMethod proxyMethod = clazz.getAnnotation(ProxyMethod.class);
        if (proxyMethod != null) {
            final String name = proxyMethod.value();
            if (!TextUtils.isEmpty(name)) {
                try {
                    addMethodHook(name, (MethodHook) clazz.newInstance());
                } catch (Throwable t) {
                    t.printStackTrace();
                }
            }
        }
        ProxyMethods proxyMethods = clazz.getAnnotation(ProxyMethods.class);
        if (proxyMethods != null) {
            String[] value = proxyMethods.value();
            for (String name : value) {
                try {
                    addMethodHook(name, (MethodHook) clazz.newInstance());
                } catch (Throwable t) {
                    t.printStackTrace();
                }
            }
        }
    }

    protected void addMethodHook(MethodHook methodHook) {
        mMethodHookMap.put(methodHook.getMethodName(), methodHook);
    }

    protected void addMethodHook(String name, MethodHook methodHook) {
        mMethodHookMap.put(name, methodHook);
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        // التحقق من أن mBase ليس null
        if (mBase == null) {
            Log.w(TAG, "Invoke called but mBase is null for method: " + (method != null ? method.getName() : "unknown"));
            
            // إذا كانت الدالة ترجع قيمة افتراضية معقولة
            if (method != null && method.getReturnType() != null) {
                if (method.getReturnType() == boolean.class) {
                    return false;
                } else if (method.getReturnType() == int.class) {
                    return 0;
                } else if (method.getReturnType() == long.class) {
                    return 0L;
                } else if (method.getReturnType() == float.class) {
                    return 0f;
                } else if (method.getReturnType() == double.class) {
                    return 0.0;
                }
            }
            
            return null;
        }
        
        MethodHook methodHook = mMethodHookMap.get(method.getName());
        if (methodHook == null || !methodHook.isEnable()) {
            try {
                return method.invoke(mBase, args);
            } catch (Throwable e) {
                throw e.getCause();
            }
        }

        Object result = methodHook.beforeHook(mBase, method, args);
        if (result != null) {
            return result;
        }
        result = methodHook.hook(mBase, method, args);
        result = methodHook.afterHook(result);
        return result;
    }
}