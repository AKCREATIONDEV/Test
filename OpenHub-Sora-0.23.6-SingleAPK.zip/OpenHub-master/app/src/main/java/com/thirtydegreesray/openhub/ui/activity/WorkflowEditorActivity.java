package com.thirtydegreesray.openhub.ui.activity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Base64;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.TextView;

import com.thirtydegreesray.openhub.AppConfig;
import com.thirtydegreesray.openhub.AppData;
import com.thirtydegreesray.openhub.http.RepoService;
import com.thirtydegreesray.openhub.http.core.AppRetrofit;
import com.thirtydegreesray.openhub.mvp.model.FileModel;
import com.thirtydegreesray.openhub.mvp.model.WorkflowFileContent;
import com.thirtydegreesray.openhub.mvp.model.WorkflowFileUpdate;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Response;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/** Simple in-app editor for .github/workflows/*.yml and *.yaml files. */
public class WorkflowEditorActivity extends Activity {
    private String owner, repo, branch;
    private RepoService service;
    private ListView list;
    private TextView status;
    private final ArrayList<FileModel> files = new ArrayList<>();

    public static void show(Activity activity, String owner, String repo, String branch) {
        activity.startActivity(new android.content.Intent(activity, WorkflowEditorActivity.class)
                .putExtra("owner", owner).putExtra("repo", repo).putExtra("branch", branch));
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        owner=getIntent().getStringExtra("owner"); repo=getIntent().getStringExtra("repo");
        branch=getIntent().getStringExtra("branch");
        if (branch == null || branch.trim().length()==0) branch="main";
        service= AppRetrofit.INSTANCE.getRetrofit(AppConfig.GITHUB_API_BASE_URL,
                AppData.INSTANCE.getAccessToken()).create(RepoService.class);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16,16,16,16);
        TextView title=new TextView(this); title.setText("Workflow YAML Editor\n"+owner+"/"+repo+" · "+branch);
        title.setTextSize(18); root.addView(title);
        status=new TextView(this); status.setText("Loading workflow files…"); root.addView(status);
        Button refresh=new Button(this); refresh.setText("Refresh workflows");
        refresh.setOnClickListener(v -> loadFiles()); root.addView(refresh);
        list=new ListView(this); root.addView(list,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root); loadFiles();
    }

    private void loadFiles() {
        status.setText("Loading .github/workflows…");
        service.getRepoFiles(owner,repo,".github/workflows",branch)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe(response -> {
                    files.clear();
                    if (response.isSuccessful() && response.body()!=null) {
                        for (FileModel f: response.body()) {
                            String n=f.getName()==null?"":f.getName().toLowerCase();
                            if ("file".equals(f.getType()) && (n.endsWith(".yml")||n.endsWith(".yaml"))) files.add(f);
                        }
                    }
                    ArrayList<String> names=new ArrayList<>();
                    for(FileModel f:files) names.add(f.getPath());
                    list.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,names));
                    status.setText(files.isEmpty()?"No .yml/.yaml workflow files found (or access denied).":"Tap a workflow to edit and commit it.");
                    list.setOnItemClickListener((parent,view,position,id)->openFile(files.get(position)));
                }, error -> status.setText("Could not load workflows: "+error.getLocalizedMessage()));
    }

    private void openFile(FileModel file) {
        status.setText("Loading "+file.getName()+"…");
        service.getWorkflowFile(owner,repo,file.getPath(),branch)
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe(response -> {
                    WorkflowFileContent body=response.body();
                    if (!response.isSuccessful() || body==null || body.getContent()==null) {
                        toast("Cannot read file. Check repository permissions."); return;
                    }
                    try {
                        String raw=new String(Base64.decode(body.getContent().replaceAll("\\s", ""),Base64.DEFAULT), Charset.forName("UTF-8"));
                        showEditor(file,body,raw);
                    } catch(Exception e) { toast("Could not decode YAML: "+e.getMessage()); }
                }, error -> toast("Load failed: "+error.getLocalizedMessage()));
    }

    private void showEditor(FileModel file, WorkflowFileContent body, String content) {
        CodeEditorActivity.openWorkflow(this, owner, repo, branch, file.getPath(),
                body.getSha(), content);
    }

    private void toast(String message){ Toast.makeText(this,message,Toast.LENGTH_LONG).show(); }
}
