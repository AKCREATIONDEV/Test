package com.thirtydegreesray.openhub.mvp.model;

import java.util.HashMap;
import java.util.Map;

public class WorkflowFileUpdate {
    public String message;
    public String content;
    public String sha;
    public String branch;
    public WorkflowFileUpdate(String message, String content, String sha, String branch) {
        this.message=message; this.content=content; this.sha=sha; this.branch=branch;
    }
}
