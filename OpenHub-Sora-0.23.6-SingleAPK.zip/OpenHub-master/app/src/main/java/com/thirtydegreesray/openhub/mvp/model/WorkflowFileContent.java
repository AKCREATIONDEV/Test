package com.thirtydegreesray.openhub.mvp.model;

import com.google.gson.annotations.SerializedName;

public class WorkflowFileContent {
    private String name;
    private String path;
    private String sha;
    private String content;
    @SerializedName("encoding") private String encoding;
    public String getName(){ return name; }
    public String getPath(){ return path; }
    public String getSha(){ return sha; }
    public String getContent(){ return content; }
    public String getEncoding(){ return encoding; }
}
