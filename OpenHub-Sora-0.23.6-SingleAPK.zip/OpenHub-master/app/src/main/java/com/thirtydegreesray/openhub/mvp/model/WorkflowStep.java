package com.thirtydegreesray.openhub.mvp.model;

import com.google.gson.annotations.SerializedName;
import java.util.Date;

/**
 * A step of a workflow job.
 */
public class WorkflowStep {

    private String name;
    private String status;
    private String conclusion;
    private int number;
    @SerializedName("started_at") private Date startedAt;
    @SerializedName("completed_at") private Date completedAt;

    public String getName() {
        return name;
    }

    public String getStatus() {
        return status;
    }

    public String getConclusion() {
        return conclusion;
    }

    public int getNumber() {
        return number;
    }

    public Date getStartedAt() { return startedAt; }

    public Date getCompletedAt() { return completedAt; }

    /** @return step duration in milliseconds, or -1 when unavailable. */
    public long getDurationMillis() {
        if (startedAt == null || completedAt == null) return -1;
        long duration = completedAt.getTime() - startedAt.getTime();
        return duration < 0 ? 0 : duration;
    }
}
