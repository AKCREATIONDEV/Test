package com.thirtydegreesray.openhub.mvp.model;

import com.google.gson.annotations.SerializedName;

import java.util.Date;

/**
 * A GitHub Actions workflow run.
 */
public class WorkflowRun {

    private long id;
    private String name;
    @SerializedName("display_title") private String displayTitle;
    @SerializedName("head_branch") private String headBranch;
    @SerializedName("head_sha") private String headSha;
    @SerializedName("run_number") private int runNumber;
    @SerializedName("run_attempt") private int runAttempt;
    private String event;
    private String status;
    private String conclusion;
    @SerializedName("workflow_id") private long workflowId;
    @SerializedName("html_url") private String htmlUrl;
    @SerializedName("created_at") private Date createdAt;
    @SerializedName("updated_at") private Date updatedAt;
    @SerializedName("run_started_at") private Date runStartedAt;
    private User actor;

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDisplayTitle() {
        return displayTitle;
    }

    public String getHeadBranch() {
        return headBranch;
    }

    public String getHeadSha() {
        return headSha;
    }

    public int getRunNumber() {
        return runNumber;
    }

    public int getRunAttempt() {
        return runAttempt;
    }

    public String getEvent() {
        return event;
    }

    public String getStatus() {
        return status;
    }

    public String getConclusion() {
        return conclusion;
    }

    public long getWorkflowId() {
        return workflowId;
    }

    public String getHtmlUrl() {
        return htmlUrl;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public Date getRunStartedAt() {
        return runStartedAt;
    }

    public User getActor() {
        return actor;
    }

    /**
     * Title shown in the list: commit message / PR title when available, else workflow name.
     */
    public String getTitle() {
        if (displayTitle != null && displayTitle.trim().length() > 0) {
            return displayTitle;
        }
        return name == null ? "" : name;
    }

    public boolean isCompleted() {
        return "completed".equals(status);
    }

    /**
     * queued / in_progress / waiting / requested / pending runs can be cancelled.
     */
    public boolean isCancellable() {
        return status != null && !isCompleted();
    }

    public boolean isFailed() {
        return isCompleted() && ("failure".equals(conclusion)
                || "timed_out".equals(conclusion)
                || "startup_failure".equals(conclusion));
    }

    /**
     * @return run duration in millis, or -1 if unknown.
     */
    public long getDurationMillis() {
        if (runStartedAt == null) return -1;
        long endTime = isCompleted() ? (updatedAt == null ? -1 : updatedAt.getTime()) : System.currentTimeMillis();
        if (endTime < 0) return -1;
        long duration = endTime - runStartedAt.getTime();
        return duration < 0 ? 0 : duration;
    }

    /**
     * The date used for the relative time label.
     */
    public Date getDisplayDate() {
        if (updatedAt != null) return updatedAt;
        return createdAt;
    }

}
