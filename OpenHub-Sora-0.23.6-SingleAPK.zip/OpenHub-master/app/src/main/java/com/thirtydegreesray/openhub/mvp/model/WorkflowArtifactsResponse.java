package com.thirtydegreesray.openhub.mvp.model;
import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
public class WorkflowArtifactsResponse {
 @SerializedName("total_count") private int totalCount;
 private ArrayList<WorkflowArtifact> artifacts;
 public int getTotalCount(){return totalCount;}
 public ArrayList<WorkflowArtifact> getArtifacts(){return artifacts;}
}
