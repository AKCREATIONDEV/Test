package com.thirtydegreesray.openhub.ui.fragment;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.os.Environment;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.Toast;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.graphics.Typeface;
import androidx.core.content.FileProvider;
import android.content.Intent;
import android.net.Uri;

import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.inject.component.AppComponent;
import com.thirtydegreesray.openhub.inject.component.DaggerFragmentComponent;
import com.thirtydegreesray.openhub.inject.module.FragmentModule;
import com.thirtydegreesray.openhub.mvp.contract.IActionsContract;
import com.thirtydegreesray.openhub.mvp.model.Branch;
import com.thirtydegreesray.openhub.mvp.model.Workflow;
import com.thirtydegreesray.openhub.mvp.model.WorkflowArtifact;
import com.thirtydegreesray.openhub.mvp.model.WorkflowJob;
import com.thirtydegreesray.openhub.mvp.model.WorkflowRun;
import com.thirtydegreesray.openhub.mvp.model.WorkflowStep;
import com.thirtydegreesray.openhub.mvp.presenter.ActionsPresenter;
import com.thirtydegreesray.openhub.ui.activity.ActionsActivity;
import com.thirtydegreesray.openhub.ui.activity.CodeEditorActivity;
import com.thirtydegreesray.openhub.ui.adapter.ActionsAdapter;
import com.thirtydegreesray.openhub.ui.fragment.base.ListFragment;
import com.thirtydegreesray.openhub.util.ActionsHelper;
import com.thirtydegreesray.openhub.util.AppOpener;
import com.thirtydegreesray.openhub.util.BundleHelper;
import com.thirtydegreesray.openhub.util.StringUtils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import okhttp3.ResponseBody;

/**
 * Workflow run list of a repository with all GitHub Actions management features.
 */
public class ActionsFragment extends ListFragment<ActionsPresenter, ActionsAdapter>
        implements IActionsContract.View {

    private static final int ACTION_JOBS = 1;
    private static final int ACTION_CANCEL = 2;
    private static final int ACTION_RERUN = 3;
    private static final int ACTION_RERUN_FAILED = 4;
    private static final int ACTION_DELETE = 5;
    private static final int ACTION_BROWSER = 6;
    private static final int ACTION_ARTIFACTS = 7;

    /** GitHub needs a moment before a new run / a state change shows up in the list. */
    private static final long RELOAD_DELAY_MILLIS = 2000;

    /** values of the "status" query parameter, "" means all */
    private static final String[] STATUS_VALUES =
            {"", "success", "failure", "cancelled", "in_progress", "queued"};

    /** branch / tag field of the currently open "run workflow" dialog */
    private EditText pendingRefEdit;
    private final Handler actionsRefreshHandler = new Handler(Looper.getMainLooper());
    private final Runnable actionsRefreshRunnable = new Runnable() {
        @Override public void run() {
            if (!isAdded() || adapter == null) return;
            boolean hasActiveRun = false;
            for (WorkflowRun run : adapter.getData()) {
                if (run != null && !run.isCompleted()) { hasActiveRun = true; break; }
            }
            if (hasActiveRun) {
                mPresenter.loadRuns(1, true);
                actionsRefreshHandler.postDelayed(this, 15000);
            }
        }
    };

    public static ActionsFragment create(String owner, String repo, String branch) {
        ActionsFragment fragment = new ActionsFragment();
        fragment.setArguments(BundleHelper.builder()
                .put("owner", owner)
                .put("repo", repo)
                .put("branch", branch).build());
        return fragment;
    }

    @Override
    public void onResume() {
        super.onResume();
        actionsRefreshHandler.removeCallbacks(actionsRefreshRunnable);
        actionsRefreshHandler.postDelayed(actionsRefreshRunnable, 15000);
    }

    @Override
    public void onPause() {
        actionsRefreshHandler.removeCallbacks(actionsRefreshRunnable);
        super.onPause();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_list;
    }

    @Override
    protected void setupFragmentComponent(AppComponent appComponent) {
        DaggerFragmentComponent.builder()
                .appComponent(appComponent)
                .fragmentModule(new FragmentModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initFragment(Bundle savedInstanceState) {
        super.initFragment(savedInstanceState);
        setLoadMoreEnable(true);
    }

    @Override
    protected void onReLoadData() {
        mPresenter.loadRuns(1, true);
    }

    @Override
    protected String getEmptyTip() {
        return getString(R.string.no_workflow_runs);
    }

    @Override
    protected void onLoadMore(int page) {
        super.onLoadMore(page);
        mPresenter.loadRuns(page, false);
    }

    @Override
    public void showRuns(ArrayList<WorkflowRun> runs) {
        adapter.setData(runs);
        postNotifyDataSetChanged();
        updateFilterInfo();
    }

    @Override
    public void onItemClick(int position, @NonNull View view) {
        super.onItemClick(position, view);
        showRunActionsDialog(adapter.getData().get(position));
    }

    // ------------------------------------------------------------------
    // toolbar actions (called by ActionsActivity)
    // ------------------------------------------------------------------

    public void onRunWorkflowClick() {
        mPresenter.loadWorkflows(IActionsContract.PURPOSE_RUN);
    }

    public void onFilterWorkflowClick() {
        mPresenter.loadWorkflows(IActionsContract.PURPOSE_FILTER);
    }

    public void onManageWorkflowsClick() {
        mPresenter.loadWorkflows(IActionsContract.PURPOSE_MANAGE);
    }

    public void onFilterStatusClick() {
        String[] labels = new String[STATUS_VALUES.length];
        int checked = 0;
        String current = mPresenter.getStatusFilter();
        for (int i = 0; i < STATUS_VALUES.length; i++) {
            labels[i] = getStatusLabel(STATUS_VALUES[i]);
            if (STATUS_VALUES[i].equals(current)) checked = i;
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.actions_filter_status)
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        mPresenter.setStatusFilter(STATUS_VALUES[which]);
                        onRefresh();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    // ------------------------------------------------------------------
    // workflow list dialogs
    // ------------------------------------------------------------------

    @Override
    public void showWorkflows(ArrayList<Workflow> workflows, int purpose) {
        if (workflows.isEmpty()) {
            showInfoToast(getString(R.string.actions_no_workflows));
            return;
        }
        switch (purpose) {
            case IActionsContract.PURPOSE_RUN:
                showRunChooser(workflows);
                break;
            case IActionsContract.PURPOSE_FILTER:
                showFilterChooser(workflows);
                break;
            case IActionsContract.PURPOSE_MANAGE:
                showManageChooser(workflows);
                break;
            default:
                break;
        }
    }

    /** Only active workflows can be triggered. */
    private void showRunChooser(ArrayList<Workflow> workflows) {
        final ArrayList<Workflow> active = new ArrayList<>();
        for (Workflow workflow : workflows) {
            if (workflow.isActive()) active.add(workflow);
        }
        if (active.isEmpty()) {
            showInfoToast(getString(R.string.actions_no_active_workflows));
            return;
        }
        String[] names = new String[active.size()];
        for (int i = 0; i < active.size(); i++) {
            names[i] = active.get(i).getDisplayName();
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.actions_select_workflow)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showRunWorkflowDialog(active.get(which));
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showFilterChooser(final ArrayList<Workflow> workflows) {
        String[] names = new String[workflows.size() + 1];
        names[0] = getString(R.string.actions_all_workflows);
        for (int i = 0; i < workflows.size(); i++) {
            names[i + 1] = workflows.get(i).getDisplayName();
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.actions_filter_workflow)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            mPresenter.setWorkflowFilter(null, null);
                        } else {
                            Workflow workflow = workflows.get(which - 1);
                            mPresenter.setWorkflowFilter(String.valueOf(workflow.getId()),
                                    workflow.getDisplayName());
                        }
                        onRefresh();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showManageChooser(final ArrayList<Workflow> workflows) {
        String[] names = new String[workflows.size()];
        for (int i = 0; i < workflows.size(); i++) {
            Workflow workflow = workflows.get(i);
            names[i] = workflow.getDisplayName() + " (" + getString(workflow.isActive()
                    ? R.string.actions_state_enabled : R.string.actions_state_disabled) + ")";
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.actions_manage_workflows)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        confirmToggleWorkflow(workflows.get(which));
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void confirmToggleWorkflow(final Workflow workflow) {
        final boolean enable = !workflow.isActive();
        showActionConfirm(
                getString(enable ? R.string.actions_enable_confirm : R.string.actions_disable_confirm,
                        workflow.getDisplayName()),
                getString(R.string.actions_manage_workflows),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mPresenter.setWorkflowEnabled(workflow, enable);
                    }
                });
    }

    // ------------------------------------------------------------------
    // run workflow dialog
    // ------------------------------------------------------------------

    private void showRunWorkflowDialog(final Workflow workflow) {
        View content = View.inflate(getActivity(), R.layout.dialog_run_workflow, null);
        TextView nameView = (TextView) content.findViewById(R.id.workflow_name);
        final EditText refEdit = (EditText) content.findViewById(R.id.ref_edit);
        final EditText inputsEdit = (EditText) content.findViewById(R.id.inputs_edit);
        Button chooseBn = (Button) content.findViewById(R.id.choose_ref_bn);

        nameView.setText(workflow.getDisplayName());
        String defaultBranch = mPresenter.getDefaultBranch();
        if (!StringUtils.isBlank(defaultBranch)) {
            refEdit.setText(defaultBranch);
            refEdit.setSelection(refEdit.getText().length());
        }
        chooseBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pendingRefEdit = refEdit;
                mPresenter.loadBranches();
            }
        });

        // positive button is wired after show(), so invalid input keeps the dialog open
        final AlertDialog dialog = new AlertDialog.Builder(getActivity())
                .setTitle(R.string.actions_run_workflow)
                .setView(content)
                .setPositiveButton(R.string.actions_run, null)
                .setNegativeButton(R.string.cancel, null)
                .show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ref = refEdit.getText().toString().trim();
                if (ref.length() == 0) {
                    refEdit.setError(getString(R.string.actions_ref_required));
                    return;
                }
                LinkedHashMap<String, String> inputs = new LinkedHashMap<>();
                String invalidLine = parseInputs(inputsEdit.getText().toString(), inputs);
                if (invalidLine != null) {
                    inputsEdit.setError(getString(R.string.actions_inputs_invalid, invalidLine));
                    return;
                }
                dialog.dismiss();
                mPresenter.dispatchWorkflow(workflow, ref, inputs);
            }
        });
    }

    /**
     * Parses "key=value" lines.
     *
     * @return the first invalid line, or null when all lines are valid
     */
    private String parseInputs(String text, Map<String, String> out) {
        String[] lines = text.split("\\r?\\n");
        for (String rawLine : lines) {
            String line = rawLine.trim();
            if (line.length() == 0) continue;
            int index = line.indexOf('=');
            if (index <= 0) return line;
            String key = line.substring(0, index).trim();
            if (key.length() == 0) return line;
            out.put(key, line.substring(index + 1).trim());
        }
        return null;
    }

    @Override
    public void showBranches(ArrayList<Branch> branches) {
        if (pendingRefEdit == null) return;
        if (branches.isEmpty()) {
            showInfoToast(getString(R.string.actions_no_branches));
            return;
        }
        final String[] names = new String[branches.size()];
        for (int i = 0; i < branches.size(); i++) {
            names[i] = branches.get(i).getName();
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.select_branch)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (pendingRefEdit != null) {
                            pendingRefEdit.setText(names[which]);
                            pendingRefEdit.setSelection(pendingRefEdit.getText().length());
                        }
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    // ------------------------------------------------------------------
    // run actions: jobs, cancel, re-run, delete
    // ------------------------------------------------------------------

    private void showRunActionsDialog(final WorkflowRun run) {
        final ArrayList<Integer> actions = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        actions.add(ACTION_JOBS);
        labels.add(getString(R.string.actions_view_jobs));
        actions.add(ACTION_ARTIFACTS);
        labels.add("Download artifacts / APK");
        if (run.isCancellable()) {
            actions.add(ACTION_CANCEL);
            labels.add(getString(R.string.actions_cancel_run));
        }
        if (run.isCompleted()) {
            actions.add(ACTION_RERUN);
            labels.add(getString(R.string.actions_rerun));
            if (run.isFailed()) {
                actions.add(ACTION_RERUN_FAILED);
                labels.add(getString(R.string.actions_rerun_failed));
            }
            actions.add(ACTION_DELETE);
            labels.add(getString(R.string.actions_delete_run));
        }
        if (!StringUtils.isBlank(run.getHtmlUrl())) {
            actions.add(ACTION_BROWSER);
            labels.add(getString(R.string.open_in_browser));
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(run.getTitle())
                .setItems(labels.toArray(new String[labels.size()]),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                onRunActionSelected(run, actions.get(which));
                            }
                        })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void onRunActionSelected(final WorkflowRun run, int action) {
        switch (action) {
            case ACTION_JOBS:
                mPresenter.loadJobs(run);
                break;
            case ACTION_ARTIFACTS:
                mPresenter.loadArtifacts(run);
                break;
            case ACTION_CANCEL:
                showActionConfirm(getString(R.string.actions_cancel_confirm),
                        getString(R.string.actions_cancel_run), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                mPresenter.cancelRun(run);
                            }
                        });
                break;
            case ACTION_RERUN:
                mPresenter.rerunRun(run);
                break;
            case ACTION_RERUN_FAILED:
                mPresenter.rerunFailedJobs(run);
                break;
            case ACTION_DELETE:
                showActionConfirm(getString(R.string.actions_delete_confirm),
                        getString(R.string.actions_delete_run), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                mPresenter.deleteRun(run);
                            }
                        });
                break;
            case ACTION_BROWSER:
                AppOpener.openInCustomTabsOrBrowser(getActivity(), run.getHtmlUrl());
                break;
            default:
                break;
        }
    }

    @Override
    public void showJobs(WorkflowRun run, final ArrayList<WorkflowJob> jobs) {
        if (jobs.isEmpty()) {
            showInfoToast(getString(R.string.actions_no_jobs));
            return;
        }
        String[] items = new String[jobs.size()];
        for (int i = 0; i < jobs.size(); i++) {
            WorkflowJob job = jobs.get(i);
            StringBuilder item = new StringBuilder(job.getName() == null ? "" : job.getName());
            item.append(" · ").append(getStateText(job.getStatus(), job.getConclusion()));
            String duration = ActionsHelper.formatDuration(job.getDurationMillis());
            if (!StringUtils.isBlank(duration)) item.append(" · ").append(duration);
            items[i] = item.toString();
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(getString(R.string.actions_jobs_title) + " · " + run.getTitle())
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showSteps(jobs.get(which));
                    }
                })
                .setPositiveButton(R.string.ok, null)
                .show();
    }

    private void showSteps(final WorkflowJob job) {
        ArrayList<WorkflowStep> steps = job.getSteps();
        if (steps == null || steps.isEmpty()) {
            new AlertDialog.Builder(getActivity()).setTitle(job.getName())
                    .setMessage("No step details are available for this job.")
                    .setPositiveButton("View full job logs", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface dialog, int which) {
                            mPresenter.loadJobLogs(job);
                        }
                    })
                    .setNegativeButton(R.string.cancel, null).show();
            return;
        }
        String[] items = new String[steps.size()];
        for (int i = 0; i < steps.size(); i++) {
            WorkflowStep step = steps.get(i);
            String status = getStateText(step.getStatus(), step.getConclusion());
            String duration = ActionsHelper.formatDuration(step.getDurationMillis());
            String marker = "queued".equalsIgnoreCase(step.getStatus()) || "in_progress".equalsIgnoreCase(step.getStatus())
                    ? "◷ " : ("success".equalsIgnoreCase(step.getConclusion()) ? "✓ " :
                    ("failure".equalsIgnoreCase(step.getConclusion()) ? "✕ " : "• "));
            items[i] = marker + step.getNumber() + ". "
                    + (step.getName() == null ? "" : step.getName())
                    + " · " + status + (StringUtils.isBlank(duration) ? "" : " · " + duration);
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity())
                .setTitle("Steps · " + job.getName())
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        mPresenter.loadJobLogs(job, steps.get(which));
                    }
                })
                .setPositiveButton(R.string.ok, null)
                .setNeutralButton("View full job logs", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        mPresenter.loadJobLogs(job);
                    }
                });
        builder.show();
    }

    @Override
    public void showJobLogs(WorkflowJob job, WorkflowStep step, String logs) {
        String output = logs == null || logs.trim().length() == 0 ? "No log output returned by GitHub." : logs;
        if (step != null) {
            output = "Selected step: " + step.getName()
                    + "\nGitHub provides logs at job level; the complete job log is shown below.\n\n" + output;
        }
        String title = step == null ? "Job logs · " + job.getName() : "Step logs · " + step.getName();
        CodeEditorActivity.openLogs(getActivity(), title, output);
    }

    @Override
    public void showArtifacts(WorkflowRun run, final ArrayList<WorkflowArtifact> artifacts) {
        if (artifacts == null || artifacts.isEmpty()) {
            showInfoToast("No artifacts were uploaded for this build.");
            return;
        }
        final ArrayList<WorkflowArtifact> available = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        for (WorkflowArtifact artifact : artifacts) {
            if (!artifact.isExpired()) {
                available.add(artifact);
                labels.add(artifact.getName() + " · " + formatBytes(artifact.getSizeInBytes()));
            }
        }
        if (available.isEmpty()) { showInfoToast("All artifacts have expired."); return; }
        new AlertDialog.Builder(getActivity()).setTitle("Build artifacts · " + run.getTitle())
                .setItems(labels.toArray(new String[labels.size()]), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        mPresenter.downloadArtifact(available.get(which));
                    }
                }).setNegativeButton(R.string.cancel, null).show();
    }

    @Override
    public void onArtifactDownloaded(final WorkflowArtifact artifact, final byte[] archiveBytes) {
        File downloads = getActivity().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        final File rootDir = downloads == null ? getActivity().getFilesDir() : downloads;
        new AsyncTask<Void, Void, File>() {
            private String error;
            @Override protected File doInBackground(Void... params) {
                File root = rootDir;
                if (!root.exists()) root.mkdirs();
                File zip = new File(root, "artifact-" + artifact.getId() + ".zip");
                try {
                    FileOutputStream out = new FileOutputStream(zip);
                    out.write(archiveBytes);
                    out.flush();
                    out.close();
                    byte[] buffer = new byte[8192]; int count;
                    File apk = null;
                    ZipInputStream zis = new ZipInputStream(new java.io.FileInputStream(zip));
                    ZipEntry entry;
                    while ((entry = zis.getNextEntry()) != null) {
                        if (!entry.isDirectory() && entry.getName().toLowerCase(java.util.Locale.US).endsWith(".apk")) {
                            String name = new File(entry.getName()).getName();
                            apk = new File(root, name);
                            FileOutputStream apkOut = new FileOutputStream(apk);
                            while ((count = zis.read(buffer)) != -1) apkOut.write(buffer, 0, count);
                            apkOut.close(); break;
                        }
                    }
                    zis.close(); zip.delete();
                    if (apk == null) { error = "The artifact archive does not contain an APK file."; return null; }
                    return apk;
                } catch (Exception e) { error = e.getMessage(); zip.delete(); return null; }
            }
            @Override protected void onPostExecute(File apk) {
                if (!isAdded()) return;
                if (apk == null) { showErrorToast("Download failed: " + error); return; }
                Toast.makeText(getActivity(), "APK saved: " + apk.getAbsolutePath(), Toast.LENGTH_LONG).show();
                try {
                    Uri uri = FileProvider.getUriForFile(getActivity(), getActivity().getPackageName() + ".fileProvider", apk);
                    Intent intent = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(intent);
                } catch (Exception ignored) { }
            }
        }.execute();
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(java.util.Locale.US, "%.1f KB", bytes / 1024.0);
        return String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
    }

    @Override
    public void onActionFinished() {
        if (recyclerView == null) return;
        recyclerView.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isAdded()) onRefresh();
            }
        }, RELOAD_DELAY_MILLIS);
    }

    /**
     * Confirm dialog with localized buttons (BaseFragment.showConfirmDialog has a hard coded
     * Chinese cancel button).
     */
    private void showActionConfirm(String message, String title,
                                   DialogInterface.OnClickListener confirmListener) {
        new AlertDialog.Builder(getActivity())
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(R.string.confirm, confirmListener)
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    private String getStateText(String status, String conclusion) {
        return getString(ActionsHelper.getTextRes(ActionsHelper.getKind(status, conclusion)));
    }

    private String getStatusLabel(String statusValue) {
        if ("success".equals(statusValue)) return getString(R.string.actions_state_success);
        if ("failure".equals(statusValue)) return getString(R.string.actions_state_failure);
        if ("cancelled".equals(statusValue)) return getString(R.string.actions_state_cancelled);
        if ("in_progress".equals(statusValue)) return getString(R.string.actions_state_running);
        if ("queued".equals(statusValue)) return getString(R.string.actions_state_queued);
        return getString(R.string.actions_all_statuses);
    }

    /** Shows the active filters in the toolbar subtitle. */
    private void updateFilterInfo() {
        if (!(getActivity() instanceof ActionsActivity)) return;
        StringBuilder info = new StringBuilder();
        if (!StringUtils.isBlank(mPresenter.getWorkflowName())) {
            info.append(mPresenter.getWorkflowName());
        }
        String status = mPresenter.getStatusFilter();
        if (!StringUtils.isBlank(status)) {
            if (info.length() > 0) info.append(" · ");
            info.append(getStatusLabel(status));
        }
        ((ActionsActivity) getActivity()).updateSubtitle(info.toString());
    }

}
