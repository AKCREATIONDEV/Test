package com.thirtydegreesray.openhub.mvp.model;
import com.google.gson.annotations.SerializedName;
import java.util.Date;
public class WorkflowArtifact {
 private long id; private String name; private boolean expired;
 @SerializedName("size_in_bytes") private long sizeInBytes;
 @SerializedName("archive_download_url") private String archiveDownloadUrl;
 @SerializedName("created_at") private Date createdAt;
 public long getId(){return id;} public String getName(){return name;} public boolean isExpired(){return expired;}
 public long getSizeInBytes(){return sizeInBytes;} public String getArchiveDownloadUrl(){return archiveDownloadUrl;} public Date getCreatedAt(){return createdAt;}
}
