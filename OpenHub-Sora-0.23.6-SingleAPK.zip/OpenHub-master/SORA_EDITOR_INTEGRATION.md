# Sora Editor integration

OpenHub uses Sora Editor **0.23.6** as its code editing/viewing widget.

- Sora core and TextMate grammar support are included; the standalone demo app, file picker and standalone save workflow are not included.
- Workflow YAML opens in the dedicated Sora editor page and remains editable/committable through the existing GitHub Contents API.
- Repository source and Actions logs open in the same editor page in read-only mode; read-only mode still allows touch scrolling and text selection.
- TextMate assets include Java, Python, JavaScript, XML, JSON, Kotlin, Gradle/Groovy and YAML scopes.
- Sora 0.23.6 uses Joni, a pure-Java regular-expression engine, by default. The native Oniguruma module is not included.
- Java 17 source/target and core-library desugaring are enabled. Android minSdk remains 21.
- The project uses AndroidX. The Gradle build uses the plugins DSL and centralized repositories.
- GitHub Actions builds and uploads exactly one debug APK named `OpenHub.apk`.

Sora Editor is licensed under LGPL-2.1. See `SORA-EDITOR-LICENSE-LGPL-2.1.txt`.
