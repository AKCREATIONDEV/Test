package com.thirtydegreesray.openhub.ui.widget;

import tiiehenry.code.language.Language;

/** JSON syntax profile with string, number, boolean and null highlighting. */
public final class JsonLanguage extends Language {
    private static JsonLanguage instance;
    private JsonLanguage() {
        setKeywords(new String[] { "true", "false", "null" });
        setOperators(new char[] { '{', '}', '[', ']', ':', ',' });
    }
    @Override public boolean isLineAStart(char c) { return false; }
    public static synchronized JsonLanguage getInstance() {
        if (instance == null) instance = new JsonLanguage();
        return instance;
    }
}
