package com.thirtydegreesray.openhub.ui.widget;

import tiiehenry.code.language.Language;

/** Groovy profile for build.gradle files. */
public final class GroovyLanguage extends Language {
    private static GroovyLanguage instance;
    private GroovyLanguage() {
        setKeywords(new String[] {
            "as", "assert", "break", "case", "catch", "class", "const", "continue",
            "def", "default", "do", "else", "enum", "extends", "false", "finally",
            "for", "goto", "if", "implements", "import", "in", "instanceof", "interface",
            "new", "null", "package", "return", "super", "switch", "this", "throw",
            "throws", "trait", "true", "try", "while", "public", "protected", "private",
            "static", "abstract", "final", "native", "synchronized", "transient", "volatile"
        });
        setNames(new String[] {
            "plugins", "pluginManagement", "repositories", "dependencies", "implementation",
            "api", "compileOnly", "runtimeOnly", "android", "defaultConfig", "buildTypes",
            "flavorDimensions", "productFlavors", "sourceSets", "signingConfigs", "namespace",
            "compileSdk", "minSdk", "targetSdk", "versionCode", "versionName", "applicationId",
            "kotlinOptions", "tasks", "register", "configure", "alias", "libs", "mavenCentral",
            "google", "jcenter", "id", "apply", "include", "project", "rootProject"
        });
        setOperators(new char[] { '(', ')', '{', '}', '.', ',', ';', '=', '+', '-', '/', '*', '&', '!', '|', ':', '[', ']', '<', '>', '?', '~', '%', '^', '@' });
    }
    public static synchronized GroovyLanguage getInstance() {
        if (instance == null) instance = new GroovyLanguage();
        return instance;
    }
}
