package com.thirtydegreesray.openhub.ui.widget;

import tiiehenry.code.language.Language;

/** Kotlin and Kotlin DSL syntax profile. Uses the editor's lightweight tokenizer. */
public final class KotlinLanguage extends Language {
    private static KotlinLanguage instance;
    private KotlinLanguage() {
        setKeywords(new String[] {
            "package", "import", "as", "typealias", "class", "interface", "object",
            "constructor", "init", "this", "super", "val", "var", "fun", "override",
            "abstract", "final", "open", "private", "protected", "public", "internal",
            "inline", "noinline", "crossinline", "reified", "tailrec", "operator",
            "infix", "external", "suspend", "data", "sealed", "enum", "annotation",
            "expect", "actual", "const", "lateinit", "inner", "companion", "out", "in",
            "where", "by", "get", "set", "field", "property", "receiver", "param",
            "setparam", "delegate", "file", "if", "else", "when", "try", "catch",
            "finally", "for", "do", "while", "throw", "return", "break", "continue",
            "is", "!is", "as?", "typeof", "true", "false", "null"
        });
        setNames(new String[] {
            "String", "Char", "Boolean", "Byte", "Short", "Int", "Long", "Float", "Double",
            "Unit", "Any", "Nothing", "Array", "List", "MutableList", "Map", "MutableMap",
            "Set", "MutableSet", "Pair", "Triple", "Sequence", "Result", "println", "print",
            "TODO", "require", "check", "error", "lazy", "run", "let", "also", "apply", "with"
        });
        setOperators(new char[] { '(', ')', '{', '}', '.', ',', ';', '=', '+', '-', '/', '*', '&', '!', '|', ':', '[', ']', '<', '>', '?', '~', '%', '^', '@' });
    }
    public static synchronized KotlinLanguage getInstance() {
        if (instance == null) instance = new KotlinLanguage();
        return instance;
    }
}
