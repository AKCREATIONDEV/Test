package com.thirtydegreesray.openhub.ui.widget;

import tiiehenry.code.view.ColorSchemeLight;
import tiiehenry.code.view.ColorScheme.Colorable;

/** Higher-contrast editor colors for source code on a light background. */
public final class OpenHubColorScheme extends ColorSchemeLight {
    public OpenHubColorScheme() {
        setColor(Colorable.FOREGROUND, 0xFF202124);
        setColor(Colorable.BACKGROUND, 0xFFFFFFFF);
        setColor(Colorable.KEYWORD, 0xFF174EA6);
        setColor(Colorable.NAME, 0xFF7B1FA2);
        setColor(Colorable.LITERAL, 0xFF00695C);
        setColor(Colorable.STRING, 0xFFB3261E);
        setColor(Colorable.COMMENT, 0xFF188038);
        setColor(Colorable.SECONDARY, 0xFF5F6368);
        setColor(Colorable.LINE_HIGHLIGHT, 0x1E009688);
        setColor(Colorable.SELECTION_BACKGROUND, 0x663F8ECA);
        setColor(Colorable.SELECTION_FOREGROUND, 0xFF111111);
    }
}
