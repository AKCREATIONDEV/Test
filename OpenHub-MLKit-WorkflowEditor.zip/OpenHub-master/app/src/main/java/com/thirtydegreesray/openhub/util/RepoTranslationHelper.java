package com.thirtydegreesray.openhub.util;

import android.content.Context;
import android.support.annotation.NonNull;

import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

/** Offline-first on-device translation using downloadable ML Kit language models. */
public final class RepoTranslationHelper {
    public interface Callback {
        void onSuccess(String translatedText);
        void onFailure(String message);
    }
    private RepoTranslationHelper() { }

    public static void translate(@NonNull Context context, @NonNull final String sourceText,
                                 @NonNull final String targetLanguageTag,
                                 @NonNull final Callback callback) {
        if (sourceText.trim().length() == 0) {
            callback.onFailure("There is no description to translate.");
            return;
        }
        final LanguageIdentifier identifier = LanguageIdentification.getClient();
        identifier.identifyLanguage(sourceText).addOnSuccessListener(language -> {
            identifier.close();
            if (language == null || "und".equals(language)) {
                callback.onFailure("Could not identify the description language.");
                return;
            }
            if (targetLanguageTag.equals(language)) {
                callback.onSuccess(sourceText);
                return;
            }
            TranslatorOptions options = new TranslatorOptions.Builder()
                    .setSourceLanguage(language)
                    .setTargetLanguage(targetLanguageTag)
                    .build();
            final Translator translator = Translation.getClient(options);
            translator.downloadModelIfNeeded().addOnSuccessListener(unused ->
                    translator.translate(sourceText)
                            .addOnSuccessListener(result -> {
                                translator.close();
                                callback.onSuccess(result);
                            })
                            .addOnFailureListener(error -> {
                                translator.close();
                                callback.onFailure("Translation failed: " + error.getLocalizedMessage());
                            }))
                    .addOnFailureListener(error -> {
                        translator.close();
                        callback.onFailure("Language model download failed. Connect to internet once and retry: "
                                + error.getLocalizedMessage());
                    });
        }).addOnFailureListener(error -> {
            identifier.close();
            callback.onFailure("Language detection failed: " + error.getLocalizedMessage());
        });
    }
}
