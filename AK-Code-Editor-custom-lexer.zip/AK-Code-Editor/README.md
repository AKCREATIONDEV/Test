# AK Code Editor

Standalone Android code editor extracted from the TaoKDao editor engine.

## Architecture

- `CodeEditor/` — retained editing engine: text buffer/document, cursor, selection, undo/redo, rendering, editor input and editor view.
- `CodeEditorLexer/` — dependency-free handwritten lexical highlighter. It provides a `LexTask` implementation for each supported language and maps tokens to the existing `ColorScheme.Colorable` categories.
- `app/` — standalone AK Code Editor host application and its minimal UI.

## Supported language modes

Text, Java, Kotlin, JavaScript, ECMAScript, C, C++, Python 3, legacy Python, XML, HTML, CSS, JSON, Lua, Markdown, Bash and Objective-C.

Smali, the ANTLR module and the unused Language Server Protocol (LSP) adapter have been removed. The app uses `CodeEditorLexer` instead of `CodeEditorAntlr`.

## Highlighting behavior

The custom lexer recognizes language keywords, identifiers, function-like names, common built-in types, strings, numbers, operators, separators, line comments and block comments where the language supports them. It also reports matching `{}`, `()` and `[]` pairs to the retained editor engine. XML/HTML tag names and attributes receive separate token categories.

This module is intentionally a lexer for syntax highlighting only. It does not provide a complete grammar parser, AST, compiler diagnostics, semantic analysis, language server, or automatic formatter. Language-specific lexical edge cases (for example C++ raw strings, nested template grammars, shell heredoc parsing and embedded JavaScript inside HTML) are not equivalent to a full language parser.

## Build

Open the project root in AndroidIDE and build `:app:assembleDebug`. The project uses Android Gradle Plugin 8.13.0, Java 17, compile SDK 36 and min SDK 28. Ensure the matching Android SDK and Gradle dependencies are available in the build environment.
