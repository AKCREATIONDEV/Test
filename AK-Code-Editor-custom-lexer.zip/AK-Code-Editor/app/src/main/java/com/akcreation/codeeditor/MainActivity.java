package com.akcreation.codeeditor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import tiiehenry.code.LexTask;
import tiiehenry.code.language.Language;
import tiiehenry.code.language.bash.BashLanguage;
import tiiehenry.code.language.c.CLanguage;
import tiiehenry.code.language.cpp.CppLanguage;
import tiiehenry.code.language.css.CssLanguage;
import tiiehenry.code.language.html.HtmlLanguage;
import tiiehenry.code.language.java.JavaLanguage;
import tiiehenry.code.language.javascript.JavascriptLanguage;
import tiiehenry.code.language.ecmascript.ECMAScriptLanguage;
import tiiehenry.code.language.json.JsonLanguage;
import tiiehenry.code.language.kotlin.KotlinLanguage;
import tiiehenry.code.language.lua.LuaLanguage;
import tiiehenry.code.language.markdown.MarkdownLanguage;
import tiiehenry.code.language.objectivec.ObjectivecLanguage;
import tiiehenry.code.language.python.PythonLanguage;
import tiiehenry.code.language.python3.Python3Language;
import tiiehenry.code.language.text.TextLanguage;
import tiiehenry.code.language.xml.XmlLanguage;
import tiiehenry.code.view.CodeEditor;
import tiiehenry.code.view.ColorScheme;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/** Minimal standalone host for the TaoKDao CodeEditor engine. */
public class MainActivity extends Activity {
    private static final int REQ_OPEN = 101;
    private static final int REQ_SAVE_AS = 102;
    private final int bg = Color.rgb(24, 27, 33);
    private final int panel = Color.rgb(34, 39, 47);
    private final int accent = Color.rgb(128, 203, 196);
    private CodeEditor editor;
    private TextView fileLabel, status;
    private Spinner languageSpinner;
    private Uri currentUri;
    private String currentName = "Untitled.java";
    private boolean dark = true;
    private int textSize = 14;
    private final Map<String, Language> languages = new LinkedHashMap<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        initLanguages();
        ColorScheme.setDark(true);
        buildUi();
        int javaPosition = new java.util.ArrayList<>(languages.keySet()).indexOf("Java");
        if (javaPosition >= 0) languageSpinner.setSelection(javaPosition);
        applyLanguage("Java");
        editor.setText(sampleCode());
        updateStatus();
    }

    private void initLanguages() {
        languages.put("Text", TextLanguage.getInstance());
        languages.put("Java", JavaLanguage.getInstance());
        languages.put("Kotlin", KotlinLanguage.getInstance());
        languages.put("JavaScript", JavascriptLanguage.getInstance());
        languages.put("ECMAScript", ECMAScriptLanguage.getInstance());
        languages.put("C", CLanguage.getInstance());
        languages.put("C++", CppLanguage.getInstance());
        languages.put("Python", Python3Language.getInstance());
        languages.put("Python (legacy)", PythonLanguage.getInstance());
        languages.put("XML", XmlLanguage.getInstance());
        languages.put("HTML", HtmlLanguage.getInstance());
        languages.put("CSS", CssLanguage.getInstance());
        languages.put("JSON", JsonLanguage.getInstance());
        languages.put("Lua", LuaLanguage.getInstance());
        languages.put("Markdown", MarkdownLanguage.getInstance());
        languages.put("Bash", BashLanguage.getInstance());
        languages.put("Objective-C", ObjectivecLanguage.getInstance());
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(8), dp(8), dp(8));
        header.setBackgroundColor(panel);
        fileLabel = new TextView(this);
        fileLabel.setText(currentName);
        fileLabel.setTextColor(Color.WHITE);
        fileLabel.setTextSize(16);
        fileLabel.setTypeface(null, 1);
        header.addView(fileLabel, new LinearLayout.LayoutParams(0, dp(42), 1));
        Button menu = button("⋮");
        header.addView(menu, new LinearLayout.LayoutParams(dp(48), dp(42)));
        menu.setOnClickListener(this::showMenu);
        root.addView(header);

        HorizontalScrollView toolsScroll = new HorizontalScrollView(this);
        toolsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tools = new LinearLayout(this);
        tools.setGravity(Gravity.CENTER_VERTICAL);
        tools.setPadding(dp(6), dp(5), dp(6), dp(5));
        tools.setBackgroundColor(panel);
        addTool(tools, "Open", v -> openFile());
        addTool(tools, "Save", v -> saveFile());
        addTool(tools, "Undo", v -> { editor.undo(); updateStatus(); });
        addTool(tools, "Redo", v -> { editor.redo(); updateStatus(); });
        addTool(tools, "Find", v -> findText());
        toolsScroll.addView(tools);
        root.addView(toolsScroll);

        LinearLayout languageBar = new LinearLayout(this);
        languageBar.setPadding(dp(10), dp(4), dp(10), dp(4));
        languageBar.setGravity(Gravity.CENTER_VERTICAL);
        TextView langTitle = new TextView(this);
        langTitle.setText("LANGUAGE");
        langTitle.setTextColor(0xffaab4c0);
        langTitle.setTextSize(10);
        languageBar.addView(langTitle);
        languageSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                languages.keySet().toArray(new String[0]));
        languageSpinner.setAdapter(adapter);
        languageBar.addView(languageSpinner, new LinearLayout.LayoutParams(dp(190), dp(42)));
        languageSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> p, View v, int position, long id) {
                applyLanguage((String) p.getItemAtPosition(position));
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p) { }
        });
        root.addView(languageBar);

        editor = new CodeEditor(this);
        editor.setBackgroundColor(Color.rgb(20, 23, 29));
        editor.setTextSizeSP(textSize);
        editor.setWordWrap(false);
        editor.getSetting().isShowLineNumbers = true;
        editor.getSetting().isAutoIndent = true;
        editor.getSetting().isAutoComplete = true;
        editor.getSetting().isHighlightCurrentRow = true;
        editor.setPadding(dp(4), dp(6), dp(4), dp(6));
        root.addView(editor, new LinearLayout.LayoutParams(-1, 0, 1));

        status = new TextView(this);
        status.setTextColor(0xffb8c2ce);
        status.setTextSize(11);
        status.setPadding(dp(12), dp(7), dp(12), dp(7));
        status.setBackgroundColor(panel);
        root.addView(status);
        setContentView(root);
    }

    private void addTool(LinearLayout row, String title, View.OnClickListener listener) {
        Button b = button(title);
        row.addView(b, new LinearLayout.LayoutParams(-2, dp(38)));
        b.setOnClickListener(listener);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff46515f));
        return b;
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void applyLanguage(String name) {
        Language language = languages.get(name);
        if (language != null && editor != null) {
            LexTask task = language.newLexTask();
            editor.setLexTask(task);
            updateStatus();
        }
    }

    private void showMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add("Save As").setOnMenuItemClickListener(i -> { saveAs(); return true; });
        popup.getMenu().add("Toggle Light / Dark").setOnMenuItemClickListener(i -> { toggleTheme(); return true; });
        popup.getMenu().add("Toggle Line Numbers").setOnMenuItemClickListener(i -> {
            editor.getSetting().isShowLineNumbers = !editor.getSetting().isShowLineNumbers;
            editor.invalidate(); return true;
        });
        popup.getMenu().add("Toggle Word Wrap").setOnMenuItemClickListener(i -> {
            editor.setWordWrap(!editor.getSetting().isWordWrap); return true;
        });
        popup.getMenu().add("Font Size +").setOnMenuItemClickListener(i -> { textSize = Math.min(30, textSize + 1); editor.setTextSizeSP(textSize); return true; });
        popup.getMenu().add("Font Size −").setOnMenuItemClickListener(i -> { textSize = Math.max(9, textSize - 1); editor.setTextSizeSP(textSize); return true; });
        popup.getMenu().add("Go to Line").setOnMenuItemClickListener(i -> { goToLine(); return true; });
        popup.show();
    }

    private void toggleTheme() {
        dark = !dark;
        ColorScheme.setDark(dark);
        getWindow().setStatusBarColor(dark ? bg : 0xffe8edf2);
        getWindow().setNavigationBarColor(dark ? bg : 0xffe8edf2);
        editor.setBackgroundColor(dark ? 0xff14171d : Color.WHITE);
        fileLabel.setTextColor(dark ? Color.WHITE : Color.BLACK);
        status.setTextColor(dark ? 0xffb8c2ce : 0xff303943);
    }

    private void openFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_OPEN);
    }

    private void saveFile() {
        if (currentUri == null) { saveAs(); return; }
        writeToUri(currentUri);
    }

    private void saveAs() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TITLE, currentName);
        startActivityForResult(i, REQ_SAVE_AS);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_OPEN) {
            try {
                getContentResolver().takePersistableUriPermission(uri, data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
            } catch (Exception ignored) { }
            readFromUri(uri);
        } else if (requestCode == REQ_SAVE_AS) {
            currentUri = uri;
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION); }
            catch (Exception ignored) { }
            currentName = queryName(uri);
            fileLabel.setText(currentName);
            writeToUri(uri);
        }
    }

    private void readFromUri(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri);
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder text = new StringBuilder();
            char[] buffer = new char[8192]; int n;
            while ((n = reader.read(buffer)) > 0) text.append(buffer, 0, n);
            editor.setText(text);
            currentUri = uri;
            currentName = queryName(uri);
            fileLabel.setText(currentName);
            selectLanguageForName(currentName);
            updateStatus();
            Toast.makeText(this, "File opened", Toast.LENGTH_SHORT).show();
        } catch (Exception e) { toast("Open failed: " + e.getMessage()); }
    }

    private void writeToUri(Uri uri) {
        try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) throw new IllegalStateException("Cannot open destination");
            out.write(editor.getString().getBytes(StandardCharsets.UTF_8));
            out.flush();
            toast("Saved: " + currentName);
        } catch (Exception e) { toast("Save failed: " + e.getMessage()); }
    }

    private String queryName(Uri uri) {
        String path = uri.getLastPathSegment();
        if (path == null || path.isEmpty()) return "Untitled.txt";
        int colon = path.lastIndexOf(':');
        return colon >= 0 ? path.substring(colon + 1) : path;
    }

    private void selectLanguageForName(String name) {
        String n = name.toLowerCase(java.util.Locale.ROOT);
        String lang = "Text";
        if (n.endsWith(".java")) lang = "Java";
        else if (n.endsWith(".kt")) lang = "Kotlin";
        else if (n.endsWith(".js") || n.endsWith(".mjs")) lang = "JavaScript";
        else if (n.endsWith(".c")) lang = "C";
        else if (n.endsWith(".cpp") || n.endsWith(".cc") || n.endsWith(".h")) lang = "C++";
        else if (n.endsWith(".py")) lang = "Python";
        else if (n.endsWith(".xml")) lang = "XML";
        else if (n.endsWith(".html") || n.endsWith(".htm")) lang = "HTML";
        else if (n.endsWith(".css")) lang = "CSS";
        else if (n.endsWith(".json")) lang = "JSON";
        else if (n.endsWith(".lua")) lang = "Lua";
        else if (n.endsWith(".md")) lang = "Markdown";
        else if (n.endsWith(".sh")) lang = "Bash";
        else if (n.endsWith(".m")) lang = "Objective-C";
        int position = new java.util.ArrayList<>(languages.keySet()).indexOf(lang);
        if (position >= 0) languageSpinner.setSelection(position);
    }

    private void findText() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Find text");
        new AlertDialog.Builder(this).setTitle("Find in document").setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Find", (d, w) -> {
                    String q = input.getText().toString();
                    if (q.isEmpty()) return;
                    String all = editor.getString();
                    int start = Math.max(0, editor.getSelectionEnd());
                    int found = all.indexOf(q, start);
                    if (found < 0) found = all.indexOf(q);
                    if (found >= 0) editor.selectRange(found, found + q.length());
                    else toast("Not found");
                }).show();
    }

    private void goToLine() {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("Line number");
        new AlertDialog.Builder(this).setTitle("Go to line").setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Go", (d, w) -> {
                    try { editor.gotoLine(Integer.parseInt(input.getText().toString())); updateStatus(); }
                    catch (Exception e) { toast("Invalid line number"); }
                }).show();
    }

    private void updateStatus() {
        if (status != null && editor != null)
            status.setText("Ln " + editor.getCurrentLine() + "   •   " + editor.getString().length() + " chars   •   " + (editor.getLanguage() == null ? "Text" : editor.getLanguage().getName()));
    }

    private String sampleCode() {
        return "// AK Code Editor\n" +
                "// Powered by TaoKDao CodeEditor engine\n\n" +
                "public class Main {\n" +
                "    public static void main(String[] args) {\n" +
                "        String message = \"Hello, Code Editor!\";\n" +
                "        System.out.println(message);\n" +
                "    }\n" +
                "}\n";
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
}
