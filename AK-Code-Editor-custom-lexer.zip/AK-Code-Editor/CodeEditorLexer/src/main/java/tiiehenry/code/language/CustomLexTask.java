package tiiehenry.code.language;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import tiiehenry.code.LexTask;
import tiiehenry.code.praser.BlockLine;
import tiiehenry.code.praser.SymbolPair;
import tiiehenry.code.praser.Span;
import tiiehenry.code.praser.Variable;
import tiiehenry.code.view.ColorScheme;

/**
 * Dependency-free, hand-written lexer used for fast syntax highlighting.
 * It deliberately performs lexical highlighting only; it does not build ASTs
 * or report compiler/parser errors.
 */
public final class CustomLexTask extends LexTask<String, ColorScheme.Colorable> {
    private static final String[] COMMON_OPERATORS = {
        ">>>=", "<<=", ">>=", "===", "!==", "...", "->>", "?.", "??=",
        "==", "!=", "<=", ">=", "++", "--", "&&", "||", "+=", "-=",
        "*=", "/=", "%=", "&=", "|=", "^=", "<<", ">>>", ">>", "->",
        "::", "=>", "?.", "??", "**", "//", "##"
    };
    private static final Set<String> COMMON_TYPES = new HashSet<>(Arrays.asList(
        "int","long","short","byte","float","double","boolean","char","void",
        "bool","string","String","var","dynamic","object","decimal","uint",
        "unsigned","signed","size_t","auto"
    ));

    public CustomLexTask(Language language) {
        super(language);
        installKeywords(language);
    }

    private static void installKeywords(Language language) {
        String name = language.getName().toLowerCase(Locale.ROOT);
        String words;
        switch (name) {
            case "java":
                words = "abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while";
                break;
            case "kotlin":
                words = "as break class continue do else false for fun if in interface is null object package return super this throw true try typealias typeof val var when while by catch constructor delegate dynamic field file finally get import init param property receiver set setparam where actual abstract annotation companion const crossinline data enum external final infix inline inner internal lateinit noinline open operator out override private protected public reified sealed suspend tailrec vararg";
                break;
            case "python":
            case "python3":
                words = "False None True and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield";
                break;
            case "javascript":
            case "ecmascript":
                words = "async await break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new return super switch this throw try typeof var void while with yield true false null undefined";
                break;
            case "c":
            case "cpp":
            case "c++":
            case "objectivec":
                words = "alignas alignof asm auto bool break case catch char class const constexpr const_cast continue decltype default delete do double else enum explicit export extern false float for friend goto if inline int long mutable namespace new noexcept nullptr operator private protected public register reinterpret_cast return short signed sizeof static static_assert static_cast struct switch template this thread_local throw true try typedef typeid typename union unsigned using virtual void volatile wchar_t while";
                break;
            case "css":
                words = "important inherit initial unset none auto";
                break;
            case "json":
                words = "true false null";
                break;
            case "lua":
                words = "and break do else elseif end false for function goto if in local nil not or repeat return then true until while";
                break;
            case "bash":
                words = "if then else elif fi for while until do done case esac function in select time coproc local export readonly declare typeset unset shift source return exit break continue eval exec set trap";
                break;
            case "dart":
                words = "abstract as assert async await break case catch class const continue covariant default deferred do dynamic else enum export extends extension external factory false final finally for Function get hide if implements import in interface is late library mixin new null on operator part rethrow return set show static super switch sync this throw true try typedef var void while with yield";
                break;
            default:
                words = "";
        }
        // Preserve curated keyword lists already supplied by a language class
        // (for example C, C++ and Lua); provide defaults only when none exist.
        if (!words.isEmpty() && language.getKeywords().length == 0) {
            language.setKeywords(words.split("\\s+"));
        }
    }

    @Override
    protected boolean tokenizePrepared(List<Span> tokens, List<BlockLine> lines,
            List<SymbolPair> pairs, List<Variable> variables, String code,
            int fromIndex, int fromLineOffset, int fromLine, boolean analyze) {
        if (code == null || code.isEmpty()) return true;
        final String lang = language.getName().toLowerCase(Locale.ROOT);
        final boolean python = lang.startsWith("python");
        final boolean bash = lang.equals("bash");
        final boolean lua = lang.equals("lua");
        final boolean markup = lang.equals("xml") || lang.equals("html");
        final boolean markdown = lang.equals("markdown");
        final boolean css = lang.equals("css");
        final boolean json = lang.equals("json");
        final boolean cFamily = lang.equals("java") || lang.equals("kotlin") ||
                lang.equals("c") || lang.equals("cpp") || lang.equals("c++") ||
                lang.equals("javascript") || lang.equals("ecmascript") ||
                lang.equals("objectivec");
        // Do not apply C-style comments to Python, Bash, CSS, JSON or Markdown.
        final String lineComment = python || bash ? "#" : lua ? "--" :
                (cFamily ? "//" : "");
        final String blockOpen = markup || markdown ? "<!--" : lua ? "--[[" :
                (cFamily || css ? "/*" : "");
        final String blockClose = markup || markdown ? "-->" : lua ? "]]" :
                (cFamily || css ? "*/" : "");

        ArrayDeque<Integer> curly = new ArrayDeque<>();
        ArrayDeque<Integer> paren = new ArrayDeque<>();
        ArrayDeque<Integer> bracket = new ArrayDeque<>();
        int i = 0, line = fromLine, col = fromLineOffset, plainStart = 0;
        int plainLine = line, plainCol = col;
        boolean insideMarkupTag = false;
        boolean markupTagNamePending = false;
        while (i < code.length() && !abort) {
            int start = i, startLine = line, startCol = col;
            char c = code.charAt(i);
            if (Character.isWhitespace(c)) {
                i++; col++;
                if (c == '\n') { line++; col = 0; }
                continue;
            }

            ColorScheme.Colorable color = null;
            int end = i + 1;

            // Line and block comments.
            if ((!lineComment.isEmpty() && code.startsWith(lineComment, i)) ||
                (!blockOpen.isEmpty() && code.startsWith(blockOpen, i))) {
                boolean block = !blockOpen.isEmpty() && code.startsWith(blockOpen, i);
                String marker = block ? blockOpen : lineComment;
                end = i + marker.length();
                if (block) {
                    int close = code.indexOf(blockClose, end);
                    end = close < 0 ? code.length() : close + blockClose.length();
                    color = ColorScheme.Colorable.COMMENT_REGION;
                } else {
                    int nl = code.indexOf('\n', end);
                    end = nl < 0 ? code.length() : nl;
                    color = ColorScheme.Colorable.COMMENT_SINGLE;
                }
            } else if (c == '"' || c == '\'' || c == '`') {
                char quote = c;
                boolean triple = i + 2 < code.length() &&
                    code.charAt(i + 1) == quote && code.charAt(i + 2) == quote;
                end = i + (triple ? 3 : 1);
                boolean escaped = false;
                while (end < code.length()) {
                    char q = code.charAt(end);
                    if (!escaped && (triple
                            ? end + 2 < code.length() && code.charAt(end) == quote &&
                              code.charAt(end + 1) == quote && code.charAt(end + 2) == quote
                            : q == quote)) {
                        end += triple ? 3 : 1;
                        break;
                    }
                    if (!escaped && q == '\\') escaped = true; else escaped = false;
                    end++;
                }
                color = ColorScheme.Colorable.LITERAL_STRING;
            } else if (Character.isDigit(c) ||
                    (c == '.' && i + 1 < code.length() && Character.isDigit(code.charAt(i + 1)))) {
                end = i + 1;
                while (end < code.length()) {
                    char n = code.charAt(end);
                    if (Character.isLetterOrDigit(n) || n == '_' || n == '.') end++;
                    else if ((n == '+' || n == '-') && end > i &&
                            "eEpP".indexOf(code.charAt(end - 1)) >= 0) end++;
                    else break;
                }
                color = ColorScheme.Colorable.LITERAL_NUM;
            } else if (Character.isJavaIdentifierStart(c) || c == '$') {
                end = i + 1;
                while (end < code.length()) {
                    char n = code.charAt(end);
                    if (Character.isJavaIdentifierPart(n) || n == '$') end++;
                    else break;
                }
                String word = code.substring(i, end);
                if (markup && insideMarkupTag) {
                    color = markupTagNamePending ? ColorScheme.Colorable.KEYWORD :
                            ColorScheme.Colorable.LITERAL_VAR;
                    markupTagNamePending = false;
                } else if (language.isKeyword(word) || isBuiltinKeyword(lang, word)) {
                    color = ColorScheme.Colorable.KEYWORD;
                } else if (isLiteral(word)) {
                    color = ColorScheme.Colorable.BASIC_TYPE;
                } else if (COMMON_TYPES.contains(word)) {
                    color = ColorScheme.Colorable.BASIC_TYPE;
                } else if (language.isInternalFunc(word) ||
                        (end < code.length() && code.charAt(end) == '(')) {
                    color = ColorScheme.Colorable.LITERAL_FUNC;
                } else {
                    color = ColorScheme.Colorable.LITERAL_VAR;
                }
            } else {
                String op = matchOperator(code, i);
                if (op != null) end = i + op.length();
                color = "{}[]();,.".indexOf(c) >= 0
                    ? ColorScheme.Colorable.SEPARATOR : ColorScheme.Colorable.SYMBOL;
                if (markup && c == '<') {
                    insideMarkupTag = true;
                    markupTagNamePending = true;
                } else if (markup && c == '>') {
                    insideMarkupTag = false;
                    markupTagNamePending = false;
                } else if (markdown && "#*_>-![]".indexOf(c) >= 0) {
                    color = ColorScheme.Colorable.KEYWORD_SECOND;
                }
            }

            // Flush untouched whitespace/text before this token.
            if (start > plainStart) {
                addTokenSpan(tokens, plainLine, plainCol, fromIndex + plainStart,
                    start - plainStart, ColorScheme.Colorable.TEXT);
            }
            addTokenSpan(tokens, startLine, startCol, fromIndex + start,
                end - start, color == null ? ColorScheme.Colorable.TEXT : color);

            // Delimiter and block-region metadata used by the editor.
            if (end == start + 1) {
                if (c == '{') { curly.push(fromIndex + start); openLineStack(lineCurlyStacks, startLine, fromIndex + start); }
                else if (c == '}' && !curly.isEmpty()) {
                    int open = curly.pop(); addPair(pairs, open, startLine, fromIndex + start, startLine);
                    closeLineStack(lineCurlyStacks, startLine, fromIndex + start, lines);
                } else if (c == '(') { paren.push(fromIndex + start); openLineStack(lineParenStacks, startLine, fromIndex + start); }
                else if (c == ')' && !paren.isEmpty()) {
                    int open = paren.pop(); addPair(pairs, open, startLine, fromIndex + start, startLine);
                    closeLineStack(lineParenStacks, startLine, fromIndex + start, lines);
                } else if (c == '[') { bracket.push(fromIndex + start); openLineStack(lineBracketStacks, startLine, fromIndex + start); }
                else if (c == ']' && !bracket.isEmpty()) {
                    int open = bracket.pop(); addPair(pairs, open, startLine, fromIndex + start, startLine);
                    closeLineStack(lineBracketStacks, startLine, fromIndex + start, lines);
                }
            }
            while (i < end) {
                char consumed = code.charAt(i++);
                if (consumed == '\n') { line++; col = 0; } else col++;
            }
            plainStart = i; plainLine = line; plainCol = col;
        }
        if (plainStart < code.length()) {
            addTokenSpan(tokens, plainLine, plainCol, fromIndex + plainStart,
                code.length() - plainStart, ColorScheme.Colorable.TEXT);
        }
        return true;
    }

    private static boolean isLiteral(String s) {
        return "true false null None True False nil undefined".contains(" " + s + " ");
    }

    private static boolean isBuiltinKeyword(String lang, String word) {
        if (lang.equals("json")) return "true".equals(word) || "false".equals(word) || "null".equals(word);
        return false;
    }

    private static String matchOperator(String code, int at) {
        for (String op : COMMON_OPERATORS) if (code.startsWith(op, at)) return op;
        return null;
    }

    @Override
    protected ColorScheme.Colorable getTokenColorable(ColorScheme.Colorable tokenType) {
        return tokenType;
    }
}
