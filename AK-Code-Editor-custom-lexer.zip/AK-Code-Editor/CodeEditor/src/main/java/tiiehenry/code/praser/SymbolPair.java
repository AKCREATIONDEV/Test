package tiiehenry.code.praser;

public class SymbolPair {
    public int left;
    public int top;
    public int right;
    public int bottom;
    public int width;
    public SymbolPair(int left, int top, int right, int bottom) {
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
    }
}
