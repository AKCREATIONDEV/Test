package com.thirtydegreesray.openhub.util;

import android.support.annotation.DrawableRes;
import android.support.annotation.StringRes;

import com.thirtydegreesray.openhub.R;

/**
 * Helper for GitHub Actions status / conclusion presentation.
 */
public class ActionsHelper {

    public static final int KIND_SUCCESS = 1;
    public static final int KIND_FAILURE = 2;
    public static final int KIND_RUNNING = 3;
    public static final int KIND_QUEUED = 4;
    public static final int KIND_CANCELLED = 5;
    public static final int KIND_SKIPPED = 6;
    public static final int KIND_WARNING = 7;

    private static final int COLOR_SUCCESS = 0xFF2DA44E;
    private static final int COLOR_FAILURE = 0xFFCF222E;
    private static final int COLOR_RUNNING = 0xFF0969DA;
    private static final int COLOR_QUEUED = 0xFFBF8700;
    private static final int COLOR_NEUTRAL = 0xFF6E7781;

    private ActionsHelper() {
    }

    /**
     * Maps GitHub's status + conclusion pair to one display kind.
     */
    public static int getKind(String status, String conclusion) {
        if ("completed".equals(status)) {
            if ("success".equals(conclusion)) {
                return KIND_SUCCESS;
            } else if ("failure".equals(conclusion) || "timed_out".equals(conclusion)
                    || "startup_failure".equals(conclusion)) {
                return KIND_FAILURE;
            } else if ("cancelled".equals(conclusion)) {
                return KIND_CANCELLED;
            } else if ("action_required".equals(conclusion)) {
                return KIND_WARNING;
            } else {
                // skipped, neutral, stale or unknown
                return KIND_SKIPPED;
            }
        } else if ("in_progress".equals(status)) {
            return KIND_RUNNING;
        } else {
            // queued, waiting, pending, requested
            return KIND_QUEUED;
        }
    }

    @DrawableRes
    public static int getIconRes(int kind) {
        switch (kind) {
            case KIND_SUCCESS:
                return R.drawable.ic_run_success;
            case KIND_FAILURE:
                return R.drawable.ic_run_failure;
            case KIND_RUNNING:
                return R.drawable.ic_run_running;
            case KIND_CANCELLED:
                return R.drawable.ic_run_cancelled;
            case KIND_SKIPPED:
                return R.drawable.ic_run_skipped;
            case KIND_WARNING:
            case KIND_QUEUED:
            default:
                return R.drawable.ic_run_queued;
        }
    }

    public static int getColor(int kind) {
        switch (kind) {
            case KIND_SUCCESS:
                return COLOR_SUCCESS;
            case KIND_FAILURE:
                return COLOR_FAILURE;
            case KIND_RUNNING:
                return COLOR_RUNNING;
            case KIND_WARNING:
            case KIND_QUEUED:
                return COLOR_QUEUED;
            case KIND_CANCELLED:
            case KIND_SKIPPED:
            default:
                return COLOR_NEUTRAL;
        }
    }

    @StringRes
    public static int getTextRes(int kind) {
        switch (kind) {
            case KIND_SUCCESS:
                return R.string.actions_state_success;
            case KIND_FAILURE:
                return R.string.actions_state_failure;
            case KIND_RUNNING:
                return R.string.actions_state_running;
            case KIND_CANCELLED:
                return R.string.actions_state_cancelled;
            case KIND_SKIPPED:
                return R.string.actions_state_skipped;
            case KIND_WARNING:
                return R.string.actions_state_warning;
            case KIND_QUEUED:
            default:
                return R.string.actions_state_queued;
        }
    }

    /**
     * 83000 -> "1m 23s", 45000 -> "45s", 7380000 -> "2h 3m"; empty for unknown (negative).
     */
    public static String formatDuration(long millis) {
        if (millis < 0) return "";
        long totalSeconds = millis / 1000;
        long hours = totalSeconds / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        long seconds = totalSeconds % 60;
        if (hours > 0) {
            return hours + "h " + minutes + "m";
        } else if (minutes > 0) {
            return minutes + "m " + seconds + "s";
        } else {
            return seconds + "s";
        }
    }

}
