

package com.thirtydegreesray.openhub.http;

import android.support.annotation.NonNull;

import com.thirtydegreesray.openhub.mvp.model.ArtifactsResponse;
import com.thirtydegreesray.openhub.mvp.model.RepoContent;
import com.thirtydegreesray.openhub.mvp.model.UpdateFileRequest;
import com.thirtydegreesray.openhub.mvp.model.UpdateFileResponse;
import com.thirtydegreesray.openhub.mvp.model.Workflow;
import com.thirtydegreesray.openhub.mvp.model.Branch;
import com.thirtydegreesray.openhub.mvp.model.Event;
import com.thirtydegreesray.openhub.mvp.model.FileModel;
import com.thirtydegreesray.openhub.mvp.model.Release;
import com.thirtydegreesray.openhub.mvp.model.Repository;
import com.thirtydegreesray.openhub.mvp.model.User;
import com.thirtydegreesray.openhub.mvp.model.WorkflowDispatchRequest;
import com.thirtydegreesray.openhub.mvp.model.WorkflowJobsResponse;
import com.thirtydegreesray.openhub.mvp.model.WorkflowRunsResponse;
import com.thirtydegreesray.openhub.mvp.model.WorkflowsResponse;

import java.util.ArrayList;
import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.Response;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.PATCH;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.Url;
import rx.Observable;

/**
 * Created on 2017/8/1.
 *
 * @author ThirtyDegreesRay
 */

public interface RepoService {

    /**
     * List repositories being starred
     */
    @NonNull @GET("users/{user}/starred")
    Observable<Response<ArrayList<Repository>>> getStarredRepos(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("user") @NonNull String user,
            @Query("page") int page,
            @Query("sort") String sort,
            @Query("direction") String direction
    );

    @NonNull @GET("user/repos")
    Observable<retrofit2.Response<ArrayList<Repository>>> getUserRepos(
            @Header("forceNetWork") boolean forceNetWork,
            @Query("page") int page,
            @Query("type") String type,
            @Query("sort") String sort,
            @Query("direction") String direction
    );

    /**
     * List user repositories
     */
    @NonNull @GET("users/{user}/repos")
    Observable<retrofit2.Response<ArrayList<Repository>>> getUserPublicRepos(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("user") @NonNull String user,
            @Query("page") int page,
            @Query("type") String type,
            @Query("sort") String sort,
            @Query("direction") String direction
    );

    /**
     * Check if you are starring a repository
     */
    @NonNull @GET("user/starred/{owner}/{repo}")
    Observable<Response<ResponseBody>> checkRepoStarred(
            @Path("owner") String owner,
            @Path("repo") String repo
    );

    /**
     * Star a repository
     */
    @NonNull @PUT("user/starred/{owner}/{repo}")
    Observable<Response<ResponseBody>> starRepo(
            @Path("owner") String owner,
            @Path("repo") String repo
    );

    /**
     * Unstar a repository
     */
    @NonNull @DELETE("user/starred/{owner}/{repo}")
    Observable<Response<ResponseBody>> unstarRepo(
            @Path("owner") String owner,
            @Path("repo") String repo
    );

    @NonNull @GET("user/subscriptions/{owner}/{repo}")
    Observable<Response<ResponseBody>> checkRepoWatched(
            @Path("owner") String owner,
            @Path("repo") String repo
    );

    @NonNull @PUT("user/subscriptions/{owner}/{repo}")
    Observable<Response<ResponseBody>> watchRepo(
            @Path("owner") String owner,
            @Path("repo") String repo
    );

    @NonNull @DELETE("user/subscriptions/{owner}/{repo}")
    Observable<Response<ResponseBody>> unwatchRepo(
            @Path("owner") String owner,
            @Path("repo") String repo
    );

    @NonNull @GET @Headers("Accept: application/vnd.github.html")
    Observable<Response<ResponseBody>> getFileAsHtmlStream(
            @Header("forceNetWork") boolean forceNetWork,
            @Url String url
    );

    @NonNull @GET @Headers("Accept: application/vnd.github.VERSION.raw")
    Observable<Response<ResponseBody>> getFileAsStream(
            @Header("forceNetWork") boolean forceNetWork,
            @Url String url
    );

    @NonNull @GET("repos/{owner}/{repo}/contents/{path}")
    Observable<Response<ArrayList<FileModel>>> getRepoFiles(
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path(value = "path", encoded = true) String path,
            @Query("ref") String branch
    );

    @NonNull @GET("repos/{owner}/{repo}/branches")
    Observable<Response<ArrayList<Branch>>> getBranches(
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Query("per_page") int perPage
    );

    @NonNull @GET("repos/{owner}/{repo}/tags")
    Observable<Response<ArrayList<Branch>>> getTags(
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Query("per_page") int perPage
    );

    @NonNull @GET("repos/{owner}/{repo}/stargazers")
    Observable<Response<ArrayList<User>>> getStargazers(
            @Header("forceNetWork") boolean forceNetWork,
            @Path(value = "owner") String owner,
            @Path(value = "repo") String repo,
            @Query("page") int page
    );

    @NonNull @GET("repos/{owner}/{repo}/contributors")
    Observable<Response<ArrayList<User>>> getContributors(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Query("page") int page
    );

    @NonNull @GET("repos/{owner}/{repo}/subscribers")
    Observable<Response<ArrayList<User>>> getWatchers(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Query("page") int page
    );

    @NonNull @GET("repos/{owner}/{repo}")
    Observable<Response<Repository>> getRepoInfo(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("owner") String owner,
            @Path("repo") String repo
    );

    @NonNull @POST("repos/{owner}/{repo}/forks")
    Observable<Response<Repository>> createFork(
            @Path("owner") String owner,
            @Path("repo") String repo
    );

    @NonNull @GET("repos/{owner}/{repo}/forks")
    Observable<Response<ArrayList<Repository>>> getForks(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Query("page") int page
    );

    /**
     * List public events for a network of repositories
     */
    @NonNull @GET("networks/{owner}/{repo}/events")
    Observable<Response<ArrayList<Event>>> getRepoEvent(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Query("page") int page
    );

    @NonNull @GET("repos/{owner}/{repo}/releases")
    @Headers("Accept: application/vnd.github.html")
    Observable<Response<ArrayList<Release>>> getReleases(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Query("page") int page
    );

    @NonNull @GET("repos/{owner}/{repo}/releases/tags/{tag}")
    @Headers("Accept: application/vnd.github.html")
    Observable<Response<Release>> getReleaseByTagName(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path("tag") String tag
    );

    /**
     * Create a repository for the authenticated user
     */
    @NonNull @POST("user/repos")
    Observable<Response<Repository>> createRepo(@NonNull @Body Map<String, Object> params);

    /**
     * Update a repository
     */
    @NonNull @PATCH("repos/{owner}/{repo}")
    Observable<Response<Repository>> updateRepo(
            @NonNull @Path("owner") String owner,
            @NonNull @Path("repo") String repo,
            @NonNull @Body Map<String, Object> params
    );

    /**
     * Delete a repository
     */
    @NonNull @DELETE("repos/{owner}/{repo}")
    Observable<Response<ResponseBody>> deleteRepo(
            @NonNull @Path("owner") String owner,
            @NonNull @Path("repo") String repo
    );

    // ------------------------------------------------------------------
    // GitHub Actions
    // ------------------------------------------------------------------

    /**
     * List workflow runs for a repository
     */
    @NonNull @GET("repos/{owner}/{repo}/actions/runs")
    Observable<Response<WorkflowRunsResponse>> getWorkflowRuns(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Query("page") int page,
            @Query("per_page") int perPage,
            @Query("status") String status
    );

    /**
     * List runs of one workflow (id or file name)
     */
    @NonNull @GET("repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs")
    Observable<Response<WorkflowRunsResponse>> getWorkflowRunsByWorkflow(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path("workflow_id") String workflowId,
            @Query("page") int page,
            @Query("per_page") int perPage,
            @Query("status") String status
    );

    /**
     * List repository workflows
     */
    @NonNull @GET("repos/{owner}/{repo}/actions/workflows")
    Observable<Response<WorkflowsResponse>> getWorkflows(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Query("per_page") int perPage
    );

    /**
     * Create a workflow dispatch event (needs workflow_dispatch trigger), returns 204
     */
    @NonNull @POST("repos/{owner}/{repo}/actions/workflows/{workflow_id}/dispatches")
    Observable<Response<ResponseBody>> dispatchWorkflow(
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path("workflow_id") String workflowId,
            @Body WorkflowDispatchRequest body
    );

    /**
     * Enable a workflow, returns 204
     */
    @NonNull @PUT("repos/{owner}/{repo}/actions/workflows/{workflow_id}/enable")
    Observable<Response<ResponseBody>> enableWorkflow(
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path("workflow_id") String workflowId
    );

    /**
     * Disable a workflow, returns 204
     */
    @NonNull @PUT("repos/{owner}/{repo}/actions/workflows/{workflow_id}/disable")
    Observable<Response<ResponseBody>> disableWorkflow(
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path("workflow_id") String workflowId
    );

    /**
     * Cancel a workflow run, returns 202
     */
    @NonNull @POST("repos/{owner}/{repo}/actions/runs/{run_id}/cancel")
    Observable<Response<ResponseBody>> cancelWorkflowRun(
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path("run_id") long runId
    );

    /**
     * Re-run all jobs of a workflow run, returns 201
     */
    @NonNull @POST("repos/{owner}/{repo}/actions/runs/{run_id}/rerun")
    Observable<Response<ResponseBody>> rerunWorkflowRun(
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path("run_id") long runId
    );

    /**
     * Re-run only the failed jobs of a workflow run, returns 201
     */
    @NonNull @POST("repos/{owner}/{repo}/actions/runs/{run_id}/rerun-failed-jobs")
    Observable<Response<ResponseBody>> rerunFailedJobs(
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path("run_id") long runId
    );

    /**
     * Delete a workflow run, returns 204
     */
    @NonNull @DELETE("repos/{owner}/{repo}/actions/runs/{run_id}")
    Observable<Response<ResponseBody>> deleteWorkflowRun(
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path("run_id") long runId
    );

    /**
     * List jobs (with steps) of a workflow run
     */
    @NonNull @GET("repos/{owner}/{repo}/actions/runs/{run_id}/jobs")
    Observable<Response<WorkflowJobsResponse>> getWorkflowRunJobs(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path("run_id") long runId,
            @Query("per_page") int perPage
    );

    /**
     * List artifacts of a workflow run
     */
    @NonNull @GET("repos/{owner}/{repo}/actions/runs/{run_id}/artifacts")
    Observable<Response<ArtifactsResponse>> getWorkflowRunArtifacts(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path("run_id") long runId,
            @Query("per_page") int perPage
    );

    /**
     * Get one workflow (its "path" is the workflow file)
     */
    @NonNull @GET("repos/{owner}/{repo}/actions/workflows/{workflow_id}")
    Observable<Response<Workflow>> getWorkflow(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path("workflow_id") String workflowId
    );

    /**
     * Get a single file (base64 content and the blob sha needed to update it)
     */
    @NonNull @GET("repos/{owner}/{repo}/contents/{path}")
    Observable<Response<RepoContent>> getContentFile(
            @Header("forceNetWork") boolean forceNetWork,
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path(value = "path", encoded = true) String path,
            @Query("ref") String ref
    );

    /**
     * Update a file, this creates a commit
     */
    @NonNull @PUT("repos/{owner}/{repo}/contents/{path}")
    Observable<Response<UpdateFileResponse>> updateFile(
            @Path("owner") String owner,
            @Path("repo") String repo,
            @Path(value = "path", encoded = true) String path,
            @Body UpdateFileRequest body
    );

}
