package com.thirtydegreesray.openhub.ui.fragment;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.PopupMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.inject.component.AppComponent;
import com.thirtydegreesray.openhub.inject.component.DaggerFragmentComponent;
import com.thirtydegreesray.openhub.inject.module.FragmentModule;
import com.thirtydegreesray.openhub.mvp.contract.IActionsContract;
import com.thirtydegreesray.openhub.mvp.model.Artifact;
import com.thirtydegreesray.openhub.mvp.model.Branch;
import com.thirtydegreesray.openhub.mvp.model.Workflow;
import com.thirtydegreesray.openhub.mvp.model.WorkflowJob;
import com.thirtydegreesray.openhub.mvp.model.WorkflowRun;
import com.thirtydegreesray.openhub.mvp.model.WorkflowStep;
import com.thirtydegreesray.openhub.mvp.presenter.ActionsPresenter;
import com.thirtydegreesray.openhub.ui.activity.ActionsActivity;
import com.thirtydegreesray.openhub.ui.activity.LogViewerActivity;
import com.thirtydegreesray.openhub.ui.activity.WorkflowEditorActivity;
import com.thirtydegreesray.openhub.ui.adapter.ActionsAdapter;
import com.thirtydegreesray.openhub.ui.fragment.base.ListFragment;
import com.thirtydegreesray.openhub.util.ActionsHelper;
import com.thirtydegreesray.openhub.util.AppOpener;
import com.thirtydegreesray.openhub.util.BundleHelper;
import com.thirtydegreesray.openhub.util.StringUtils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Workflow run list of a repository with all GitHub Actions management features.
 */
public class ActionsFragment extends ListFragment<ActionsPresenter, ActionsAdapter>
        implements IActionsContract.View {

    /** GitHub needs a moment before a new run / a state change shows up in the list. */
    private static final long RELOAD_DELAY_MILLIS = 2000;

    /** values of the "status" query parameter, "" means all */
    private static final String[] STATUS_VALUES =
            {"", "success", "failure", "cancelled", "in_progress", "queued"};

    /** branch / tag field of the currently open "run workflow" dialog */
    private EditText pendingRefEdit;

    public static ActionsFragment create(String owner, String repo, String branch) {
        ActionsFragment fragment = new ActionsFragment();
        fragment.setArguments(BundleHelper.builder()
                .put("owner", owner)
                .put("repo", repo)
                .put("branch", branch).build());
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_list;
    }

    @Override
    protected void setupFragmentComponent(AppComponent appComponent) {
        DaggerFragmentComponent.builder()
                .appComponent(appComponent)
                .fragmentModule(new FragmentModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initFragment(Bundle savedInstanceState) {
        super.initFragment(savedInstanceState);
        setLoadMoreEnable(true);
        adapter.setOnRunMenuClickListener(new ActionsAdapter.OnRunMenuClickListener() {
            @Override
            public void onRunMenuClick(WorkflowRun run, View anchor) {
                showRunMenu(run, anchor);
            }
        });
    }

    @Override
    protected void onReLoadData() {
        mPresenter.loadRuns(1, true);
    }

    @Override
    protected String getEmptyTip() {
        return getString(R.string.no_workflow_runs);
    }

    @Override
    protected void onLoadMore(int page) {
        super.onLoadMore(page);
        mPresenter.loadRuns(page, false);
    }

    @Override
    public void showRuns(ArrayList<WorkflowRun> runs) {
        adapter.setData(runs);
        postNotifyDataSetChanged();
        updateFilterInfo();
    }

    @Override
    public void onItemClick(int position, @NonNull View view) {
        super.onItemClick(position, view);
        showRunOptionsDialog(adapter.getData().get(position));
    }

    // ------------------------------------------------------------------
    // toolbar actions (called by ActionsActivity)
    // ------------------------------------------------------------------

    public void onRunWorkflowClick() {
        mPresenter.loadWorkflows(IActionsContract.PURPOSE_RUN);
    }

    public void onFilterWorkflowClick() {
        mPresenter.loadWorkflows(IActionsContract.PURPOSE_FILTER);
    }

    public void onManageWorkflowsClick() {
        mPresenter.loadWorkflows(IActionsContract.PURPOSE_MANAGE);
    }

    public void onFilterStatusClick() {
        String[] labels = new String[STATUS_VALUES.length];
        int checked = 0;
        String current = mPresenter.getStatusFilter();
        for (int i = 0; i < STATUS_VALUES.length; i++) {
            labels[i] = getStatusLabel(STATUS_VALUES[i]);
            if (STATUS_VALUES[i].equals(current)) checked = i;
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.actions_filter_status)
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        mPresenter.setStatusFilter(STATUS_VALUES[which]);
                        onRefresh();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    // ------------------------------------------------------------------
    // workflow list dialogs
    // ------------------------------------------------------------------

    @Override
    public void showWorkflows(ArrayList<Workflow> workflows, int purpose) {
        if (workflows.isEmpty()) {
            showInfoToast(getString(R.string.actions_no_workflows));
            return;
        }
        switch (purpose) {
            case IActionsContract.PURPOSE_RUN:
                showRunChooser(workflows);
                break;
            case IActionsContract.PURPOSE_FILTER:
                showFilterChooser(workflows);
                break;
            case IActionsContract.PURPOSE_MANAGE:
                showManageChooser(workflows);
                break;
            default:
                break;
        }
    }

    /** Only active workflows can be triggered. */
    private void showRunChooser(ArrayList<Workflow> workflows) {
        final ArrayList<Workflow> active = new ArrayList<>();
        for (Workflow workflow : workflows) {
            if (workflow.isActive()) active.add(workflow);
        }
        if (active.isEmpty()) {
            showInfoToast(getString(R.string.actions_no_active_workflows));
            return;
        }
        String[] names = new String[active.size()];
        for (int i = 0; i < active.size(); i++) {
            names[i] = active.get(i).getDisplayName();
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.actions_select_workflow)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showRunWorkflowDialog(active.get(which));
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showFilterChooser(final ArrayList<Workflow> workflows) {
        String[] names = new String[workflows.size() + 1];
        names[0] = getString(R.string.actions_all_workflows);
        for (int i = 0; i < workflows.size(); i++) {
            names[i + 1] = workflows.get(i).getDisplayName();
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.actions_filter_workflow)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            mPresenter.setWorkflowFilter(null, null);
                        } else {
                            Workflow workflow = workflows.get(which - 1);
                            mPresenter.setWorkflowFilter(String.valueOf(workflow.getId()),
                                    workflow.getDisplayName());
                        }
                        onRefresh();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showManageChooser(final ArrayList<Workflow> workflows) {
        String[] names = new String[workflows.size()];
        for (int i = 0; i < workflows.size(); i++) {
            Workflow workflow = workflows.get(i);
            names[i] = workflow.getDisplayName() + " (" + getString(workflow.isActive()
                    ? R.string.actions_state_enabled : R.string.actions_state_disabled) + ")";
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.actions_manage_workflows)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        confirmToggleWorkflow(workflows.get(which));
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void confirmToggleWorkflow(final Workflow workflow) {
        final boolean enable = !workflow.isActive();
        showActionConfirm(
                getString(enable ? R.string.actions_enable_confirm : R.string.actions_disable_confirm,
                        workflow.getDisplayName()),
                getString(R.string.actions_manage_workflows),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mPresenter.setWorkflowEnabled(workflow, enable);
                    }
                });
    }

    // ------------------------------------------------------------------
    // run workflow dialog
    // ------------------------------------------------------------------

    private void showRunWorkflowDialog(final Workflow workflow) {
        View content = View.inflate(getActivity(), R.layout.dialog_run_workflow, null);
        TextView nameView = (TextView) content.findViewById(R.id.workflow_name);
        final EditText refEdit = (EditText) content.findViewById(R.id.ref_edit);
        final EditText inputsEdit = (EditText) content.findViewById(R.id.inputs_edit);
        Button chooseBn = (Button) content.findViewById(R.id.choose_ref_bn);

        nameView.setText(workflow.getDisplayName());
        String defaultBranch = mPresenter.getDefaultBranch();
        if (!StringUtils.isBlank(defaultBranch)) {
            refEdit.setText(defaultBranch);
            refEdit.setSelection(refEdit.getText().length());
        }
        chooseBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pendingRefEdit = refEdit;
                mPresenter.loadBranches();
            }
        });

        // positive button is wired after show(), so invalid input keeps the dialog open
        final AlertDialog dialog = new AlertDialog.Builder(getActivity())
                .setTitle(R.string.actions_run_workflow)
                .setView(content)
                .setPositiveButton(R.string.actions_run, null)
                .setNegativeButton(R.string.cancel, null)
                .show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ref = refEdit.getText().toString().trim();
                if (ref.length() == 0) {
                    refEdit.setError(getString(R.string.actions_ref_required));
                    return;
                }
                LinkedHashMap<String, String> inputs = new LinkedHashMap<>();
                String invalidLine = parseInputs(inputsEdit.getText().toString(), inputs);
                if (invalidLine != null) {
                    inputsEdit.setError(getString(R.string.actions_inputs_invalid, invalidLine));
                    return;
                }
                dialog.dismiss();
                mPresenter.dispatchWorkflow(workflow, ref, inputs);
            }
        });
    }

    /**
     * Parses "key=value" lines.
     *
     * @return the first invalid line, or null when all lines are valid
     */
    private String parseInputs(String text, Map<String, String> out) {
        String[] lines = text.split("\\r?\\n");
        for (String rawLine : lines) {
            String line = rawLine.trim();
            if (line.length() == 0) continue;
            int index = line.indexOf('=');
            if (index <= 0) return line;
            String key = line.substring(0, index).trim();
            if (key.length() == 0) return line;
            out.put(key, line.substring(index + 1).trim());
        }
        return null;
    }

    @Override
    public void showBranches(ArrayList<Branch> branches) {
        if (pendingRefEdit == null) return;
        if (branches.isEmpty()) {
            showInfoToast(getString(R.string.actions_no_branches));
            return;
        }
        final String[] names = new String[branches.size()];
        for (int i = 0; i < branches.size(); i++) {
            names[i] = branches.get(i).getName();
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.select_branch)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (pendingRefEdit != null) {
                            pendingRefEdit.setText(names[which]);
                            pendingRefEdit.setSelection(pendingRefEdit.getText().length());
                        }
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    // ------------------------------------------------------------------
    // run card: options dialog (tap) and three dot menu
    // ------------------------------------------------------------------

    /**
     * Tap on a run: small dialog with the two read-only options, jobs and artifacts.
     */
    private void showRunOptionsDialog(final WorkflowRun run) {
        View content = View.inflate(getActivity(), R.layout.dialog_run_options, null);
        ImageView statusIcon = (ImageView) content.findViewById(R.id.run_status_icon);
        TextView titleView = (TextView) content.findViewById(R.id.run_title);
        TextView subtitleView = (TextView) content.findViewById(R.id.run_subtitle);

        int kind = ActionsHelper.getKind(run.getStatus(), run.getConclusion());
        statusIcon.setImageResource(ActionsHelper.getIconRes(kind));
        statusIcon.setColorFilter(ActionsHelper.getColor(kind));
        titleView.setText(run.getTitle());
        StringBuilder subtitle = new StringBuilder();
        if (!StringUtils.isBlank(run.getName())) subtitle.append(run.getName()).append(' ');
        subtitle.append('#').append(run.getRunNumber())
                .append(" · ").append(getString(ActionsHelper.getTextRes(kind)));
        subtitleView.setText(subtitle.toString());

        final AlertDialog dialog = new AlertDialog.Builder(getActivity())
                .setView(content)
                .create();
        content.findViewById(R.id.option_jobs).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                mPresenter.loadJobs(run);
            }
        });
        content.findViewById(R.id.option_artifacts).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                mPresenter.loadArtifacts(run);
            }
        });
        dialog.show();
    }

    /**
     * Three dot button of a run card: cancel, re-run, delete, open in browser.
     */
    private void showRunMenu(final WorkflowRun run, View anchor) {
        PopupMenu popup = new PopupMenu(getActivity(), anchor);
        popup.inflate(R.menu.menu_workflow_run);
        Menu menu = popup.getMenu();
        menu.findItem(R.id.action_run_cancel).setVisible(run.isCancellable());
        menu.findItem(R.id.action_run_rerun).setVisible(run.isCompleted());
        menu.findItem(R.id.action_run_rerun_failed).setVisible(run.isFailed());
        menu.findItem(R.id.action_run_delete).setVisible(run.isCompleted());
        menu.findItem(R.id.action_run_browser).setVisible(!StringUtils.isBlank(run.getHtmlUrl()));
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_run_workflow_file:
                        WorkflowEditorActivity.show(getActivity(), mPresenter.getOwner(),
                                mPresenter.getRepoName(), String.valueOf(run.getWorkflowId()),
                                run.getName(), run.getHeadBranch(), mPresenter.getDefaultBranch());
                        return true;
                    case R.id.action_run_cancel:
                        confirmCancelRun(run);
                        return true;
                    case R.id.action_run_rerun:
                        mPresenter.rerunRun(run);
                        return true;
                    case R.id.action_run_rerun_failed:
                        mPresenter.rerunFailedJobs(run);
                        return true;
                    case R.id.action_run_delete:
                        confirmDeleteRun(run);
                        return true;
                    case R.id.action_run_browser:
                        AppOpener.openInCustomTabsOrBrowser(getActivity(), run.getHtmlUrl());
                        return true;
                    default:
                        return false;
                }
            }
        });
        popup.show();
    }

    private void confirmCancelRun(final WorkflowRun run) {
        showActionConfirm(getString(R.string.actions_cancel_confirm),
                getString(R.string.actions_cancel_run), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mPresenter.cancelRun(run);
                    }
                });
    }

    private void confirmDeleteRun(final WorkflowRun run) {
        showActionConfirm(getString(R.string.actions_delete_confirm),
                getString(R.string.actions_delete_run), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mPresenter.deleteRun(run);
                    }
                });
    }

    // ------------------------------------------------------------------
    // jobs, steps, logs
    // ------------------------------------------------------------------

    /**
     * A run with one job goes straight to its steps, several jobs need a pick first.
     */
    @Override
    public void showJobs(WorkflowRun run, final ArrayList<WorkflowJob> jobs) {
        if (jobs.isEmpty()) {
            showInfoToast(getString(R.string.actions_no_jobs));
            return;
        }
        if (jobs.size() == 1) {
            showSteps(jobs.get(0));
            return;
        }
        String[] items = new String[jobs.size()];
        for (int i = 0; i < jobs.size(); i++) {
            WorkflowJob job = jobs.get(i);
            StringBuilder item = new StringBuilder(job.getName() == null ? "" : job.getName());
            item.append(" · ").append(getStateText(job.getStatus(), job.getConclusion()));
            String duration = ActionsHelper.formatDuration(job.getDurationMillis());
            if (!StringUtils.isBlank(duration)) item.append(" · ").append(duration);
            items[i] = item.toString();
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(getString(R.string.actions_jobs_title) + " · " + run.getTitle())
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showSteps(jobs.get(which));
                    }
                })
                .setPositiveButton(R.string.ok, null)
                .show();
    }

    /**
     * Steps of one job. A tap on a step or on "open logs" shows the job log in the app.
     */
    private void showSteps(final WorkflowJob job) {
        ArrayList<WorkflowStep> steps = job.getSteps();
        if (steps == null || steps.isEmpty()) {
            openJobLog(job);
            return;
        }
        String[] items = new String[steps.size()];
        for (int i = 0; i < steps.size(); i++) {
            WorkflowStep step = steps.get(i);
            items[i] = step.getNumber() + ". " + (step.getName() == null ? "" : step.getName())
                    + " · " + getStateText(step.getStatus(), step.getConclusion());
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(job.getName())
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        openJobLog(job);
                    }
                })
                .setPositiveButton(R.string.ok, null)
                .setNeutralButton(R.string.actions_open_logs, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        openJobLog(job);
                    }
                })
                .show();
    }

    private void openJobLog(WorkflowJob job) {
        LogViewerActivity.show(getActivity(), mPresenter.getOwner(), mPresenter.getRepoName(),
                String.valueOf(job.getId()), job.getName(), job.getHtmlUrl());
    }

    // ------------------------------------------------------------------
    // artifacts
    // ------------------------------------------------------------------

    @Override
    public void showArtifacts(WorkflowRun run, final ArrayList<Artifact> artifacts) {
        if (artifacts.isEmpty()) {
            showInfoToast(getString(R.string.actions_no_artifacts));
            return;
        }
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.actions_artifacts)
                .setAdapter(new ArtifactListAdapter(getActivity(), artifacts),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Artifact artifact = artifacts.get(which);
                                if (artifact.isExpired()) {
                                    showWarningToast(getString(R.string.actions_artifact_expired_tip));
                                } else {
                                    mPresenter.downloadArtifact(artifact);
                                }
                            }
                        })
                .setPositiveButton(R.string.ok, null)
                .show();
    }

    @Override
    public void startArtifactDownload(String url, String fileName) {
        AppOpener.startDownload(getActivity(), url, fileName);
    }

    /** Artifact name on the left, size on the right. */
    private static class ArtifactListAdapter extends ArrayAdapter<Artifact> {

        ArtifactListAdapter(Context context, ArrayList<Artifact> artifacts) {
            super(context, 0, artifacts);
        }

        @NonNull
        @Override
        public View getView(int position, View convertView, @NonNull ViewGroup parent) {
            View view = convertView != null ? convertView : LayoutInflater.from(getContext())
                    .inflate(R.layout.layout_item_artifact, parent, false);
            Artifact artifact = getItem(position);
            TextView nameView = (TextView) view.findViewById(R.id.artifact_name);
            TextView sizeView = (TextView) view.findViewById(R.id.artifact_size);
            nameView.setText(artifact.getName());
            if (artifact.isExpired()) {
                sizeView.setText(R.string.actions_artifact_expired);
            } else {
                sizeView.setText(StringUtils.getSizeString(artifact.getSizeInBytes()));
            }
            view.setAlpha(artifact.isExpired() ? 0.5f : 1f);
            return view;
        }
    }

    @Override
    public void onActionFinished() {
        if (recyclerView == null) return;
        recyclerView.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isAdded()) onRefresh();
            }
        }, RELOAD_DELAY_MILLIS);
    }

    /**
     * Confirm dialog with localized buttons (BaseFragment.showConfirmDialog has a hard coded
     * Chinese cancel button).
     */
    private void showActionConfirm(String message, String title,
                                   DialogInterface.OnClickListener confirmListener) {
        new AlertDialog.Builder(getActivity())
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(R.string.confirm, confirmListener)
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    private String getStateText(String status, String conclusion) {
        return getString(ActionsHelper.getTextRes(ActionsHelper.getKind(status, conclusion)));
    }

    private String getStatusLabel(String statusValue) {
        if ("success".equals(statusValue)) return getString(R.string.actions_state_success);
        if ("failure".equals(statusValue)) return getString(R.string.actions_state_failure);
        if ("cancelled".equals(statusValue)) return getString(R.string.actions_state_cancelled);
        if ("in_progress".equals(statusValue)) return getString(R.string.actions_state_running);
        if ("queued".equals(statusValue)) return getString(R.string.actions_state_queued);
        return getString(R.string.actions_all_statuses);
    }

    /** Shows the active filters in the toolbar subtitle. */
    private void updateFilterInfo() {
        if (!(getActivity() instanceof ActionsActivity)) return;
        StringBuilder info = new StringBuilder();
        if (!StringUtils.isBlank(mPresenter.getWorkflowName())) {
            info.append(mPresenter.getWorkflowName());
        }
        String status = mPresenter.getStatusFilter();
        if (!StringUtils.isBlank(status)) {
            if (info.length() > 0) info.append(" · ");
            info.append(getStatusLabel(status));
        }
        ((ActionsActivity) getActivity()).updateSubtitle(info.toString());
    }

}
