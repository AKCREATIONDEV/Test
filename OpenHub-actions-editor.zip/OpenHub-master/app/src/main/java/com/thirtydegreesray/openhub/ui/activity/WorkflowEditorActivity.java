package com.thirtydegreesray.openhub.ui.activity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.Menu;
import android.view.MenuItem;

import com.thirtydegreesray.dataautoaccess.annotation.AutoAccess;
import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.mvp.contract.base.IBaseContract;
import com.thirtydegreesray.openhub.ui.activity.base.SingleFragmentActivity;
import com.thirtydegreesray.openhub.ui.fragment.WorkflowEditorFragment;
import com.thirtydegreesray.openhub.util.AppOpener;
import com.thirtydegreesray.openhub.util.BundleHelper;
import com.thirtydegreesray.openhub.util.StringUtils;

/**
 * Code editor for the workflow file (.github/workflows/*.yml) of a run. The commit icon in the
 * toolbar commits the changes to the branch the file was loaded from.
 */
public class WorkflowEditorActivity
        extends SingleFragmentActivity<IBaseContract.Presenter, WorkflowEditorFragment> {

    public static void show(Activity activity, String owner, String repo, String workflowId,
                            String workflowName, String branch, String defaultBranch) {
        Intent intent = new Intent(activity, WorkflowEditorActivity.class)
                .putExtras(BundleHelper.builder()
                        .put("owner", owner)
                        .put("repo", repo)
                        .put("workflowId", workflowId)
                        .put("workflowName", workflowName)
                        .put("branch", branch)
                        .put("defaultBranch", defaultBranch).build());
        activity.startActivity(intent);
    }

    @AutoAccess String owner;
    @AutoAccess String repo;
    @AutoAccess String workflowId;
    @AutoAccess String workflowName;
    @AutoAccess String branch;
    @AutoAccess String defaultBranch;

    @Override
    protected void initView(Bundle savedInstanceState) {
        super.initView(savedInstanceState);
        updateTitle(StringUtils.isBlank(workflowName) ? getString(R.string.actions_workflow_file)
                : workflowName, null);
        setToolbarScrollAble(true);
    }

    @Override
    protected WorkflowEditorFragment createFragment() {
        return WorkflowEditorFragment.create(owner, repo, workflowId, branch, defaultBranch);
    }

    /**
     * Title is the file name, subtitle "owner/repo" plus the branch once the file is loaded.
     */
    public void updateTitle(String fileName, String ref) {
        String subTitle = owner.concat("/").concat(repo);
        if (!StringUtils.isBlank(ref)) {
            subTitle = subTitle.concat(" · ").concat(ref);
        }
        setToolbarTitle(fileName, subTitle);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_workflow_editor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        WorkflowEditorFragment fragment = getFragment();
        switch (item.getItemId()) {
            case android.R.id.home:
                if (fragment != null && fragment.hasChanges()) {
                    confirmDiscard();
                    return true;
                }
                break;
            case R.id.action_editor_commit:
                if (fragment != null) fragment.onCommitClick();
                return true;
            case R.id.action_editor_reload:
                if (fragment != null) fragment.onReloadClick();
                return true;
            case R.id.action_editor_browser:
                if (fragment != null && !StringUtils.isBlank(fragment.getBrowserUrl())) {
                    AppOpener.openInCustomTabsOrBrowser(getActivity(), fragment.getBrowserUrl());
                }
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        WorkflowEditorFragment fragment = getFragment();
        if (fragment != null && fragment.hasChanges()) {
            confirmDiscard();
        } else {
            super.onBackPressed();
        }
    }

    private void confirmDiscard() {
        new AlertDialog.Builder(this)
                .setMessage(R.string.actions_discard_confirm)
                .setPositiveButton(R.string.actions_discard, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

}
