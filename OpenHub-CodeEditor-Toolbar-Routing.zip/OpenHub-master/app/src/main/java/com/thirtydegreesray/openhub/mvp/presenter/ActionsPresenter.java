package com.thirtydegreesray.openhub.mvp.presenter;

import com.thirtydegreesray.dataautoaccess.annotation.AutoAccess;
import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.dao.DaoSession;
import com.thirtydegreesray.openhub.http.core.HttpObserver;
import com.thirtydegreesray.openhub.http.core.HttpResponse;
import com.thirtydegreesray.openhub.http.core.HttpSubscriber;
import com.thirtydegreesray.openhub.mvp.contract.IActionsContract;
import com.thirtydegreesray.openhub.mvp.model.Branch;
import com.thirtydegreesray.openhub.mvp.model.Workflow;
import com.thirtydegreesray.openhub.mvp.model.WorkflowArtifact;
import com.thirtydegreesray.openhub.mvp.model.WorkflowArtifactsResponse;
import com.thirtydegreesray.openhub.mvp.model.WorkflowDispatchRequest;
import com.thirtydegreesray.openhub.mvp.model.WorkflowJob;
import com.thirtydegreesray.openhub.mvp.model.WorkflowStep;
import com.thirtydegreesray.openhub.mvp.model.WorkflowJobsResponse;
import com.thirtydegreesray.openhub.mvp.model.WorkflowRun;
import com.thirtydegreesray.openhub.mvp.model.WorkflowRunsResponse;
import com.thirtydegreesray.openhub.mvp.model.WorkflowsResponse;
import com.thirtydegreesray.openhub.mvp.presenter.base.BasePresenter;
import com.thirtydegreesray.openhub.util.StringUtils;

import org.json.JSONObject;

import java.util.ArrayList;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.Map;

import javax.inject.Inject;

import okhttp3.ResponseBody;
import retrofit2.Response;
import rx.Observable;
import rx.functions.Func1;

/**
 * Presenter of the GitHub Actions screen: lists workflow runs and manages
 * workflows (run, cancel, re-run, delete, enable / disable).
 */
public class ActionsPresenter extends BasePresenter<IActionsContract.View>
        implements IActionsContract.Presenter {

    private static final int RUNS_PER_PAGE = 30;
    private static final int LIST_PER_PAGE = 100;

    @AutoAccess String owner;
    @AutoAccess String repo;
    /** default branch of the repository, pre-filled when running a workflow */
    @AutoAccess String branch;
    /** workflow filter, blank means all workflows */
    @AutoAccess String workflowId;
    @AutoAccess String workflowName;
    /** status filter (success, failure, in_progress...), blank means all */
    @AutoAccess String statusFilter;

    private ArrayList<WorkflowRun> runs;

    @Inject
    public ActionsPresenter(DaoSession daoSession) {
        super(daoSession);
    }

    @Override
    public void onViewInitialized() {
        super.onViewInitialized();
        if (runs == null) {
            loadRuns(1, false);
        } else {
            mView.showRuns(runs);
            mView.hideLoading();
        }
    }

    @Override
    public void loadRuns(final int page, final boolean isReload) {
        mView.showLoading();
        final HttpObserver<WorkflowRunsResponse> httpObserver =
                new HttpObserver<WorkflowRunsResponse>() {
                    @Override
                    public void onError(Throwable error) {
                        mView.hideLoading();
                        if (page == 1) {
                            mView.showLoadError(getErrorTip(error));
                        } else {
                            mView.showErrorToast(getErrorTip(error));
                        }
                    }

                    @Override
                    public void onSuccess(HttpResponse<WorkflowRunsResponse> response) {
                        mView.hideLoading();
                        WorkflowRunsResponse result = response.body();
                        ArrayList<WorkflowRun> body = (result == null || result.getWorkflowRuns() == null)
                                ? new ArrayList<WorkflowRun>() : result.getWorkflowRuns();
                        if (isReload || runs == null || page == 1) {
                            runs = body;
                        } else {
                            runs.addAll(body);
                        }
                        if (body.size() == 0 && runs.size() != 0) {
                            mView.setCanLoadMore(false);
                        } else {
                            mView.showRuns(runs);
                        }
                    }
                };
        generalRxHttpExecute(new IObservableCreator<WorkflowRunsResponse>() {
            @Override
            public Observable<Response<WorkflowRunsResponse>> createObservable(boolean forceNetWork) {
                // run states change quickly, always ask the network
                if (StringUtils.isBlank(workflowId)) {
                    return getRepoService().getWorkflowRuns(true, owner, repo, page,
                            RUNS_PER_PAGE, getStatusParam());
                } else {
                    return getRepoService().getWorkflowRunsByWorkflow(true, owner, repo,
                            workflowId, page, RUNS_PER_PAGE, getStatusParam());
                }
            }
        }, httpObserver);
    }

    @Override
    public void loadWorkflows(final int purpose) {
        mView.showProgressDialog(getLoadTip());
        final HttpObserver<WorkflowsResponse> httpObserver = new HttpObserver<WorkflowsResponse>() {
            @Override
            public void onError(Throwable error) {
                mView.dismissProgressDialog();
                mView.showErrorToast(getErrorTip(error));
            }

            @Override
            public void onSuccess(HttpResponse<WorkflowsResponse> response) {
                mView.dismissProgressDialog();
                WorkflowsResponse result = response.body();
                ArrayList<Workflow> list = new ArrayList<>();
                if (result != null && result.getWorkflows() != null) {
                    for (Workflow workflow : result.getWorkflows()) {
                        if (!workflow.isDeleted()) list.add(workflow);
                    }
                }
                mView.showWorkflows(list, purpose);
            }
        };
        generalRxHttpExecute(new IObservableCreator<WorkflowsResponse>() {
            @Override
            public Observable<Response<WorkflowsResponse>> createObservable(boolean forceNetWork) {
                return getRepoService().getWorkflows(true, owner, repo, LIST_PER_PAGE);
            }
        }, httpObserver);
    }

    @Override
    public void loadBranches() {
        mView.showProgressDialog(getLoadTip());
        final HttpObserver<ArrayList<Branch>> httpObserver = new HttpObserver<ArrayList<Branch>>() {
            @Override
            public void onError(Throwable error) {
                mView.dismissProgressDialog();
                mView.showErrorToast(getErrorTip(error));
            }

            @Override
            public void onSuccess(HttpResponse<ArrayList<Branch>> response) {
                mView.dismissProgressDialog();
                ArrayList<Branch> list = response.body() == null
                        ? new ArrayList<Branch>() : response.body();
                mView.showBranches(list);
            }
        };
        generalRxHttpExecute(new IObservableCreator<ArrayList<Branch>>() {
            @Override
            public Observable<Response<ArrayList<Branch>>> createObservable(boolean forceNetWork) {
                return getRepoService().getBranches(owner, repo, LIST_PER_PAGE);
            }
        }, httpObserver);
    }

    @Override
    public void loadJobs(final WorkflowRun run) {
        mView.showProgressDialog(getLoadTip());
        final HttpObserver<WorkflowJobsResponse> httpObserver =
                new HttpObserver<WorkflowJobsResponse>() {
                    @Override
                    public void onError(Throwable error) {
                        mView.dismissProgressDialog();
                        mView.showErrorToast(getErrorTip(error));
                    }

                    @Override
                    public void onSuccess(HttpResponse<WorkflowJobsResponse> response) {
                        mView.dismissProgressDialog();
                        WorkflowJobsResponse result = response.body();
                        ArrayList<WorkflowJob> list = (result == null || result.getJobs() == null)
                                ? new ArrayList<WorkflowJob>() : result.getJobs();
                        mView.showJobs(run, list);
                    }
                };
        generalRxHttpExecute(new IObservableCreator<WorkflowJobsResponse>() {
            @Override
            public Observable<Response<WorkflowJobsResponse>> createObservable(boolean forceNetWork) {
                return getRepoService().getWorkflowRunJobs(true, owner, repo, run.getId(),
                        LIST_PER_PAGE);
            }
        }, httpObserver);
    }

    @Override
    public void loadJobLogs(final WorkflowJob job) {
        loadJobLogs(job, null);
    }

    @Override
    public void loadJobLogs(final WorkflowJob job, final WorkflowStep step) {
        mView.showProgressDialog(getLoadTip());
        // GitHub's job-logs endpoint normally returns a ZIP archive. Read and
        // extract it on Rx's IO thread, never pass a live ResponseBody to the UI.
        Observable<Response<String>> download = getRepoService()
                .getWorkflowJobLogs(owner, repo, job.getId())
                .map(new Func1<Response<ResponseBody>, Response<String>>() {
                    @Override
                    public Response<String> call(Response<ResponseBody> response) {
                        if (!response.isSuccessful()) {
                            throw new RuntimeException("GitHub could not provide job logs (HTTP "
                                    + response.code() + ")");
                        }
                        ResponseBody body = response.body();
                        if (body == null) throw new RuntimeException("GitHub returned an empty job log archive.");
                        try {
                            return Response.success(decodeJobLogArchive(body.bytes(), step));
                        } catch (IOException e) {
                            throw new RuntimeException("Could not read job logs: " + e.getMessage(), e);
                        } finally {
                            body.close();
                        }
                    }
                });

        HttpObserver<String> observer = new HttpObserver<String>() {
            @Override public void onError(Throwable error) {
                mView.dismissProgressDialog();
                mView.showErrorToast(getErrorTip(error));
            }
            @Override public void onSuccess(HttpResponse<String> response) {
                mView.dismissProgressDialog();
                if (response.isSuccessful() && response.body() != null) {
                    mView.showJobLogs(job, step, response.body());
                } else {
                    mView.showErrorToast("GitHub returned no job logs.");
                }
            }
        };
        generalRxHttpExecute(new IObservableCreator<String>() {
            @Override public Observable<Response<String>> createObservable(boolean forceNetWork) {
                return download;
            }
        }, observer);
    }

    /**
     * Extract GitHub's job-log ZIP. GitHub exposes logs per job, not a separate
     * REST endpoint per step. The ZIP normally contains one text file per step;
     * when a step was selected, return only its matching archive entry.
     */
    private String decodeJobLogArchive(byte[] bytes, WorkflowStep selectedStep) throws IOException {
        if (bytes == null || bytes.length == 0) return "";
        boolean zip = bytes.length >= 4 && bytes[0] == 'P' && bytes[1] == 'K';
        if (!zip) {
            String raw = new String(bytes, "UTF-8");
            if (selectedStep != null) {
                return "GitHub returned a single combined job log; individual step logs are not separable.\\n\\n" + raw;
            }
            return raw;
        }

        ZipInputStream input = new ZipInputStream(new ByteArrayInputStream(bytes));
        ByteArrayOutputStream allOutput = new ByteArrayOutputStream();
        ByteArrayOutputStream selectedOutput = new ByteArrayOutputStream();
        boolean foundText = false;
        boolean foundSelected = false;
        try {
            ZipEntry entry;
            byte[] buffer = new byte[8192];
            while ((entry = input.getNextEntry()) != null) {
                if (!entry.isDirectory()) {
                    String entryName = entry.getName() == null ? "" : entry.getName();
                    String lower = entryName.toLowerCase(java.util.Locale.US);
                    if (lower.endsWith(".txt") || lower.endsWith(".log") || lower.length() == 0) {
                        ByteArrayOutputStream current = new ByteArrayOutputStream();
                        int count;
                        while ((count = input.read(buffer)) != -1) current.write(buffer, 0, count);
                        byte[] content = current.toByteArray();
                        if (content.length > 0) {
                            foundText = true;
                            allOutput.write(("\\n===== " + entryName + " =====\\n").getBytes("UTF-8"));
                            allOutput.write(content);
                            allOutput.write('\n');
                            if (selectedStep != null && matchesStepLog(entryName, selectedStep)) {
                                selectedOutput.write(("\\n===== " + entryName + " =====\\n").getBytes("UTF-8"));
                                selectedOutput.write(content);
                                selectedOutput.write('\n');
                                foundSelected = true;
                            }
                        }
                        current.close();
                    }
                }
                input.closeEntry();
            }
            if (!foundText) throw new IOException("The GitHub log ZIP contains no readable text log.");
            if (selectedStep != null) {
                if (foundSelected) return new String(selectedOutput.toByteArray(), "UTF-8");
                return "GitHub did not provide a separately identifiable log file for step "
                        + selectedStep.getNumber() + " (" + selectedStep.getName()
                        + "). Showing the complete job log instead.\\n"
                        + new String(allOutput.toByteArray(), "UTF-8");
            }
            return new String(allOutput.toByteArray(), "UTF-8");
        } finally {
            input.close();
            allOutput.close();
            selectedOutput.close();
        }
    }

    private boolean matchesStepLog(String entryName, WorkflowStep step) {
        if (step == null || entryName == null) return false;
        String base = entryName;
        int slash = Math.max(base.lastIndexOf('/'), base.lastIndexOf('\\\\'));
        if (slash >= 0) base = base.substring(slash + 1);
        String lower = base.toLowerCase(java.util.Locale.US);
        String number = String.valueOf(step.getNumber());
        if (lower.matches("^0*" + java.util.regex.Pattern.quote(number) + "[_ .-].*")) return true;
        String normalizedEntry = lower.replaceAll("[^a-z0-9]", "");
        String normalizedStep = step.getName() == null ? "" :
                step.getName().toLowerCase(java.util.Locale.US).replaceAll("[^a-z0-9]", "");
        return normalizedStep.length() > 0 && normalizedEntry.contains(normalizedStep);
    }

    @Override
    public void loadArtifacts(final WorkflowRun run) {
        mView.showProgressDialog(getLoadTip());
        HttpObserver<WorkflowArtifactsResponse> observer = new HttpObserver<WorkflowArtifactsResponse>() {
            @Override public void onError(Throwable error) { mView.dismissProgressDialog(); mView.showErrorToast(getErrorTip(error)); }
            @Override public void onSuccess(HttpResponse<WorkflowArtifactsResponse> response) {
                mView.dismissProgressDialog();
                WorkflowArtifactsResponse result = response.body();
                ArrayList<WorkflowArtifact> list = result == null || result.getArtifacts() == null ? new ArrayList<WorkflowArtifact>() : result.getArtifacts();
                mView.showArtifacts(run, list);
            }
        };
        generalRxHttpExecute(new IObservableCreator<WorkflowArtifactsResponse>() {
            @Override public Observable<Response<WorkflowArtifactsResponse>> createObservable(boolean forceNetWork) {
                return getRepoService().getWorkflowRunArtifacts(true, owner, repo, run.getId(), LIST_PER_PAGE);
            }
        }, observer);
    }

    @Override
    public void downloadArtifact(final WorkflowArtifact artifact) {
        mView.showProgressDialog("Downloading " + artifact.getName() + "...");
        // Read the streaming response on Rx's IO thread. Passing ResponseBody to an
        // AsyncTask lets Retrofit/Rx close the socket before the task reads it.
        Observable<Response<byte[]>> download = getRepoService()
                .downloadWorkflowArtifact(owner, repo, artifact.getId())
                .map(new Func1<Response<ResponseBody>, Response<byte[]>>() {
                    @Override
                    public Response<byte[]> call(Response<ResponseBody> response) {
                        if (!response.isSuccessful()) {
                            throw new RuntimeException("Artifact download failed (HTTP "
                                    + response.code() + ")");
                        }
                        ResponseBody body = response.body();
                        if (body == null) {
                            throw new RuntimeException("GitHub returned an empty artifact archive.");
                        }
                        try {
                            return Response.success(body.bytes());
                        } catch (IOException e) {
                            throw new RuntimeException("Could not read artifact download: " + e.getMessage(), e);
                        } finally {
                            body.close();
                        }
                    }
                });
        HttpObserver<byte[]> observer = new HttpObserver<byte[]>() {
            @Override public void onError(Throwable error) {
                mView.dismissProgressDialog();
                mView.showErrorToast(getErrorTip(error));
            }
            @Override public void onSuccess(HttpResponse<byte[]> response) {
                mView.dismissProgressDialog();
                if (response.isSuccessful() && response.body() != null) {
                    mView.onArtifactDownloaded(artifact, response.body());
                } else {
                    mView.showErrorToast("Artifact download returned no data.");
                }
            }
        };
        generalRxHttpExecute(new IObservableCreator<byte[]>() {
            @Override
            public Observable<Response<byte[]>> createObservable(boolean forceNetWork) {
                return download;
            }
        }, observer);
    }

    @Override
    public void dispatchWorkflow(Workflow workflow, String ref, Map<String, String> inputs) {
        executeAction(getRepoService().dispatchWorkflow(owner, repo,
                String.valueOf(workflow.getId()), new WorkflowDispatchRequest(ref, inputs)),
                getString(R.string.actions_dispatching), getString(R.string.actions_dispatched));
    }

    @Override
    public void cancelRun(WorkflowRun run) {
        executeAction(getRepoService().cancelWorkflowRun(owner, repo, run.getId()),
                getString(R.string.actions_please_wait), getString(R.string.actions_cancel_requested));
    }

    @Override
    public void rerunRun(WorkflowRun run) {
        executeAction(getRepoService().rerunWorkflowRun(owner, repo, run.getId()),
                getString(R.string.actions_please_wait), getString(R.string.actions_rerun_started));
    }

    @Override
    public void rerunFailedJobs(WorkflowRun run) {
        executeAction(getRepoService().rerunFailedJobs(owner, repo, run.getId()),
                getString(R.string.actions_please_wait), getString(R.string.actions_rerun_started));
    }

    @Override
    public void deleteRun(WorkflowRun run) {
        executeAction(getRepoService().deleteWorkflowRun(owner, repo, run.getId()),
                getString(R.string.actions_please_wait), getString(R.string.actions_deleted));
    }

    @Override
    public void setWorkflowEnabled(Workflow workflow, boolean enabled) {
        String id = String.valueOf(workflow.getId());
        if (enabled) {
            executeAction(getRepoService().enableWorkflow(owner, repo, id),
                    getString(R.string.actions_please_wait),
                    getString(R.string.actions_workflow_enabled));
        } else {
            executeAction(getRepoService().disableWorkflow(owner, repo, id),
                    getString(R.string.actions_please_wait),
                    getString(R.string.actions_workflow_disabled));
        }
    }

    /**
     * Executes a request without response body (POST / PUT / DELETE actions).
     * Failure messages from GitHub (e.g. "Workflow does not have 'workflow_dispatch' trigger")
     * are shown as they are, because they explain what is wrong.
     */
    private void executeAction(Observable<Response<ResponseBody>> observable,
                               String progressTip, final String successTip) {
        mView.showProgressDialog(progressTip);
        HttpSubscriber<ResponseBody> subscriber = new HttpSubscriber<>(
                new HttpObserver<ResponseBody>() {
                    @Override
                    public void onError(Throwable error) {
                        mView.dismissProgressDialog();
                        mView.showErrorToast(getErrorTip(error));
                    }

                    @Override
                    public void onSuccess(HttpResponse<ResponseBody> response) {
                        mView.dismissProgressDialog();
                        if (response.isSuccessful()) {
                            mView.showSuccessToast(successTip);
                            mView.onActionFinished();
                        } else {
                            mView.showErrorToast(getFailureMessage(response.getOriResponse()));
                        }
                    }
                });
        generalRxHttpExecute(observable, subscriber);
    }

    /**
     * Builds "code: message" using GitHub's JSON error body when present.
     */
    private String getFailureMessage(Response<ResponseBody> response) {
        String message = null;
        try {
            if (response.errorBody() != null) {
                String raw = response.errorBody().string();
                message = new JSONObject(raw).optString("message", null);
            }
        } catch (Exception ignored) {
            // body is not JSON, fall back to the HTTP status message
        }
        if (StringUtils.isBlank(message)) {
            message = response.message();
        }
        return StringUtils.isBlank(message) ? String.valueOf(response.code())
                : response.code() + ": " + message;
    }

    private String getStatusParam() {
        return StringUtils.isBlank(statusFilter) ? null : statusFilter;
    }

    public void setWorkflowFilter(String workflowId, String workflowName) {
        this.workflowId = workflowId;
        this.workflowName = workflowName;
        this.runs = null;
    }

    public void setStatusFilter(String statusFilter) {
        this.statusFilter = statusFilter;
        this.runs = null;
    }

    public String getOwner() {
        return owner;
    }

    public String getRepoName() {
        return repo;
    }

    public String getDefaultBranch() {
        return branch;
    }

    public String getWorkflowName() {
        return workflowName;
    }

    public String getStatusFilter() {
        return statusFilter;
    }

}
