# OpenHub dependency baseline (2026-11-20)

This project remains Java + XML + MVP. The update migrates Android Support Library imports to AndroidX and updates the core build/dependency baseline. Dependencies are intentionally limited to features already used by the source tree; Sora Editor, Room, WorkManager, Paging, Compose, and extra logging/network modules are not added without an implementation need.

## Build platform

- Android Gradle Plugin: 8.13.2 (latest selected 8.x baseline; AGP 9.x is newer but deferred for AndroidIDE compatibility)
- Gradle wrapper: 8.13
- JDK: 17
- compileSdk: 36
- targetSdk: 36
- minSdk: 24 (Android 7.0+; required to use the current AndroidX baseline)

## Direct dependencies

| Group | Artifact | Version | Reason |
|---|---|---:|---|
| AndroidX | core | 1.19.1 | Core compatibility utilities |
| AndroidX | appcompat | 1.8.0 | AppCompat activities/widgets |
| AndroidX | activity | 1.14.0 | Activity integration |
| AndroidX | fragment | 1.9.1 | Fragment APIs |
| AndroidX | recyclerview | 1.4.0 | Existing lists/adapters |
| AndroidX | constraintlayout | 2.2.1 | Existing XML layouts |
| AndroidX | annotation | 1.11.0 | Nullability/resource annotations |
| AndroidX | coordinatorlayout | 1.3.0 | Existing CoordinatorLayout XML containers |
| AndroidX | cardview | 1.0.0 | Existing card widgets |
| AndroidX | drawerlayout | 1.2.0 | Navigation drawer |
| AndroidX | viewpager | 1.1.0 | Existing pager screens |
| AndroidX | swiperefreshlayout | 1.2.0 | Existing pull-to-refresh |
| AndroidX | browser | 1.9.0 | Custom Tabs |
| AndroidX | preference | 1.2.1 | Settings preferences |
| Google | Material Components | 1.13.0 | Existing Material widgets |
| Square | Retrofit | 3.0.0 | GitHub REST API and legacy RxJava 1 adapter |
| Square | OkHttp | 4.12.0 | Shared HTTP client; Retrofit 3.0.0 dependency baseline |
| Google | Gson | 2.13.2 | JSON models |
| Bumptech | Glide | 5.0.9 | Existing image loading |
| Jsoup | jsoup | 1.21.2 | Existing trending/topic HTML parsing |
| Greenrobot | greenDAO | 3.3.0 | Existing generated DAO database |
| Greenrobot | EventBus | 3.3.1 | Existing event bus |
| ReactiveX | RxJava | 1.3.8 | Existing RxJava 1 source API |
| ReactiveX | RxAndroid | 1.2.1 | Existing Android scheduler integration |
| Dagger | dagger | 2.60.1 | Existing dependency injection |
| Jake Wharton | ButterKnife | 10.2.3 | Existing view binding annotations |
| Rosemoe | Sora Editor | Not added | Current workflow editor is not migrated; pre-release editor should not be injected as an unused dependency |

Unused `glideimagegetter` was removed because there is no source usage. Material Dialogs were also removed because no source/layout usage was found.

### Retained feature-specific helpers

| Library | Version | Why it remains |
|---|---:|---|
| DataAutoAccess | 1.2.8 | Used by activity/fragment saved-state fields |
| RxPermissions | 0.9.4 | Used by the download permission flow; Jetifier bridges its legacy support types |
| CircleImageView | 3.1.0 | Used by existing profile/avatar layouts |
| Toasty | 1.5.2 | Used by download, login and common feedback flows |
| Material About Library | 2.2.1 | Used by the existing About screen |
| SubmitButton | 1.1.2 | Used by login layouts |
| RichText | 2.5.4 | Used by Markdown preview |
| Logger | 2.2.0 | Used by app diagnostics and exception logging |
| StickyHeadersRecyclerView | 0.4.3 | Used by trace/history list headers |

Simple XML is pulled by Retrofit's `converter-simplexml` because existing feed models use it. The unused `glideimagegetter` and Material Dialogs dependencies were removed after source/layout searches found no call sites. These remaining helpers are retained for compatibility, not because they are the newest libraries.

## Notes

- Exact dependency resolution and a full Android build must run in CI. This workspace did not have Gradle/Android SDK installed, so this source update is not represented as a verified successful APK build.
- AndroidX release versions move independently; re-check the official release notes before the next release.
