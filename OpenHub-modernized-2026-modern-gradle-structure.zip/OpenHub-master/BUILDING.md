# Building OpenHub

## Requirements
- JDK 17
- Android SDK Platform 36 and Build Tools 36.0.0
- Gradle wrapper (included)

## Local build
1. Copy `local.properties.example` to `local.properties`.
2. Set the Android SDK path in `local.properties` (`sdk.dir=...`) and fill only the OAuth values you have configured.
3. Run `./gradlew :app:assembleNormalDebug :app:assembleFullNameDebug`.
4. APKs are under `app/build/outputs/apk/`.

The debug build uses the standard debug key. Release builds are unsigned unless `sign_path`, `store_password`, `key_alias`, and `key_password` are supplied in `local.properties` or their matching environment variables are configured.

## AndroidIDE
Open the `OpenHub-master` directory as the project root. Set JDK 17 and install SDK Platform 36 / Build Tools 36.0.0. First sync may take time because AndroidX and updated Maven dependencies must download.

## GitHub Actions secrets

For configured CI builds, add repository Actions secrets named `OPENHUB_CLIENT_ID`, `OPENHUB_CLIENT_SECRET`, `BUGLY_APP_ID`, and `DEBUG_BUGLY_APP_ID`. Do not store a production OAuth client secret in a public APK; the client-side value is extractable and should be replaced by a backend OAuth exchange.
