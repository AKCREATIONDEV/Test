package com.thirtydegreesray.openhub.mvp.model;

import com.google.gson.annotations.SerializedName;

/**
 * The commit created by a contents API update.
 */
public class CommitRef {

    private String sha;
    @SerializedName("html_url") private String htmlUrl;

    public String getSha() {
        return sha;
    }

    public String getHtmlUrl() {
        return htmlUrl;
    }

}
