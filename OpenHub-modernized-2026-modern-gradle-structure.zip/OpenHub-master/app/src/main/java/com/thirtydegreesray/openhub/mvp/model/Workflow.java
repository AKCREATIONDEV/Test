package com.thirtydegreesray.openhub.mvp.model;

import com.google.gson.annotations.SerializedName;

/**
 * A GitHub Actions workflow (a .yml file under .github/workflows).
 */
public class Workflow {

    private long id;
    private String name;
    private String path;
    private String state;
    @SerializedName("html_url") private String htmlUrl;

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPath() {
        return path;
    }

    public String getState() {
        return state;
    }

    public String getHtmlUrl() {
        return htmlUrl;
    }

    public boolean isActive() {
        return "active".equals(state);
    }

    public boolean isDeleted() {
        return "deleted".equals(state);
    }

    /**
     * Name for UI lists, falls back to the file path.
     */
    public String getDisplayName() {
        if (name != null && name.trim().length() > 0) return name;
        return path == null ? String.valueOf(id) : path;
    }

}
