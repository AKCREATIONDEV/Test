package com.thirtydegreesray.openhub.mvp.model;

/**
 * A step of a workflow job.
 */
public class WorkflowStep {

    private String name;
    private String status;
    private String conclusion;
    private int number;

    public String getName() {
        return name;
    }

    public String getStatus() {
        return status;
    }

    public String getConclusion() {
        return conclusion;
    }

    public int getNumber() {
        return number;
    }

}
