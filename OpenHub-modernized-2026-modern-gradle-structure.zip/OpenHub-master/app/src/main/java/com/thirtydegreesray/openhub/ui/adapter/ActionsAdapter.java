package com.thirtydegreesray.openhub.ui.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.mvp.model.WorkflowRun;
import com.thirtydegreesray.openhub.ui.adapter.base.BaseAdapter;
import com.thirtydegreesray.openhub.ui.adapter.base.BaseViewHolder;
import com.thirtydegreesray.openhub.ui.fragment.base.BaseFragment;
import com.thirtydegreesray.openhub.util.ActionsHelper;
import com.thirtydegreesray.openhub.util.StringUtils;

import javax.inject.Inject;

import butterknife.BindView;

/**
 * Adapter of the workflow run list.
 */
public class ActionsAdapter extends BaseAdapter<ActionsAdapter.ViewHolder, WorkflowRun> {

    /**
     * Listener of the three dot button of a run card.
     */
    public interface OnRunMenuClickListener {
        void onRunMenuClick(WorkflowRun run, View anchor);
    }

    private OnRunMenuClickListener onRunMenuClickListener;

    @Inject
    public ActionsAdapter(Context context, BaseFragment fragment) {
        super(context, fragment);
    }

    public void setOnRunMenuClickListener(OnRunMenuClickListener listener) {
        this.onRunMenuClickListener = listener;
    }

    @Override
    protected int getLayoutId(int viewType) {
        return R.layout.layout_item_workflow_run;
    }

    @Override
    protected ViewHolder getViewHolder(View itemView, int viewType) {
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        super.onBindViewHolder(holder, position);
        WorkflowRun run = data.get(position);

        int kind = ActionsHelper.getKind(run.getStatus(), run.getConclusion());
        int color = ActionsHelper.getColor(kind);
        holder.statusIcon.setImageResource(ActionsHelper.getIconRes(kind));
        holder.statusIcon.setColorFilter(color);

        holder.title.setText(run.getTitle());

        StringBuilder workflow = new StringBuilder();
        if (!StringUtils.isBlank(run.getName())) {
            workflow.append(run.getName()).append(" ");
        }
        workflow.append("#").append(run.getRunNumber());
        if (run.getRunAttempt() > 1) {
            workflow.append(" (")
                    .append(context.getString(R.string.actions_run_attempt, run.getRunAttempt()))
                    .append(")");
        }
        holder.workflow.setText(workflow.toString());

        StringBuilder meta = new StringBuilder();
        appendMeta(meta, run.getEvent());
        appendMeta(meta, run.getHeadBranch());
        if (run.getActor() != null) {
            appendMeta(meta, run.getActor().getLogin());
        }
        holder.meta.setText(meta.toString());

        StringBuilder state = new StringBuilder(context.getString(ActionsHelper.getTextRes(kind)));
        if (run.isCompleted()) {
            String duration = ActionsHelper.formatDuration(run.getDurationMillis());
            if (!StringUtils.isBlank(duration)) {
                state.append(" · ").append(duration);
            }
        }
        holder.state.setText(state.toString());
        holder.state.setTextColor(color);

        holder.moreBn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPosition = holder.getAdapterPosition();
                if (onRunMenuClickListener != null && adapterPosition != RecyclerView.NO_POSITION
                        && adapterPosition < data.size()) {
                    onRunMenuClickListener.onRunMenuClick(data.get(adapterPosition), v);
                }
            }
        });

        if (run.getDisplayDate() != null) {
            holder.time.setText(StringUtils.getNewsTimeStr(context, run.getDisplayDate()));
        } else {
            holder.time.setText("");
        }
    }

    private void appendMeta(StringBuilder builder, String value) {
        if (StringUtils.isBlank(value)) return;
        if (builder.length() > 0) builder.append(" · ");
        builder.append(value);
    }

    class ViewHolder extends BaseViewHolder {

        @BindView(R.id.status_icon) ImageView statusIcon;
        @BindView(R.id.title) TextView title;
        @BindView(R.id.workflow) TextView workflow;
        @BindView(R.id.meta) TextView meta;
        @BindView(R.id.state) TextView state;
        @BindView(R.id.time) TextView time;
        @BindView(R.id.more_bn) ImageView moreBn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

}
