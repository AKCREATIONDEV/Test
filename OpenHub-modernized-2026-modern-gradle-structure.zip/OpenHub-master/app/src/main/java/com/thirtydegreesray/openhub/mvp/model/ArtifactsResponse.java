package com.thirtydegreesray.openhub.mvp.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Response of "list workflow run artifacts".
 */
public class ArtifactsResponse {

    @SerializedName("total_count") private int totalCount;
    private ArrayList<Artifact> artifacts;

    public int getTotalCount() {
        return totalCount;
    }

    public ArrayList<Artifact> getArtifacts() {
        return artifacts;
    }

}
