package com.thirtydegreesray.openhub.mvp.model;

/**
 * Response of "create or update file contents".
 */
public class UpdateFileResponse {

    private RepoContent content;
    private CommitRef commit;

    public RepoContent getContent() {
        return content;
    }

    public CommitRef getCommit() {
        return commit;
    }

}
