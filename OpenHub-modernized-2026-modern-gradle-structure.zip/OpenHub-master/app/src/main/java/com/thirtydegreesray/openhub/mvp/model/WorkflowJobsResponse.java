package com.thirtydegreesray.openhub.mvp.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Response of "list jobs for a workflow run".
 */
public class WorkflowJobsResponse {

    @SerializedName("total_count") private int totalCount;
    private ArrayList<WorkflowJob> jobs;

    public int getTotalCount() {
        return totalCount;
    }

    public ArrayList<WorkflowJob> getJobs() {
        return jobs;
    }

}
