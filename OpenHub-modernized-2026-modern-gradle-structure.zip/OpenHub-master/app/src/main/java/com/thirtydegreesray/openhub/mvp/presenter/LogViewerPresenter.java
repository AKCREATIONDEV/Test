package com.thirtydegreesray.openhub.mvp.presenter;

import com.thirtydegreesray.dataautoaccess.annotation.AutoAccess;
import com.thirtydegreesray.openhub.AppConfig;
import com.thirtydegreesray.openhub.dao.DaoSession;
import com.thirtydegreesray.openhub.http.core.HttpObserver;
import com.thirtydegreesray.openhub.http.core.HttpResponse;
import com.thirtydegreesray.openhub.http.core.HttpSubscriber;
import com.thirtydegreesray.openhub.mvp.contract.ILogViewerContract;
import com.thirtydegreesray.openhub.mvp.presenter.base.BasePresenter;
import com.thirtydegreesray.openhub.util.ActionsFileHelper;

import javax.inject.Inject;

import retrofit2.Response;
import rx.Observable;
import rx.Subscriber;

/**
 * Loads the log of one workflow job.
 */
public class LogViewerPresenter extends BasePresenter<ILogViewerContract.View>
        implements ILogViewerContract.Presenter {

    /** only the end of bigger logs is shown, the WebView gets slow beyond this */
    private static final int MAX_LOG_BYTES = 2 * 1024 * 1024;

    @AutoAccess String owner;
    @AutoAccess String repo;
    @AutoAccess String jobId;

    private ActionsFileHelper.TextResult result;

    @Inject
    public LogViewerPresenter(DaoSession daoSession) {
        super(daoSession);
    }

    @Override
    public void onViewInitialized() {
        super.onViewInitialized();
        loadLog(false);
    }

    @Override
    public void loadLog(boolean forceReload) {
        if (result != null && !forceReload) {
            mView.showLog(result.text, result.truncated);
            return;
        }
        mView.showLoading();
        // makes sure the access token is registered for the api host
        getRepoService();
        final String apiUrl = AppConfig.GITHUB_API_BASE_URL + "repos/" + owner + "/" + repo
                + "/actions/jobs/" + jobId + "/logs";
        Observable<Response<ActionsFileHelper.TextResult>> observable = Observable.create(
                new Observable.OnSubscribe<Response<ActionsFileHelper.TextResult>>() {
                    @Override
                    public void call(Subscriber<? super Response<ActionsFileHelper.TextResult>> subscriber) {
                        try {
                            String location = ActionsFileHelper.resolveRedirectUrl(apiUrl);
                            subscriber.onNext(Response.success(
                                    ActionsFileHelper.loadText(location, MAX_LOG_BYTES)));
                            subscriber.onCompleted();
                        } catch (Exception e) {
                            subscriber.onError(e);
                        }
                    }
                });
        generalRxHttpExecute(observable, new HttpSubscriber<>(
                new HttpObserver<ActionsFileHelper.TextResult>() {
                    @Override
                    public void onError(Throwable error) {
                        mView.hideLoading();
                        mView.showLoadError(getErrorTip(error));
                    }

                    @Override
                    public void onSuccess(HttpResponse<ActionsFileHelper.TextResult> response) {
                        mView.hideLoading();
                        result = response.body();
                        mView.showLog(result.text, result.truncated);
                    }
                }));
    }

    public String getOwner() {
        return owner;
    }

    public String getRepoName() {
        return repo;
    }

    public String getJobId() {
        return jobId;
    }

}
