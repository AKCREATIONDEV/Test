package com.thirtydegreesray.openhub.mvp.presenter;

import com.thirtydegreesray.dataautoaccess.annotation.AutoAccess;
import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.dao.DaoSession;
import com.thirtydegreesray.openhub.http.core.HttpObserver;
import com.thirtydegreesray.openhub.http.core.HttpResponse;
import com.thirtydegreesray.openhub.http.core.HttpSubscriber;
import com.thirtydegreesray.openhub.mvp.contract.IActionsContract;
import com.thirtydegreesray.openhub.mvp.model.Artifact;
import com.thirtydegreesray.openhub.mvp.model.ArtifactsResponse;
import com.thirtydegreesray.openhub.mvp.model.Branch;
import com.thirtydegreesray.openhub.mvp.model.Workflow;
import com.thirtydegreesray.openhub.mvp.model.WorkflowDispatchRequest;
import com.thirtydegreesray.openhub.mvp.model.WorkflowJob;
import com.thirtydegreesray.openhub.mvp.model.WorkflowJobsResponse;
import com.thirtydegreesray.openhub.mvp.model.WorkflowRun;
import com.thirtydegreesray.openhub.mvp.model.WorkflowRunsResponse;
import com.thirtydegreesray.openhub.mvp.model.WorkflowsResponse;
import com.thirtydegreesray.openhub.mvp.presenter.base.BasePresenter;
import com.thirtydegreesray.openhub.AppConfig;
import com.thirtydegreesray.openhub.util.ActionsFileHelper;
import com.thirtydegreesray.openhub.util.StringUtils;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

import javax.inject.Inject;

import okhttp3.ResponseBody;
import retrofit2.Response;
import rx.Observable;
import rx.Subscriber;

/**
 * Presenter of the GitHub Actions screen: lists workflow runs and manages
 * workflows (run, cancel, re-run, delete, enable / disable).
 */
public class ActionsPresenter extends BasePresenter<IActionsContract.View>
        implements IActionsContract.Presenter {

    private static final int RUNS_PER_PAGE = 30;
    private static final int LIST_PER_PAGE = 100;

    @AutoAccess String owner;
    @AutoAccess String repo;
    /** default branch of the repository, pre-filled when running a workflow */
    @AutoAccess String branch;
    /** workflow filter, blank means all workflows */
    @AutoAccess String workflowId;
    @AutoAccess String workflowName;
    /** status filter (success, failure, in_progress...), blank means all */
    @AutoAccess String statusFilter;

    private ArrayList<WorkflowRun> runs;

    @Inject
    public ActionsPresenter(DaoSession daoSession) {
        super(daoSession);
    }

    @Override
    public void onViewInitialized() {
        super.onViewInitialized();
        if (runs == null) {
            loadRuns(1, false);
        } else {
            mView.showRuns(runs);
            mView.hideLoading();
        }
    }

    @Override
    public void loadRuns(final int page, final boolean isReload) {
        mView.showLoading();
        final HttpObserver<WorkflowRunsResponse> httpObserver =
                new HttpObserver<WorkflowRunsResponse>() {
                    @Override
                    public void onError(Throwable error) {
                        mView.hideLoading();
                        if (page == 1) {
                            mView.showLoadError(getErrorTip(error));
                        } else {
                            mView.showErrorToast(getErrorTip(error));
                        }
                    }

                    @Override
                    public void onSuccess(HttpResponse<WorkflowRunsResponse> response) {
                        mView.hideLoading();
                        WorkflowRunsResponse result = response.body();
                        ArrayList<WorkflowRun> body = (result == null || result.getWorkflowRuns() == null)
                                ? new ArrayList<WorkflowRun>() : result.getWorkflowRuns();
                        if (isReload || runs == null || page == 1) {
                            runs = body;
                        } else {
                            runs.addAll(body);
                        }
                        if (body.size() == 0 && runs.size() != 0) {
                            mView.setCanLoadMore(false);
                        } else {
                            mView.showRuns(runs);
                        }
                    }
                };
        generalRxHttpExecute(new IObservableCreator<WorkflowRunsResponse>() {
            @Override
            public Observable<Response<WorkflowRunsResponse>> createObservable(boolean forceNetWork) {
                // run states change quickly, always ask the network
                if (StringUtils.isBlank(workflowId)) {
                    return getRepoService().getWorkflowRuns(true, owner, repo, page,
                            RUNS_PER_PAGE, getStatusParam());
                } else {
                    return getRepoService().getWorkflowRunsByWorkflow(true, owner, repo,
                            workflowId, page, RUNS_PER_PAGE, getStatusParam());
                }
            }
        }, httpObserver);
    }

    @Override
    public void loadWorkflows(final int purpose) {
        mView.showProgressDialog(getLoadTip());
        final HttpObserver<WorkflowsResponse> httpObserver = new HttpObserver<WorkflowsResponse>() {
            @Override
            public void onError(Throwable error) {
                mView.dismissProgressDialog();
                mView.showErrorToast(getErrorTip(error));
            }

            @Override
            public void onSuccess(HttpResponse<WorkflowsResponse> response) {
                mView.dismissProgressDialog();
                WorkflowsResponse result = response.body();
                ArrayList<Workflow> list = new ArrayList<>();
                if (result != null && result.getWorkflows() != null) {
                    for (Workflow workflow : result.getWorkflows()) {
                        if (!workflow.isDeleted()) list.add(workflow);
                    }
                }
                mView.showWorkflows(list, purpose);
            }
        };
        generalRxHttpExecute(new IObservableCreator<WorkflowsResponse>() {
            @Override
            public Observable<Response<WorkflowsResponse>> createObservable(boolean forceNetWork) {
                return getRepoService().getWorkflows(true, owner, repo, LIST_PER_PAGE);
            }
        }, httpObserver);
    }

    @Override
    public void loadBranches() {
        mView.showProgressDialog(getLoadTip());
        final HttpObserver<ArrayList<Branch>> httpObserver = new HttpObserver<ArrayList<Branch>>() {
            @Override
            public void onError(Throwable error) {
                mView.dismissProgressDialog();
                mView.showErrorToast(getErrorTip(error));
            }

            @Override
            public void onSuccess(HttpResponse<ArrayList<Branch>> response) {
                mView.dismissProgressDialog();
                ArrayList<Branch> list = response.body() == null
                        ? new ArrayList<Branch>() : response.body();
                mView.showBranches(list);
            }
        };
        generalRxHttpExecute(new IObservableCreator<ArrayList<Branch>>() {
            @Override
            public Observable<Response<ArrayList<Branch>>> createObservable(boolean forceNetWork) {
                return getRepoService().getBranches(owner, repo, LIST_PER_PAGE);
            }
        }, httpObserver);
    }

    @Override
    public void loadJobs(final WorkflowRun run) {
        mView.showProgressDialog(getLoadTip());
        final HttpObserver<WorkflowJobsResponse> httpObserver =
                new HttpObserver<WorkflowJobsResponse>() {
                    @Override
                    public void onError(Throwable error) {
                        mView.dismissProgressDialog();
                        mView.showErrorToast(getErrorTip(error));
                    }

                    @Override
                    public void onSuccess(HttpResponse<WorkflowJobsResponse> response) {
                        mView.dismissProgressDialog();
                        WorkflowJobsResponse result = response.body();
                        ArrayList<WorkflowJob> list = (result == null || result.getJobs() == null)
                                ? new ArrayList<WorkflowJob>() : result.getJobs();
                        mView.showJobs(run, list);
                    }
                };
        generalRxHttpExecute(new IObservableCreator<WorkflowJobsResponse>() {
            @Override
            public Observable<Response<WorkflowJobsResponse>> createObservable(boolean forceNetWork) {
                return getRepoService().getWorkflowRunJobs(true, owner, repo, run.getId(),
                        LIST_PER_PAGE);
            }
        }, httpObserver);
    }

    @Override
    public void loadArtifacts(final WorkflowRun run) {
        mView.showProgressDialog(getLoadTip());
        final HttpObserver<ArtifactsResponse> httpObserver = new HttpObserver<ArtifactsResponse>() {
            @Override
            public void onError(Throwable error) {
                mView.dismissProgressDialog();
                mView.showErrorToast(getErrorTip(error));
            }

            @Override
            public void onSuccess(HttpResponse<ArtifactsResponse> response) {
                mView.dismissProgressDialog();
                ArtifactsResponse result = response.body();
                ArrayList<Artifact> list = (result == null || result.getArtifacts() == null)
                        ? new ArrayList<Artifact>() : result.getArtifacts();
                mView.showArtifacts(run, list);
            }
        };
        generalRxHttpExecute(new IObservableCreator<ArtifactsResponse>() {
            @Override
            public Observable<Response<ArtifactsResponse>> createObservable(boolean forceNetWork) {
                return getRepoService().getWorkflowRunArtifacts(true, owner, repo, run.getId(),
                        LIST_PER_PAGE);
            }
        }, httpObserver);
    }

    /**
     * Resolves the short lived pre-signed archive url (GitHub answers the api call with a
     * redirect) and hands it to the view, which starts the download.
     */
    @Override
    public void downloadArtifact(final Artifact artifact) {
        mView.showProgressDialog(getString(R.string.actions_preparing_download));
        // makes sure the access token is registered for the api host
        getRepoService();
        final String apiUrl = AppConfig.GITHUB_API_BASE_URL + "repos/" + owner + "/" + repo
                + "/actions/artifacts/" + artifact.getId() + "/zip";
        Observable<Response<String>> observable = Observable.create(
                new Observable.OnSubscribe<Response<String>>() {
                    @Override
                    public void call(Subscriber<? super Response<String>> subscriber) {
                        try {
                            subscriber.onNext(Response.success(
                                    ActionsFileHelper.resolveRedirectUrl(apiUrl)));
                            subscriber.onCompleted();
                        } catch (Exception e) {
                            subscriber.onError(e);
                        }
                    }
                });
        generalRxHttpExecute(observable, new HttpSubscriber<>(new HttpObserver<String>() {
            @Override
            public void onError(Throwable error) {
                mView.dismissProgressDialog();
                mView.showErrorToast(getErrorTip(error));
            }

            @Override
            public void onSuccess(HttpResponse<String> response) {
                mView.dismissProgressDialog();
                mView.startArtifactDownload(response.body(), artifact.getFileName());
            }
        }));
    }

    @Override
    public void dispatchWorkflow(Workflow workflow, String ref, Map<String, String> inputs) {
        executeAction(getRepoService().dispatchWorkflow(owner, repo,
                String.valueOf(workflow.getId()), new WorkflowDispatchRequest(ref, inputs)),
                getString(R.string.actions_dispatching), getString(R.string.actions_dispatched));
    }

    @Override
    public void cancelRun(WorkflowRun run) {
        executeAction(getRepoService().cancelWorkflowRun(owner, repo, run.getId()),
                getString(R.string.actions_please_wait), getString(R.string.actions_cancel_requested));
    }

    @Override
    public void rerunRun(WorkflowRun run) {
        executeAction(getRepoService().rerunWorkflowRun(owner, repo, run.getId()),
                getString(R.string.actions_please_wait), getString(R.string.actions_rerun_started));
    }

    @Override
    public void rerunFailedJobs(WorkflowRun run) {
        executeAction(getRepoService().rerunFailedJobs(owner, repo, run.getId()),
                getString(R.string.actions_please_wait), getString(R.string.actions_rerun_started));
    }

    @Override
    public void deleteRun(WorkflowRun run) {
        executeAction(getRepoService().deleteWorkflowRun(owner, repo, run.getId()),
                getString(R.string.actions_please_wait), getString(R.string.actions_deleted));
    }

    @Override
    public void setWorkflowEnabled(Workflow workflow, boolean enabled) {
        String id = String.valueOf(workflow.getId());
        if (enabled) {
            executeAction(getRepoService().enableWorkflow(owner, repo, id),
                    getString(R.string.actions_please_wait),
                    getString(R.string.actions_workflow_enabled));
        } else {
            executeAction(getRepoService().disableWorkflow(owner, repo, id),
                    getString(R.string.actions_please_wait),
                    getString(R.string.actions_workflow_disabled));
        }
    }

    /**
     * Executes a request without response body (POST / PUT / DELETE actions).
     * Failure messages from GitHub (e.g. "Workflow does not have 'workflow_dispatch' trigger")
     * are shown as they are, because they explain what is wrong.
     */
    private void executeAction(Observable<Response<ResponseBody>> observable,
                               String progressTip, final String successTip) {
        mView.showProgressDialog(progressTip);
        HttpSubscriber<ResponseBody> subscriber = new HttpSubscriber<>(
                new HttpObserver<ResponseBody>() {
                    @Override
                    public void onError(Throwable error) {
                        mView.dismissProgressDialog();
                        mView.showErrorToast(getErrorTip(error));
                    }

                    @Override
                    public void onSuccess(HttpResponse<ResponseBody> response) {
                        mView.dismissProgressDialog();
                        if (response.isSuccessful()) {
                            mView.showSuccessToast(successTip);
                            mView.onActionFinished();
                        } else {
                            mView.showErrorToast(getFailureMessage(response.getOriResponse()));
                        }
                    }
                });
        generalRxHttpExecute(observable, subscriber);
    }

    /**
     * Builds "code: message" using GitHub's JSON error body when present.
     */
    private String getFailureMessage(Response<ResponseBody> response) {
        String message = null;
        try {
            if (response.errorBody() != null) {
                String raw = response.errorBody().string();
                message = new JSONObject(raw).optString("message", null);
            }
        } catch (Exception ignored) {
            // body is not JSON, fall back to the HTTP status message
        }
        if (StringUtils.isBlank(message)) {
            message = response.message();
        }
        return StringUtils.isBlank(message) ? String.valueOf(response.code())
                : response.code() + ": " + message;
    }

    private String getStatusParam() {
        return StringUtils.isBlank(statusFilter) ? null : statusFilter;
    }

    public void setWorkflowFilter(String workflowId, String workflowName) {
        this.workflowId = workflowId;
        this.workflowName = workflowName;
        this.runs = null;
    }

    public void setStatusFilter(String statusFilter) {
        this.statusFilter = statusFilter;
        this.runs = null;
    }

    public String getOwner() {
        return owner;
    }

    public String getRepoName() {
        return repo;
    }

    public String getDefaultBranch() {
        return branch;
    }

    public String getWorkflowName() {
        return workflowName;
    }

    public String getStatusFilter() {
        return statusFilter;
    }

}
