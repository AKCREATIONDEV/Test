package com.thirtydegreesray.openhub.mvp.contract;

import com.thirtydegreesray.openhub.mvp.contract.base.IBaseContract;
import com.thirtydegreesray.openhub.mvp.model.Artifact;
import com.thirtydegreesray.openhub.mvp.model.Branch;
import com.thirtydegreesray.openhub.mvp.model.Workflow;
import com.thirtydegreesray.openhub.mvp.model.WorkflowJob;
import com.thirtydegreesray.openhub.mvp.model.WorkflowRun;

import java.util.ArrayList;
import java.util.Map;

/**
 * Contract of the GitHub Actions screen.
 */
public interface IActionsContract {

    /** Workflow list is loaded to pick the workflow to run. */
    int PURPOSE_RUN = 1;
    /** Workflow list is loaded to filter the run list. */
    int PURPOSE_FILTER = 2;
    /** Workflow list is loaded to enable / disable a workflow. */
    int PURPOSE_MANAGE = 3;

    interface View extends IBaseContract.View {
        void showRuns(ArrayList<WorkflowRun> runs);

        void setCanLoadMore(boolean canLoadMore);

        void showLoadError(String error);

        void showWorkflows(ArrayList<Workflow> workflows, int purpose);

        void showBranches(ArrayList<Branch> branches);

        void showJobs(WorkflowRun run, ArrayList<WorkflowJob> jobs);

        void showArtifacts(WorkflowRun run, ArrayList<Artifact> artifacts);

        /**
         * The pre-signed archive url is ready, the download can start.
         */
        void startArtifactDownload(String url, String fileName);

        /**
         * An action (run / cancel / re-run / delete / enable / disable) succeeded,
         * the run list should be refreshed.
         */
        void onActionFinished();
    }

    interface Presenter extends IBaseContract.Presenter<IActionsContract.View> {
        void loadRuns(int page, boolean isReload);

        void loadWorkflows(int purpose);

        void loadBranches();

        void loadJobs(WorkflowRun run);

        void loadArtifacts(WorkflowRun run);

        void downloadArtifact(Artifact artifact);

        void dispatchWorkflow(Workflow workflow, String ref, Map<String, String> inputs);

        void cancelRun(WorkflowRun run);

        void rerunRun(WorkflowRun run);

        void rerunFailedJobs(WorkflowRun run);

        void deleteRun(WorkflowRun run);

        void setWorkflowEnabled(Workflow workflow, boolean enabled);
    }

}
