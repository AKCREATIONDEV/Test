package com.thirtydegreesray.openhub.mvp.presenter;

import android.util.Base64;

import com.thirtydegreesray.dataautoaccess.annotation.AutoAccess;
import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.dao.DaoSession;
import com.thirtydegreesray.openhub.http.core.HttpObserver;
import com.thirtydegreesray.openhub.http.core.HttpResponse;
import com.thirtydegreesray.openhub.http.core.HttpSubscriber;
import com.thirtydegreesray.openhub.mvp.contract.IWorkflowEditorContract;
import com.thirtydegreesray.openhub.mvp.model.RepoContent;
import com.thirtydegreesray.openhub.mvp.model.UpdateFileRequest;
import com.thirtydegreesray.openhub.mvp.model.UpdateFileResponse;
import com.thirtydegreesray.openhub.mvp.model.Workflow;
import com.thirtydegreesray.openhub.mvp.presenter.base.BasePresenter;
import com.thirtydegreesray.openhub.util.ActionsFileHelper;
import com.thirtydegreesray.openhub.util.StringUtils;

import java.nio.charset.Charset;

import javax.inject.Inject;

import retrofit2.Response;
import rx.Observable;

/**
 * Loads the workflow file (.github/workflows/*.yml) of a run and commits changes to it.
 */
public class WorkflowEditorPresenter extends BasePresenter<IWorkflowEditorContract.View>
        implements IWorkflowEditorContract.Presenter {

    private static final Charset UTF_8 = Charset.forName("UTF-8");

    @AutoAccess String owner;
    @AutoAccess String repo;
    @AutoAccess String workflowId;
    /** head branch of the run, the file is read from here first */
    @AutoAccess String branch;
    @AutoAccess String defaultBranch;

    private String filePath;
    /** blob sha of the loaded file, GitHub needs it to accept an update */
    private String fileSha;
    /** branch the file was loaded from, the commit goes here */
    private String loadedRef;
    /** the file used Windows line endings, they are written back on commit */
    private boolean crlf;

    @Inject
    public WorkflowEditorPresenter(DaoSession daoSession) {
        super(daoSession);
    }

    @Override
    public void onViewInitialized() {
        super.onViewInitialized();
        loadFile();
    }

    @Override
    public void loadFile() {
        mView.showLoading();
        generalRxHttpExecute(new IObservableCreator<Workflow>() {
            @Override
            public Observable<Response<Workflow>> createObservable(boolean forceNetWork) {
                return getRepoService().getWorkflow(true, owner, repo, workflowId);
            }
        }, new HttpObserver<Workflow>() {
            @Override
            public void onError(Throwable error) {
                mView.hideLoading();
                mView.showLoadError(getErrorTip(error));
            }

            @Override
            public void onSuccess(HttpResponse<Workflow> response) {
                Workflow workflow = response.body();
                if (workflow == null || StringUtils.isBlank(workflow.getPath())) {
                    mView.hideLoading();
                    mView.showLoadError(getString(R.string.actions_file_unsupported));
                    return;
                }
                filePath = workflow.getPath();
                loadContent(getFirstRef(), true);
            }
        });
    }

    private String getFirstRef() {
        if (!StringUtils.isBlank(branch)) return branch;
        return StringUtils.isBlank(defaultBranch) ? null : defaultBranch;
    }

    /**
     * @param allowFallback retry on the default branch when the run's branch has no such file
     *                      (deleted branch, tag, pull request from a fork)
     */
    private void loadContent(final String ref, final boolean allowFallback) {
        generalRxHttpExecute(new IObservableCreator<RepoContent>() {
            @Override
            public Observable<Response<RepoContent>> createObservable(boolean forceNetWork) {
                // the sha must be the latest one, never read it from the cache
                return getRepoService().getContentFile(true, owner, repo, filePath, ref);
            }
        }, new HttpObserver<RepoContent>() {
            @Override
            public void onError(Throwable error) {
                if (allowFallback && !StringUtils.isBlank(defaultBranch)
                        && !defaultBranch.equals(ref)) {
                    loadContent(defaultBranch, false);
                    return;
                }
                mView.hideLoading();
                mView.showLoadError(getErrorTip(error));
            }

            @Override
            public void onSuccess(HttpResponse<RepoContent> response) {
                mView.hideLoading();
                RepoContent content = response.body();
                if (content == null || content.getContent() == null
                        || !"base64".equals(content.getEncoding())) {
                    mView.showLoadError(getString(R.string.actions_file_unsupported));
                    return;
                }
                try {
                    String raw = new String(Base64.decode(content.getContent(), Base64.DEFAULT), UTF_8);
                    crlf = raw.contains("\r\n");
                    fileSha = content.getSha();
                    loadedRef = ref;
                    mView.showFile(crlf ? raw.replace("\r\n", "\n") : raw, filePath, ref);
                } catch (IllegalArgumentException e) {
                    mView.showLoadError(getString(R.string.actions_file_unsupported));
                }
            }
        });
    }

    @Override
    public void commit(String text, String message) {
        String finalText = crlf ? text.replace("\n", "\r\n") : text;
        String encoded = Base64.encodeToString(finalText.getBytes(UTF_8), Base64.NO_WRAP);
        UpdateFileRequest body = new UpdateFileRequest(message, encoded, fileSha, loadedRef);

        mView.showProgressDialog(getString(R.string.actions_committing));
        generalRxHttpExecute(getRepoService().updateFile(owner, repo, filePath, body),
                new HttpSubscriber<>(new HttpObserver<UpdateFileResponse>() {
                    @Override
                    public void onError(Throwable error) {
                        mView.dismissProgressDialog();
                        mView.showErrorToast(getErrorTip(error));
                    }

                    @Override
                    public void onSuccess(HttpResponse<UpdateFileResponse> response) {
                        mView.dismissProgressDialog();
                        if (!response.isSuccessful()) {
                            mView.showErrorToast(getCommitFailureMessage(response.getOriResponse()));
                            return;
                        }
                        UpdateFileResponse result = response.body();
                        if (result != null && result.getContent() != null
                                && !StringUtils.isBlank(result.getContent().getSha())) {
                            // the next commit must replace the file we just wrote
                            fileSha = result.getContent().getSha();
                            mView.onCommitted();
                        } else {
                            mView.onCommitted();
                            loadFile();
                        }
                    }
                }));
    }

    /**
     * GitHub refuses workflow file changes for tokens without the "workflow" scope
     * (tokens created before this scope was requested), tell the user how to fix it.
     */
    private String getCommitFailureMessage(Response<?> response) {
        String message = ActionsFileHelper.getFailureMessage(response);
        String lower = message.toLowerCase();
        if (lower.contains("workflow") && lower.contains("scope")) {
            return getString(R.string.actions_commit_need_scope);
        }
        return message;
    }

    public String getOwner() {
        return owner;
    }

    public String getRepoName() {
        return repo;
    }

}
