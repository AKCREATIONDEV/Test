package com.thirtydegreesray.openhub.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.thirtydegreesray.dataautoaccess.annotation.AutoAccess;
import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.mvp.contract.base.IBaseContract;
import com.thirtydegreesray.openhub.ui.activity.base.SingleFragmentActivity;
import com.thirtydegreesray.openhub.ui.fragment.LogViewerFragment;
import com.thirtydegreesray.openhub.util.AppOpener;
import com.thirtydegreesray.openhub.util.BundleHelper;
import com.thirtydegreesray.openhub.util.StringUtils;

/**
 * Shows the log of one GitHub Actions job inside the app.
 */
public class LogViewerActivity extends SingleFragmentActivity<IBaseContract.Presenter, LogViewerFragment> {

    public static void show(Activity activity, String owner, String repo, String jobId,
                            String jobName, String jobUrl) {
        Intent intent = new Intent(activity, LogViewerActivity.class)
                .putExtras(BundleHelper.builder()
                        .put("owner", owner)
                        .put("repo", repo)
                        .put("jobId", jobId)
                        .put("jobName", jobName)
                        .put("jobUrl", jobUrl).build());
        activity.startActivity(intent);
    }

    @AutoAccess String owner;
    @AutoAccess String repo;
    @AutoAccess String jobId;
    @AutoAccess String jobName;
    @AutoAccess String jobUrl;

    @Override
    protected void initView(Bundle savedInstanceState) {
        super.initView(savedInstanceState);
        String title = StringUtils.isBlank(jobName) ? getString(R.string.actions_logs) : jobName;
        setToolbarTitle(title, owner.concat("/").concat(repo));
        setToolbarScrollAble(true);
    }

    @Override
    protected LogViewerFragment createFragment() {
        return LogViewerFragment.create(owner, repo, jobId);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_log_viewer, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem wrapItem = menu.findItem(R.id.action_log_wrap);
        if (wrapItem != null && getFragment() != null) {
            wrapItem.setChecked(getFragment().isWrap());
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        LogViewerFragment fragment = getFragment();
        switch (item.getItemId()) {
            case R.id.action_log_bottom:
                if (fragment != null) fragment.goToBottom();
                return true;
            case R.id.action_log_top:
                if (fragment != null) fragment.goToTop();
                return true;
            case R.id.action_log_wrap:
                if (fragment != null) {
                    fragment.setWrap(!item.isChecked());
                    item.setChecked(fragment.isWrap());
                }
                return true;
            case R.id.action_log_refresh:
                if (fragment != null) fragment.reload();
                return true;
            case R.id.action_log_browser:
                if (!StringUtils.isBlank(jobUrl)) {
                    AppOpener.openInCustomTabsOrBrowser(getActivity(), jobUrl);
                }
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
