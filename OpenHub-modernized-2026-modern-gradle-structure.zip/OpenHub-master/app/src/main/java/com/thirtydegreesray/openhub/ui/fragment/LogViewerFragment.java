package com.thirtydegreesray.openhub.ui.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.inject.component.AppComponent;
import com.thirtydegreesray.openhub.inject.component.DaggerFragmentComponent;
import com.thirtydegreesray.openhub.inject.module.FragmentModule;
import com.thirtydegreesray.openhub.mvp.contract.ILogViewerContract;
import com.thirtydegreesray.openhub.mvp.presenter.LogViewerPresenter;
import com.thirtydegreesray.openhub.ui.fragment.base.BaseFragment;
import com.thirtydegreesray.openhub.ui.widget.webview.CodeWebView;
import com.thirtydegreesray.openhub.util.BundleHelper;
import com.thirtydegreesray.openhub.util.PrefUtils;
import com.thirtydegreesray.openhub.util.StringUtils;

import butterknife.BindView;

/**
 * Log of one workflow job in a code like view: monospace, line numbers, errors in red.
 */
public class LogViewerFragment extends BaseFragment<LogViewerPresenter>
        implements ILogViewerContract.View, CodeWebView.ContentChangedListener {

    @BindView(R.id.web_view) CodeWebView webView;
    @BindView(R.id.loader) ProgressBar loader;

    private boolean wrap;
    private String currentLog;
    private boolean truncated;

    public static LogViewerFragment create(String owner, String repo, String jobId) {
        LogViewerFragment fragment = new LogViewerFragment();
        fragment.setArguments(BundleHelper.builder()
                .put("owner", owner)
                .put("repo", repo)
                .put("jobId", jobId).build());
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_viewer;
    }

    @Override
    protected void setupFragmentComponent(AppComponent appComponent) {
        DaggerFragmentComponent.builder()
                .appComponent(appComponent)
                .fragmentModule(new FragmentModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initFragment(Bundle savedInstanceState) {
        wrap = PrefUtils.isCodeWrap();
        loader.setVisibility(View.VISIBLE);
        loader.setIndeterminate(true);
    }

    @Override
    public void showLog(String log, boolean truncated) {
        this.currentLog = log;
        this.truncated = truncated;
        render();
    }

    @Override
    public void showLoadError(String error) {
        this.currentLog = null;
        loader.setVisibility(View.GONE);
        webView.setLogSource(StringUtils.isBlank(error) ? getString(R.string.actions_log_empty) : error,
                true, null);
    }

    private void render() {
        if (currentLog == null) return;
        String source = StringUtils.isBlank(currentLog)
                ? getString(R.string.actions_log_empty) : currentLog;
        String notice = truncated ? getString(R.string.actions_log_truncated) : null;
        webView.setLogSource(source, wrap, notice);
        webView.setContentChangedListener(this);
        loader.setVisibility(View.VISIBLE);
        loader.setIndeterminate(false);
    }

    // ------------------------------------------------------------------
    // toolbar actions (called by LogViewerActivity)
    // ------------------------------------------------------------------

    public boolean isWrap() {
        return wrap;
    }

    public void setWrap(boolean wrap) {
        this.wrap = wrap;
        PrefUtils.set(PrefUtils.CODE_WRAP, wrap);
        render();
    }

    public void goToBottom() {
        if (webView != null) webView.pageDown(true);
    }

    public void goToTop() {
        if (webView != null) webView.pageUp(true);
    }

    public void reload() {
        mPresenter.loadLog(true);
    }

    @Override
    public void showLoading() {
        super.showLoading();
        if (loader == null) return;
        loader.setVisibility(View.VISIBLE);
        loader.setIndeterminate(true);
    }

    @Override
    public void hideLoading() {
        super.hideLoading();
        if (loader != null) loader.setVisibility(View.GONE);
    }

    @Override
    public void onContentChanged(int progress) {
        if (loader == null) return;
        loader.setProgress(progress);
        if (progress == 100) {
            loader.setVisibility(View.GONE);
        }
    }

    @Override
    public void onScrollChanged(boolean reachedTop, int scroll) {
    }

}
