package com.thirtydegreesray.openhub.mvp.model;

import com.google.gson.annotations.SerializedName;

import java.util.Date;

/**
 * An artifact uploaded by a workflow run (a zip archive).
 */
public class Artifact {

    private long id;
    private String name;
    @SerializedName("size_in_bytes") private long sizeInBytes;
    private boolean expired;
    @SerializedName("created_at") private Date createdAt;
    @SerializedName("expires_at") private Date expiresAt;

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public long getSizeInBytes() {
        return sizeInBytes;
    }

    public boolean isExpired() {
        return expired;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Date getExpiresAt() {
        return expiresAt;
    }

    /**
     * Artifacts are always downloaded as zip archives.
     */
    public String getFileName() {
        String base = (name == null || name.trim().length() == 0) ? "artifact-" + id : name;
        return base.endsWith(".zip") ? base : base + ".zip";
    }

}
