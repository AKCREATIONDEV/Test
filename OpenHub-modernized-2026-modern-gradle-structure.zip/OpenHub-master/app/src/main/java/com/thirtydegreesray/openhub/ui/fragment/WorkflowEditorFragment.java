package com.thirtydegreesray.openhub.ui.fragment;

import android.content.DialogInterface;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.thirtydegreesray.openhub.AppConfig;
import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.inject.component.AppComponent;
import com.thirtydegreesray.openhub.inject.component.DaggerFragmentComponent;
import com.thirtydegreesray.openhub.inject.module.FragmentModule;
import com.thirtydegreesray.openhub.mvp.contract.IWorkflowEditorContract;
import com.thirtydegreesray.openhub.mvp.presenter.WorkflowEditorPresenter;
import com.thirtydegreesray.openhub.ui.activity.WorkflowEditorActivity;
import com.thirtydegreesray.openhub.ui.fragment.base.BaseFragment;
import com.thirtydegreesray.openhub.util.BundleHelper;
import com.thirtydegreesray.openhub.util.StringUtils;

import butterknife.BindView;

/**
 * Edit area of the workflow editor.
 */
public class WorkflowEditorFragment extends BaseFragment<WorkflowEditorPresenter>
        implements IWorkflowEditorContract.View {

    @BindView(R.id.code_edit) EditText codeEdit;
    @BindView(R.id.loader) ProgressBar loader;

    /** text as loaded / last committed, used to detect unsaved changes */
    private String originalText;
    private String filePath;
    private String ref;

    public static WorkflowEditorFragment create(String owner, String repo, String workflowId,
                                                String branch, String defaultBranch) {
        WorkflowEditorFragment fragment = new WorkflowEditorFragment();
        fragment.setArguments(BundleHelper.builder()
                .put("owner", owner)
                .put("repo", repo)
                .put("workflowId", workflowId)
                .put("branch", branch)
                .put("defaultBranch", defaultBranch).build());
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_workflow_editor;
    }

    @Override
    protected void setupFragmentComponent(AppComponent appComponent) {
        DaggerFragmentComponent.builder()
                .appComponent(appComponent)
                .fragmentModule(new FragmentModule(this))
                .build()
                .inject(this);
    }

    @Override
    protected void initFragment(Bundle savedInstanceState) {
        // the file is loaded by the presenter, typing is possible once it is shown
        codeEdit.setEnabled(false);
    }

    @Override
    public void showLoading() {
        super.showLoading();
        if (loader != null) loader.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        super.hideLoading();
        if (loader != null) loader.setVisibility(View.GONE);
    }

    @Override
    public void showFile(String text, String path, String ref) {
        this.originalText = text;
        this.filePath = path;
        this.ref = ref;
        codeEdit.setText(text);
        codeEdit.setEnabled(true);
        if (getActivity() instanceof WorkflowEditorActivity) {
            String fileName = path.substring(path.lastIndexOf('/') + 1);
            ((WorkflowEditorActivity) getActivity()).updateTitle(fileName, ref);
        }
    }

    @Override
    public void showLoadError(String error) {
        showErrorToast(error);
    }

    @Override
    public void onCommitted() {
        originalText = getCurrentText();
        showSuccessToast(getString(R.string.actions_committed));
    }

    // ------------------------------------------------------------------
    // toolbar actions (called by WorkflowEditorActivity)
    // ------------------------------------------------------------------

    public boolean hasChanges() {
        return originalText != null && !originalText.equals(getCurrentText());
    }

    public void onCommitClick() {
        if (originalText == null) return;
        if (!hasChanges()) {
            showInfoToast(getString(R.string.actions_no_changes));
            return;
        }
        showCommitDialog();
    }

    public void onReloadClick() {
        if (!hasChanges()) {
            mPresenter.loadFile();
            return;
        }
        new AlertDialog.Builder(getActivity())
                .setMessage(R.string.actions_discard_confirm)
                .setPositiveButton(R.string.actions_discard, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mPresenter.loadFile();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    public String getBrowserUrl() {
        if (StringUtils.isBlank(filePath)) return null;
        return AppConfig.GITHUB_BASE_URL + mPresenter.getOwner() + "/" + mPresenter.getRepoName()
                + "/blob/" + (StringUtils.isBlank(ref) ? "HEAD" : ref) + "/" + filePath;
    }

    private String getCurrentText() {
        return codeEdit.getText().toString();
    }

    private void showCommitDialog() {
        View content = View.inflate(getActivity(), R.layout.dialog_commit, null);
        TextView infoView = (TextView) content.findViewById(R.id.commit_info);
        final EditText messageEdit = (EditText) content.findViewById(R.id.commit_message);

        String fileName = filePath.substring(filePath.lastIndexOf('/') + 1);
        infoView.setText(StringUtils.isBlank(ref) ? filePath
                : getString(R.string.actions_commit_branch, ref) + " · " + fileName);
        messageEdit.setText(getString(R.string.actions_commit_default_message, fileName));
        messageEdit.setSelection(messageEdit.getText().length());

        // positive button is wired after show(), so an empty message keeps the dialog open
        final AlertDialog dialog = new AlertDialog.Builder(getActivity())
                .setTitle(R.string.actions_commit)
                .setView(content)
                .setPositiveButton(R.string.actions_commit, null)
                .setNegativeButton(R.string.cancel, null)
                .show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = messageEdit.getText().toString().trim();
                if (message.length() == 0) {
                    messageEdit.setError(getString(R.string.actions_commit_message_required));
                    return;
                }
                dialog.dismiss();
                mPresenter.commit(getCurrentText(), message);
            }
        });
    }

}
