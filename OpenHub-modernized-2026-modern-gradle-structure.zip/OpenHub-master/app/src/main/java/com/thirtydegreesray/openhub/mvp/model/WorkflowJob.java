package com.thirtydegreesray.openhub.mvp.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.Date;

/**
 * A job of a workflow run.
 */
public class WorkflowJob {

    private long id;
    private String name;
    private String status;
    private String conclusion;
    @SerializedName("html_url") private String htmlUrl;
    @SerializedName("started_at") private Date startedAt;
    @SerializedName("completed_at") private Date completedAt;
    private ArrayList<WorkflowStep> steps;

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getStatus() {
        return status;
    }

    public String getConclusion() {
        return conclusion;
    }

    public String getHtmlUrl() {
        return htmlUrl;
    }

    public Date getStartedAt() {
        return startedAt;
    }

    public Date getCompletedAt() {
        return completedAt;
    }

    public ArrayList<WorkflowStep> getSteps() {
        return steps;
    }

    /**
     * @return job duration in millis, or -1 if unknown.
     */
    public long getDurationMillis() {
        if (startedAt == null || completedAt == null) return -1;
        long duration = completedAt.getTime() - startedAt.getTime();
        return duration < 0 ? 0 : duration;
    }

}
