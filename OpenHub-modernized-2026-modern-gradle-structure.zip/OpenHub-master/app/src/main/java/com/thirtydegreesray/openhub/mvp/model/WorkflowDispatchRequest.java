package com.thirtydegreesray.openhub.mvp.model;

import java.util.Map;

/**
 * Request body of "create a workflow dispatch event".
 * "inputs" is omitted from the JSON when null.
 */
public class WorkflowDispatchRequest {

    private String ref;
    private Map<String, String> inputs;

    public WorkflowDispatchRequest(String ref, Map<String, String> inputs) {
        this.ref = ref;
        this.inputs = (inputs == null || inputs.isEmpty()) ? null : inputs;
    }

    public String getRef() {
        return ref;
    }

    public Map<String, String> getInputs() {
        return inputs;
    }

}
