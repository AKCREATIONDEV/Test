package com.thirtydegreesray.openhub.mvp.model;

/**
 * Request body of "create or update file contents". "branch" is omitted when null
 * (GitHub then commits to the default branch).
 */
public class UpdateFileRequest {

    private String message;
    /** base64 of the new file content */
    private String content;
    /** blob sha of the file being replaced */
    private String sha;
    private String branch;

    public UpdateFileRequest(String message, String content, String sha, String branch) {
        this.message = message;
        this.content = content;
        this.sha = sha;
        this.branch = branch;
    }

    public String getMessage() {
        return message;
    }

    public String getContent() {
        return content;
    }

    public String getSha() {
        return sha;
    }

    public String getBranch() {
        return branch;
    }

}
