package com.thirtydegreesray.openhub.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.thirtydegreesray.dataautoaccess.annotation.AutoAccess;
import com.thirtydegreesray.openhub.AppConfig;
import com.thirtydegreesray.openhub.R;
import com.thirtydegreesray.openhub.mvp.contract.base.IBaseContract;
import com.thirtydegreesray.openhub.ui.activity.base.SingleFragmentActivity;
import com.thirtydegreesray.openhub.ui.fragment.ActionsFragment;
import com.thirtydegreesray.openhub.util.AppOpener;
import com.thirtydegreesray.openhub.util.BundleHelper;
import com.thirtydegreesray.openhub.util.StringUtils;

/**
 * GitHub Actions screen of a repository: workflow runs, run / cancel / re-run / delete,
 * enable / disable workflows.
 */
public class ActionsActivity extends SingleFragmentActivity<IBaseContract.Presenter, ActionsFragment> {

    public static void show(Activity activity, String owner, String repo, String branch) {
        Intent intent = createIntent(activity, owner, repo, branch);
        activity.startActivity(intent);
    }

    public static Intent createIntent(Activity activity, String owner, String repo, String branch) {
        return new Intent(activity, ActionsActivity.class)
                .putExtras(BundleHelper.builder()
                        .put("owner", owner)
                        .put("repo", repo)
                        .put("branch", branch).build());
    }

    @AutoAccess String owner;
    @AutoAccess String repo;
    @AutoAccess String branch;

    @Override
    protected void initView(Bundle savedInstanceState) {
        super.initView(savedInstanceState);
        updateSubtitle(null);
        setToolbarScrollAble(true);
    }

    @Override
    protected ActionsFragment createFragment() {
        return ActionsFragment.create(owner, repo, branch);
    }

    /**
     * Shows "owner/repo" plus the active filters under the toolbar title.
     *
     * @param filterInfo active filters, e.g. "build.yml · Failed", null or blank for none
     */
    public void updateSubtitle(String filterInfo) {
        String subTitle = owner.concat("/").concat(repo);
        if (!StringUtils.isBlank(filterInfo)) {
            subTitle = subTitle.concat(" · ").concat(filterInfo);
        }
        setToolbarTitle(getString(R.string.actions), subTitle);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_actions, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        ActionsFragment fragment = getFragment();
        switch (item.getItemId()) {
            case R.id.action_run_workflow:
                if (fragment != null) fragment.onRunWorkflowClick();
                return true;
            case R.id.action_filter_workflow:
                if (fragment != null) fragment.onFilterWorkflowClick();
                return true;
            case R.id.action_filter_status:
                if (fragment != null) fragment.onFilterStatusClick();
                return true;
            case R.id.action_manage_workflows:
                if (fragment != null) fragment.onManageWorkflowsClick();
                return true;
            case R.id.action_open_in_browser:
                AppOpener.openInCustomTabsOrBrowser(getActivity(),
                        AppConfig.GITHUB_BASE_URL + owner + "/" + repo + "/actions");
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
