package com.thirtydegreesray.openhub.mvp.contract;

import com.thirtydegreesray.openhub.mvp.contract.base.IBaseContract;

/**
 * Contract of the workflow job log viewer.
 */
public interface ILogViewerContract {

    interface View extends IBaseContract.View {
        /**
         * @param truncated true when only the end of a very large log is shown
         */
        void showLog(String log, boolean truncated);

        void showLoadError(String error);
    }

    interface Presenter extends IBaseContract.Presenter<ILogViewerContract.View> {
        void loadLog(boolean forceReload);
    }

}
