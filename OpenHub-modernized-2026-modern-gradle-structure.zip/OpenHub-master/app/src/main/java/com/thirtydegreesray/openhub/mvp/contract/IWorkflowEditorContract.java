package com.thirtydegreesray.openhub.mvp.contract;

import com.thirtydegreesray.openhub.mvp.contract.base.IBaseContract;

/**
 * Contract of the workflow file editor.
 */
public interface IWorkflowEditorContract {

    interface View extends IBaseContract.View {
        /**
         * @param path file path in the repository, e.g. .github/workflows/build.yml
         * @param ref  branch the file was loaded from (and will be committed to), may be null
         */
        void showFile(String text, String path, String ref);

        void showLoadError(String error);

        void onCommitted();
    }

    interface Presenter extends IBaseContract.Presenter<IWorkflowEditorContract.View> {
        void loadFile();

        void commit(String text, String message);
    }

}
