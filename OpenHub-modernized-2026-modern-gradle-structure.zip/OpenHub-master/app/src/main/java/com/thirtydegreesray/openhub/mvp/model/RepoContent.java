package com.thirtydegreesray.openhub.mvp.model;

import com.google.gson.annotations.SerializedName;

/**
 * A file of a repository as returned by the contents API.
 */
public class RepoContent {

    private String name;
    private String path;
    private String sha;
    private long size;
    private String content;
    private String encoding;
    @SerializedName("html_url") private String htmlUrl;

    public String getName() {
        return name;
    }

    public String getPath() {
        return path;
    }

    public String getSha() {
        return sha;
    }

    public long getSize() {
        return size;
    }

    /** base64 text, with line breaks */
    public String getContent() {
        return content;
    }

    public String getEncoding() {
        return encoding;
    }

    public String getHtmlUrl() {
        return htmlUrl;
    }

}
