# Release shrinker rules for OpenHub.
# Keep model fields used by Gson and Simple XML reflection.
-keepattributes Signature,*Annotation*,EnclosingMethod,InnerClasses,SourceFile,LineNumberTable
-keep class com.thirtydegreesray.openhub.http.model.** { *; }
-keep class com.thirtydegreesray.openhub.mvp.model.** { *; }
-keep class com.thirtydegreesray.openhub.dao.** { *; }
-keep class org.simpleframework.xml.** { *; }
-keep class org.greenrobot.greendao.** { *; }
-keep class com.thirtydegreesray.dataautoaccess.** { *; }
-keep class **$$DataAccessor { *; }
-keepclassmembers class * { @com.thirtydegreesray.dataautoaccess.annotation.AutoAccess <fields>; }

# Dagger generated injection classes
-keep class dagger.** { *; }
-keep class javax.inject.** { *; }
-dontwarn javax.annotation.**

# Glide generated modules and parsers
-keep public class * extends com.bumptech.glide.module.AppGlideModule
-keep public enum com.bumptech.glide.load.resource.bitmap.ImageHeaderParser$** { **[] $VALUES; public *; }

# EventBus subscriber annotations
-keepclassmembers class ** { @org.greenrobot.eventbus.Subscribe <methods>; }
-keep enum org.greenrobot.eventbus.ThreadMode { *; }

# Gson adapters and TypeTokens
-keep,allowobfuscation,allowshrinking class com.google.gson.reflect.TypeToken
-keep,allowobfuscation,allowshrinking class * extends com.google.gson.reflect.TypeToken
-keepclassmembers,allowobfuscation class * { @com.google.gson.annotations.SerializedName <fields>; }

# Retrofit service interfaces are discovered through annotations/reflection
-keepattributes RuntimeVisibleAnnotations,RuntimeVisibleParameterAnnotations,AnnotationDefault
-dontwarn org.codehaus.mojo.animal_sniffer.**
