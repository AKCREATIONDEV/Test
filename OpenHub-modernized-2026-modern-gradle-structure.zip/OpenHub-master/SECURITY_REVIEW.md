# Security hardening and remaining work

## Applied in this source update

- Removed the bundled release keystore and the populated `public.properties` file from the distributable source archive.
- Build secrets now come from `local.properties` or environment variables; `local.properties.example` is a blank template.
- Added ignore rules for local properties, keystores, and build outputs.
- Debug builds use the normal Android debug signing key. Release signing is enabled only when a local/CI keystore is supplied.
- AndroidX FileProvider is used; the manifest keeps `allowBackup=false`, explicitly marks internal activities non-exported, and enforces system-trusted TLS with cleartext disabled.
- Removed the unused legacy AES/ECB helper (it had a hard-coded key and no call sites).
- GitHub Actions uses JDK 17, validates the Gradle wrapper, builds both debug flavors, and uploads artifacts.

## Important security work still required before production

1. **OAuth client secret in an Android app is not secret.** Even when supplied through CI environment variables, a value compiled into `BuildConfig` can be extracted from the APK. Production OAuth should exchange the authorization code through a trusted backend; rotate any previously published client secret.
2. **Token storage still needs a dedicated secure design.** If future code persists credentials, use Android Keystore-backed authenticated encryption (AES-GCM) with a versioned migration path; do not reintroduce hard-coded encryption keys.
3. **Trending service endpoint is HTTP.** `AppConfig.OPENHUB_BASE_URL` currently points to an HTTP service. Cleartext remains disabled in the manifest, so that endpoint may fail until the service is moved to HTTPS with a valid certificate. Do not enable global cleartext traffic to work around this.
4. **Review OAuth scopes.** Current scopes include `delete_repo` and `workflow`. Request only the scopes required by the features the user enables.
5. **Release signing secrets:** store keystore bytes/passwords in protected CI secrets, never commit a `.jks` file. Use a dedicated release keystore and rotate if it has ever been exposed.
6. **ProGuard/R8:** focused keep rules are prepared, but release shrinking remains disabled until reflection-heavy Gson, Simple XML, greenDAO, Glide, ButterKnife, and DataAutoAccess paths pass minified-release tests.
7. **Target SDK 36 behavior:** verify edge-to-edge layouts, back navigation, notifications, file downloads, and runtime permissions on Android 16 before Play publication.

This document is a checklist, not a claim that all legacy security issues have already been fixed.
